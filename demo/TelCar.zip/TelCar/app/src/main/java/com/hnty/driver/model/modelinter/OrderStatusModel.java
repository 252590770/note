package com.hnty.driver.model.modelinter;


import com.hnty.driver.entity.OrderStatusParam;
import com.hnty.driver.inter.OnDriverVoiceListener;

/**
 * Created by L on 2018/1/12.
 */

public interface OrderStatusModel {

    void sendOrderStatus(OrderStatusParam param, OnDriverVoiceListener listener);

}
