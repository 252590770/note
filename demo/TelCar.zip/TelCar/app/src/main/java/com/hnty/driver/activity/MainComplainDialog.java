package com.hnty.driver.activity;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.hnty.driver.R;
import com.hnty.driver.application.MyApplication;
import com.hnty.driver.databinding.MainComplainDialogBinding;
import com.hnty.driver.entity.ComplaintOrderBean;
import com.hnty.driver.entity.ComplaintParam;
import com.hnty.driver.entity.PushOrderBean;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.inter.ComplaintOrderListener;
import com.hnty.driver.model.modelimpl.ComplaintOrderModelImpl;
import com.hnty.driver.util.SPTool;
import com.hnty.driver.util.ToastUtil;

public class MainComplainDialog extends Activity implements OnClickListener, ComplaintOrderListener {


    Context context;
    public MainComplainDialogBinding binding;

    private LinearLayout llBottom;
    private LinearLayout btnListen;
    private LinearLayout btnGet;
    private LinearLayout btnComplain;
    private LinearLayout btnFinish;
    public TextView tvTel;
    public TextView tvTime;
    public TextView tvStart;
    public TextView tvEnd;
    public TextView tvMainBottomMid;
    LinearLayout ll;


    ComplaintOrderBean bean;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        bean = (ComplaintOrderBean) getIntent().getSerializableExtra("bean");

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//保持屏幕高亮
        binding = DataBindingUtil.setContentView(this, R.layout.main_complain_dialog);
        getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);//需要添加的语句
        context = this;


        init();

        new Handler().
        postDelayed(new Runnable() {
            @Override
            public void run() {

               finish();
            }
        }, 3000);

    }

    private void init() {
        binding.back.setOnClickListener(this);
        binding.btnGetOrder.setOnClickListener(this);
        binding.ivSound.setOnClickListener(this);
        binding.tvTel.setText("乘客电话:" + "********"+bean.body.voice_tell. subSequence(bean.body.voice_tell.length()-3, bean.body.voice_tell.length()));
        binding.tvCount.setText("接单司机:" + bean.body.driver_name. subSequence(0, 1)+"师傅");
        binding.tvCarNo.setText("车牌号:" + bean.body.car_no);

//        setGetOrderLocation(MainTopDialog.mainTopDialog.binding.tvLocation,
//                bean.body.get_longitude, bean.body.get_latitude);

    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
//		finish();
        return true;
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.back:

                finish();

                break;

            case R.id.btnGetOrder:
                    showSinpleChioceDialog();
                break;

            case R.id.ivSound:

                PushOrderBean pushOrderBean = new PushOrderBean();
                pushOrderBean.body = new PushOrderBean.BodyBean();
                pushOrderBean.body.voice_name = bean.body.voice_name;
                pushOrderBean.body.end_name = bean.body.voice_name;
                pushOrderBean.body.driver_name = bean.body.driver_name;
                MyApplication.playMedia(pushOrderBean,null);
                break;
        }

    }





    //////////////////进度框进度框进度框///////////////////
    //显示进度框
    private ProgressDialog progDialog = null;//

    private void showProgressDialog(String str) {
        if (progDialog == null)
            progDialog = new ProgressDialog(this);
        progDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progDialog.setIndeterminate(false);
        progDialog.setCancelable(true);
        progDialog.setMessage(str);
        progDialog.show();
    }

    //隐藏进度框
    private void dissmissProgressDialog() {
        if (progDialog != null) {
            progDialog.dismiss();
        }
    }
    //////////////////进度框进度框进度框///////////////////




    //////////////////司机投诉///////////////////
    //投诉显示单选对话框
    int mWhich;
    public void showSinpleChioceDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("选择投诉:");
//		builder.setIcon(R.drawable.driver_icon);
        final String[] items = new String[]{"远距离接单", "黑车",};
        builder.setSingleChoiceItems(items, 0, new DialogInterface.OnClickListener() {/*设置单选条件的点击事件*/
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mWhich = which;
            }
        });
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                touSu(mWhich);
            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        builder.setCancelable(false);
        builder.show();
    }

    private ComplaintOrderModelImpl complaintOrderModel;//comlain

    void touSu(int which) {
        if (complaintOrderModel == null) {
            complaintOrderModel = new ComplaintOrderModelImpl();
        }
        try {

            ComplaintParam param;
            param = new ComplaintParam("getDrivercomplaint", which + "",
                    SPTool.getUserInfo(context).body.driver_id,
                    bean.body.voice_order,
                    SPTool.getMyPushOrderInfo(this).body.voice_tell);
            complaintOrderModel.sendComplaint(param, this);
        } catch (Exception e) {
        }
    }

    @Override
    public void onComplaintSuccess(String str) {
        ToastUtil.show(context,str);
    }

    @Override
    public void onComplaintError(String errStr) {
        ToastUtil.show(context,errStr);
    }
    //////////////////司机投诉///////////////////

}
