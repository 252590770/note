package com.hnty.driver.model.modelinter;


import com.hnty.driver.inter.OnDriverRankListener;


public interface DriverRankModel {

    void getDriverRank(OnDriverRankListener listener);

}
