package com.hnty.driver.entity;


public class EventBean {

    public int code;
    public String result;




    public EventBean(String result) {
        this.result = result;
    }

    public EventBean(int code) {
        this.code = code;
    }

    public EventBean(int code, String result) {
        this.code = code;
        this.result = result;
    }
}
