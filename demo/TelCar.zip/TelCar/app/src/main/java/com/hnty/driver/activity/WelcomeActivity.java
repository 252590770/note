package com.hnty.driver.activity;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;

import com.hnty.driver.MainActivity;
import com.hnty.driver.R;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.impl.PermissionResultListener;

import java.io.File;


public class WelcomeActivity extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        startActivity(new Intent(this,MainActivity.class));
        finish();

    }


}
