package com.hnty.driver.model.modelimpl;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.DriverCancelBean;
import com.hnty.driver.entity.DriverCancelParam;
import com.hnty.driver.entity.OrderRepeatBean;
import com.hnty.driver.entity.OrderRepeatParam;
import com.hnty.driver.inter.OnDriverCancelListener;
import com.hnty.driver.inter.OnOrderRepeatListener;
import com.hnty.driver.model.modelinter.DriverCancelModel;
import com.hnty.driver.model.modelinter.OrderRepeatModel;
import com.hnty.driver.util.NetworkUtil;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;


public class OrderRepeatModelImpl implements OrderRepeatModel {



    @Override
    public void orderRepeat(OrderRepeatParam param, final OnOrderRepeatListener listener) {



        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            listener.onOrderRepeatError("没有网络o");
            return;
        }

        MyApplication.getAPI().orderRepeat(param.method,param.driver_id,param.voice_order)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<OrderRepeatBean>(){

                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull OrderRepeatBean bean) {

                        try {

                            if(bean.code==1){
                                listener.onOrderRepeatSuccess(bean);
                            }else if(bean.code==0){
                                listener.onOrderRepeatError(bean.msg);
                            }
                        }catch (Exception e){
                            listener.onOrderRepeatError("数据错误" );
                        }
                    }
                    @Override
                    public void onError(@NonNull Throwable e) {
                        listener.onOrderRepeatError("数据错误");
                    }

                    @Override
                    public void onComplete() {
                    }
                });


    }


}
