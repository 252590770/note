package com.hnty.driver.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnty.driver.MainActivity;
import com.hnty.driver.R;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.impl.PermissionResultListener;
import com.hnty.driver.inter.OnPosyListener;
import com.hnty.driver.model.modelimpl.GetPosyModelImpl;
import com.hnty.driver.model.modelimpl.ToPosyModelImpl;
import com.hnty.driver.tts.MiniTTS;
import com.hnty.driver.util.CommonUtils;
import com.hnty.driver.util.SPTool;
import com.hnty.driver.util.ToastUtil;
import com.hnty.driver.view.statusbar.StatusBarUtil;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;


public class QRCodeActivity extends Activity {

    Context context;
    String orderId;
    String count;
    WebView webView;
    TextView money;
    TextView tvTime;
    ImageView ivBack;
    Toolbar toolbar;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_code);
        // 设置透明状态栏
        StatusBarUtil.setColor(this, CommonUtils.getColor(R.color.colorTheme), 0);
        setTitle("收款码");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//来保持屏幕高亮
        context = this;
        orderId = getIntent().getStringExtra("billNo");

//        showProgressDialog("请稍等...");
        orderId+=((int)((Math.random()*9+1)*1000));

        count = getIntent().getStringExtra("count");
        webView = (WebView) findViewById(R.id.webView);
        money = (TextView) findViewById(R.id.money);
        tvTime = (TextView) findViewById(R.id.tvTime);
        tvTime.setVisibility(View.INVISIBLE);
        ivBack = (ImageView) findViewById(R.id.ivBack);
        toolbar = (Toolbar) findViewById(R.id.tool_bar);
        initWebView();
        toolbar.setTitle("付款码");
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        money.setText(count);
        findViewById(R.id.llMoney).setVisibility(View.VISIBLE);
        SPTool.putBoolean(context,"QRCodeActivityAlive",true);

        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.addJavascriptInterface(new InJavaScriptLocalObj(), "local_obj");
//        webView.loadUrl("http://www.baidu.com");
        webView.loadUrl(Constant.baseUrl+Constant.travel+"/toPosyinfo.action?" +
                "method=toPosy&billNo=" +
                orderId +
                "&totalAmount=" +
                count);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return super.shouldOverrideUrlLoading(view, url);
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                view.loadUrl("javascript:window.local_obj.showSource('<head>'+" + "document.getElementsByTagName('html')[0].innerHTML+'</head>');");
                super.onPageFinished(view, url);
            }
        });



    handler.postDelayed(runnable, 0);

    }



    /**
     * js接口
     */
    final class InJavaScriptLocalObj {
        @JavascriptInterface
        public void showSource(String html) {
            getHtmlContent(html);
        }
    }


    /**
     * 获取内容
     * @param html
     */
    private String pageDescription="";
    private void getHtmlContent(final String html){
        Log.d("LOGCAT","网页内容:"+html);
        Document document = Jsoup.parse(html);
        pageDescription=document.select("meta[name=description]").get(0).attr("content");
        Log.i("cai1227","description:"+pageDescription);


//        dissmissProgressDialog();

        if("requestPay".equals(pageDescription)){
//            findViewById(R.id.llMoney).setVisibility(View.VISIBLE);
        }else {
//            findViewById(R.id.llMoney).setVisibility(View.INVISIBLE);
        }



    }



    int second = 300;
    Handler handler = new Handler();
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            // TODO Auto-generated method stub
            //要做的事情，这里再次调用此Runnable对象，以实现每两秒实现一次的定时器操作
            second--;
            handler.postDelayed(this, 1000);
//            tvTime.setText("("+second+"秒后关闭"+")");
            if(second%3==0){
                getPosy();
            }

//            if(second==0){
//                finish();
//            }
        }
    };


    @Override
    protected void onDestroy() {
        handler.removeCallbacks(runnable);
        SPTool.putBoolean(context,"QRCodeActivityAlive",false);
        try {
            MyMessageActivity.getMyMessageActivity().finish();
        }catch (Exception e){
        }
        super.onDestroy();
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void initWebView() {

        WebSettings ws = webView.getSettings();
        // 网页内容的宽度是否可大于WebView控件的宽度
        ws.setLoadWithOverviewMode(false);
        // 保存表单数据
        ws.setSaveFormData(true);
        // 是否应该支持使用其屏幕缩放控件和手势缩放
        ws.setSupportZoom(true);
        ws.setBuiltInZoomControls(true);
        ws.setDisplayZoomControls(false);
        // 启动应用缓存
        ws.setAppCacheEnabled(true);
        // 设置缓存模式
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        // setDefaultZoom  api19被弃用
        // 设置此属性，可任意比例缩放。
        ws.setUseWideViewPort(true);
        // 不缩放
        webView.setInitialScale(100);
        // 告诉WebView启用JavaScript执行。默认的是false。
        ws.setJavaScriptEnabled(true);
        //  页面加载好以后，再放开图片
        ws.setBlockNetworkImage(false);
        // 使用localStorage则必须打开
        ws.setDomStorageEnabled(true);
        // 排版适应屏幕
        ws.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NARROW_COLUMNS);
        // WebView是否新窗口打开(加了后可能打不开网页)
        ws.setSupportMultipleWindows(true);

        // webview从5.0开始默认不允许混合模式,https中不能加载http资源,需要设置开启。
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        /** 设置字体默认缩放大小(改变网页字体大小,setTextSize  api14被弃用)*/
        ws.setTextZoom(100);


    }


    public void getQrCode(View view) {
        if (money.getText().toString().trim().length() == 0) {
            ToastUtil.show(context, "请输入金额");
            return;
        }
        webView.loadUrl(Constant.baseUrl+Constant.travel+"/toPosyinfo.action?" +
                "method=toPosy&billNo=" +
                orderId +
                "&totalAmount=" +
                count);
        hideKeyboard();
    }


    ToPosyModelImpl posyModel;
    OnPosyListener onPosyListener;
    void toPosy(final String billNo, final String totalAmount) {
        if (posyModel == null) {
            posyModel = new ToPosyModelImpl();
        }
        if (onPosyListener == null) {
            onPosyListener = new OnPosyListener() {
                @Override
                public void onPosSuccess(String code) {

                }

                @Override
                public void onPosError(String errStr) {

                }
            };
        }

        posyModel.toPosy(billNo, totalAmount, onPosyListener);
    }



    GetPosyModelImpl getPosyModel;
    GetPosyModelImpl.OnGetPosyListener onGetPosyListener;
    void getPosy (){
        if(getPosyModel == null){
            getPosyModel = new GetPosyModelImpl();
        }

        if(onGetPosyListener == null){
            onGetPosyListener = new GetPosyModelImpl.OnGetPosyListener() {
                @Override
                public void onGetPosySuccess(String cede) {

                    if(cede.equals("1")){
                        QRCodeActivity.this.finish();
                        yuYin("付款成功!");

                    }
                }

                @Override
                public void onGetPosyError(String errStr) {
//                    ToastUtil.show(context,errStr);
                }
            };
        }
        getPosyModel.getPosy(orderId,onGetPosyListener);
    }



    //显示进度框
    private ProgressDialog progDialog = null;//

    private void showProgressDialog(String str) {
        if (progDialog == null)
            progDialog = new ProgressDialog(this);
        progDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progDialog.setIndeterminate(false);
        progDialog.setCancelable(true);
        progDialog.setMessage(str);
        progDialog.show();
    }

    //隐藏进度框
    private void dissmissProgressDialog() {
        if (progDialog != null) {
            progDialog.dismiss();
        }
    }


    public static void start(Context mContext) {
        Intent intent = new Intent(mContext, QRCodeActivity.class);
        mContext.startActivity(intent);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm.isActive()) {
            if (this.getCurrentFocus().getWindowToken() != null) {
                imm.hideSoftInputFromWindow(this.getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        }
    }




    MiniTTS tts;//语音播报
    void  yuYin (final String str){


        performRequestPermissions(getString(R.string.permission_imei),
                new String[]{
                        Manifest.permission.MODIFY_AUDIO_SETTINGS
                }
                , PER_REQUEST_CODE,
                new PermissionResultListener() {
                    @Override
                    public void onPermissionDenied() {

                    }

                    @Override
                    public void onPermissionGranted() {

                        try {

                            tts = new MiniTTS(context);
                            tts.initPermission().initTTs();
                            tts.speak(str);
//                                    tts.speak("测试2");

                        }catch (Exception E)
                        {
                            E.printStackTrace();
                        }

                    }
                });
    }















    ///////////////////////////////获取运行时权限/////////////////////////////
    final int PER_REQUEST_CODE = 0;

    private void getLoginIMSI() {

        performRequestPermissions(getString(R.string.permission_imei),
                new String[]{
                        Manifest.permission.READ_PHONE_STATE,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.READ_PHONE_STATE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.WAKE_LOCK,
                        Manifest.permission.DISABLE_KEYGUARD,
                        Manifest.permission.RECEIVE_BOOT_COMPLETED,
                        Manifest.permission.SYSTEM_ALERT_WINDOW,
                }
                , PER_REQUEST_CODE,
                new PermissionResultListener() {
                    @Override
                    public void onPermissionDenied() {

                    }

                    @Override
                    public void onPermissionGranted() {

                        try {


                        } catch (Exception E) {
                            E.printStackTrace();
                        }

                    }
                });


    }

    //请求码
    private int mRequestCode;
    //运行时权限接口
    private PermissionResultListener mListener;

    protected void performRequestPermissions(String desc, String[] permissions,
                                             int requestCode,
                                             PermissionResultListener listener) {
        if (permissions == null || permissions.length == 0) {
            return;
        }
        mRequestCode = requestCode;
        mListener = listener;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkEachSelfPermission(permissions)) {// 检查是否声明了权限
                requestEachPermissions(desc, permissions, requestCode);
            } else {// 已经申请权限
                if (mListener != null) {
                    mListener.onPermissionGranted();
                }
            }
        } else {
            if (mListener != null) {
                mListener.onPermissionGranted();
            }
        }
    }

    /**
     * 检察每个权限是否申请
     *
     * @param permissions
     * @return true 需要申请权限,false 已申请权限
     */
    private boolean checkEachSelfPermission(String[] permissions) {
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) !=
                    PackageManager.PERMISSION_GRANTED) {
                return true;
            }
        }
        return false;
    }

    private void requestEachPermissions(String desc, String[] permissions, int requestCode) {
        if (shouldShowRequestPermissionRationale(permissions)) {// 需要再次声明
            showRationaleDialog(desc, permissions, requestCode);
        } else {
            ActivityCompat.requestPermissions(QRCodeActivity.this, permissions, requestCode);
        }
    }


    /**
     * 再次申请权限时，是否需要声明
     *
     * @param permissions
     * @return
     */
    private boolean shouldShowRequestPermissionRationale(String[] permissions) {
        for (String permission : permissions) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 弹出声明的 Dialog
     *
     * @param desc
     * @param permissions
     * @param requestCode
     */
    private void showRationaleDialog(String desc, final String[] permissions,
                                     final int requestCode) {
        final android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.tips))
                .setMessage(desc)
                .setPositiveButton(getResources().getString(R.string.sure),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                ActivityCompat.requestPermissions(QRCodeActivity.this,
                                        permissions, requestCode);
                            }
                        })
                .setNegativeButton(getResources().getString(R.string.cancel),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        })
                .setCancelable(false)
                .show();
    }
    ///////////////////////////////获取运行时权限/////////////////////////////
}
