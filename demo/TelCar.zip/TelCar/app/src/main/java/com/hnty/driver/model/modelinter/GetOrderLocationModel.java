package com.hnty.driver.model.modelinter;


import android.widget.TextView;

import com.hnty.driver.entity.GetOrderLocationParam;
import com.hnty.driver.inter.OnGetOrderLocationListener;


public interface GetOrderLocationModel {

    void getOrderLocation(GetOrderLocationParam param, OnGetOrderLocationListener listener, TextView tv);

}
