package com.hnty.driver.inter;


import com.hnty.driver.entity.UpdateBean;

/**
 * Created by L on 2018/1/12.
 */

public interface OnUpdateListener {

    void onUpdateSuccess(UpdateBean bean);
    void onUpdateError(Object err);

}
