package com.hnty.driver.application;

import android.app.ActivityManager;
import android.app.Application;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Handler;
import android.support.multidex.MultiDexApplication;
import android.util.Log;

import com.hnty.driver.LocalService;
import com.hnty.driver.R;
import com.hnty.driver.api.API;
import com.hnty.driver.config.CacheInterceptor;
import com.hnty.driver.entity.EventBean;
import com.hnty.driver.entity.PushOrderBean;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.util.CrashHandler;
import com.hnty.driver.util.SPTool;
import com.hnty.driver.util.VoiceUtils;
import com.hnty.driver.util.VoiceUtils2;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.CustomConverterFactory;

//import com.uuzuche.lib_zxing.activity.ZXingLibrary;


/**
 * Created by Administrator on 2017/4/20.
 */

public class MyApplication extends MultiDexApplication {
    private int rtrn=0;
    public static API api;
    private static Retrofit retrofit = null;
    public static Context context;
    private float volumnRatio;

    private static MyApplication myApplication;
    public static MyApplication getInstance() {
        return myApplication;
    }

    //  public static RefWatcher appgetrefwatcher;
    @Override
    public void onCreate() {
        super.onCreate();
        myApplication = this;
//        ZXingLibrary.initDisplayOpinion(this);

        context = getApplicationContext();

        //全局错误日志打印
        CrashHandler crashHandler = CrashHandler.getInstance();
        crashHandler.init(getApplicationContext());

       // appgetrefwatcher=LeakCanary.install(this);
//        JPushInterface.setDebugMode(true); 	// 设置开启日志,发布时请关闭日志
//        JPushInterface.init(this);
    }
//    public static RefWatcher getRefWatcher(Context context) {
//        MyApplication application = (MyApplication) context.getApplicationContext();
//        return application.appgetrefwatcher;
//    }

    @Override
    public void onTrimMemory(int level) {
//        isApplicationInBackground(this);
        super.onTrimMemory(level);

    }

    //解决 method 数 超过 65536
//    @Override
//    public void attachBaseContext(Context base) {
//        super.attachBaseContext(base);
//        MultiDex.install(this);
//    }

    public void isApplicationInBackground(Context context) {
        Log.i("522","进入后台");
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> taskList = am.getRunningTasks(1);
        if (taskList != null && !taskList.isEmpty()) {
            ComponentName topActivity = taskList.get(0).topActivity;
            if (topActivity != null && !topActivity.getPackageName().equals(context.getPackageName())) {
//                ToastUtil.show(context,"进入后台  ");
                Log.i("522","进入后台");
                SPTool.putBoolean(context,"InBackground",true);
            }else {
                SPTool.putBoolean(context,"InBackground",false);
//                ToastUtil.show(context,"进入前台  ");
                Log.i("522","进入前台");

            }
        }

    }






    public static Context getContext() {
        return context;
    }


    private static ArrayList<PushOrderBean> orders;
    public static  ArrayList<PushOrderBean>  getOrderList() {

        if(orders == null){
            orders = new ArrayList<PushOrderBean>();
        }
        return orders;
    }


    public static  synchronized void   removeBean( int position,String voice_order) {


        try {

            if(position==0){
                orders.remove(position);
            }else {

                for(int i = 0; i< MyApplication.getOrderList().size() ; i++){

                    if(MyApplication.getOrderList().get(i).body.voice_order.equals(voice_order)){
                        orders.remove(MyApplication.getOrderList().get(i));
                    }
                }

            }

        }catch (Exception e){
//            ToastUtil.show(getContext(),e.toString());
        }


    }




    public static API getAPI() {

        if (api == null) {
            api = MyApplication.getRetrofit().create(API.class);
        }

        Log.i("ccccccc", "api=" + api.toString());
        Log.i("ccccccc", "retrofit=" + retrofit.toString());

        return api;

    }



    public static Retrofit getRetrofit() {

        if (retrofit == null) {
            initRetrofit();
        }
        return retrofit;
    }


    private static void initRetrofit() {
        retrofit = new Retrofit.Builder()
                .baseUrl(Constant.baseUrl)
                .addConverterFactory(CustomConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .client(okHttpClient)
                .build();
    }




    private static final int TIMEOUT_READ = 20;
    private static final int TIMEOUT_CONNECTION = 10;
    private static CacheInterceptor cacheInterceptor = new CacheInterceptor();


    static OkHttpClient.Builder builder = new OkHttpClient.Builder()
            .retryOnConnectionFailure(false)
            .connectTimeout(TIMEOUT_CONNECTION, TimeUnit.SECONDS)//单位是秒
            .readTimeout(TIMEOUT_READ, TimeUnit.SECONDS);

    static OkHttpClient okHttpClient = getOkHttpClient();

    private static OkHttpClient getOkHttpClient() {
        //日志显示级别
        HttpLoggingInterceptor.Level level= HttpLoggingInterceptor.Level.BODY;
        //新建log拦截器
        HttpLoggingInterceptor loggingInterceptor=new HttpLoggingInterceptor(new HttpLoggingInterceptor.Logger() {
            @Override
            public void log(String message) {
                Log.i("cccccc","OkHttp====Message:"+message);
            }
        });
        loggingInterceptor.setLevel(level);
        //定制OkHttp

        //OkHttp进行添加拦截器loggingInterceptor
        builder.addInterceptor(loggingInterceptor);
        return builder.build();
    }






    public static synchronized  void playMedia(final PushOrderBean bean ) {

//        if(VoiceUtils.with(context).IsPlaying){
//            return;
//        }

        VoiceUtils.with(context).Play(bean, LocalService.myService.mHandler);
    }


    public static synchronized  int  playMedia(final PushOrderBean bean , final Handler handler) {



        if(VoiceUtils.with(context).IsPlaying){
            return  -1;
        }

        try {

            return   VoiceUtils.with(context).PlayReturnLong(bean,LocalService.myService.mHandler);
        } catch (Exception e) {
            e.printStackTrace();
            EventBus.getDefault().post(new EventBean(11));
        }

        return  -1;
    }



    public static synchronized  int  playMedia2(final PushOrderBean bean , final Handler handler) {



        if(VoiceUtils2.with(context).IsPlaying){
            return  -1;
        }

        try {

            return   VoiceUtils2.with(context).PlayReturnLong(bean,LocalService.myService.mHandler);
        } catch (Exception e) {
            e.printStackTrace();

            Log.i("efsd",e.toString());

//            EventBus.getDefault().post(new EventBean(12));
        }

        return  -1;
    }




//    public  void playNewOrder(){
////        TTS.getTTS().setContext(context).play("有新订单");
//    }



    public  void playRunOrder(){

        try {


            final MediaPlayer  mediaPlayerneworder= MediaPlayer.create(context, R.raw.run_order);
            mediaPlayerneworder.start();
            mediaPlayerneworder.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp)
                {
                    mediaPlayerneworder.stop();
                    mediaPlayerneworder.release();
                }
            });

        }catch (Exception e){ }
    }



    public  void playDriveOrder(){

        try {


            final MediaPlayer  mediaPlayerneworder= MediaPlayer.create(context, R.raw.drive_order);
            mediaPlayerneworder.start();
            mediaPlayerneworder.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp)
                {
                    mediaPlayerneworder.stop();
                    mediaPlayerneworder.release();
                }
            });

        }catch (Exception e){ }
    }

//    public  void noMoreMoney(){
//        TTS.getTTS().setContext(context).play("余额不足");//no_more_money
//    }

    public  void noMoreMoney(){
        try {
            final MediaPlayer mediaPlayer= MediaPlayer.create(context, R.raw.no_more_money);
            mediaPlayer.start();
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp)
                {
                    mediaPlayer.stop();
                    mediaPlayer.release();
                }
            });

        }catch (Exception e){ }
    }


    public  void PlayDriverOnLine(){

        try {
            final MediaPlayer mediaPlayer= MediaPlayer.create(context, R.raw.driver_out);
            mediaPlayer.start();
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp)
                {
                    mediaPlayer.stop();
                    mediaPlayer.release();

                }
            });

        }catch (Exception e){ }

    }


//    public  void driverOutLine(){
//        TTS.getTTS().setContext(context).play("有人用此车牌登录,系统强制退出");//shut_down
//    }

    public  void driverOutLine(){

        try {
            final MediaPlayer mediaPlayer= MediaPlayer.create(context, R.raw.shut_down);
            mediaPlayer.start();
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp)
                {
                    mediaPlayer.stop();
                    mediaPlayer.release();
                    EventBus.getDefault().post(new EventBean(17));
                }
            });

        }catch (Exception e){ }


    }

    public  void driveroffLine(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {

                    final MediaPlayer mediaPlayer= MediaPlayer.create(context, R.raw.driver_off_line);
                    mediaPlayer.start();
                    mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        @Override
                        public void onCompletion(MediaPlayer mp)
                        {
                            mediaPlayer.stop();
                            mediaPlayer.release();
                            Intent location = new Intent(context,LocalService.class);
                            stopService(location);
                            android.os.Process.killProcess(android.os.Process.myPid());
                        }
                    });


                } catch (Exception e) {
                    e.printStackTrace();
                    android.os.Process.killProcess(android.os.Process.myPid());
                }
            }
        }).start();



    }



//    public  void getOutOfTheCar(){
//        TTS.getTTS().setContext(context).play("请您出车");//get_out_of_the_car
//    }
    public  void getOutOfTheCar(){


        try {
            final MediaPlayer mediaPlayer= MediaPlayer.create(context, R.raw.get_out_of_the_car);
            mediaPlayer.start();
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp)
                {
                    mediaPlayer.stop();
                    mediaPlayer.release();
                }
            });

        }catch (Exception e){ }

    }


//    public  void jieDan(){
//        TTS.getTTS().setContext(context).play("接单成功");
//    }

    public  void jieDan(){
        try {
            final MediaPlayer mediaPlayer= MediaPlayer.create(context, R.raw.jiedan);
            mediaPlayer.start();
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp)
                {
                    mediaPlayer.stop();
                    mediaPlayer.release();

                }
            });

        }catch (Exception e){ }

    }

//    public  void tiXing(){
//        TTS.getTTS().setContext(context).play("平台提醒");
//    }
    public  void tiXing(){
        try {
            final MediaPlayer mediaPlayer= MediaPlayer.create(context, R.raw.pingtaitixing);
            mediaPlayer.start();
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp)
                {
                    mediaPlayer.stop();
                    mediaPlayer.release();

                }
            });

        }catch (Exception e){ }

    }


//    public  void beiJie(){
//        TTS.getTTS().setContext(context).play("订单已被接");
//    }

    public  void beiJie(){
        try {
            final MediaPlayer mediaPlayer= MediaPlayer.create(context, R.raw.dingdan_beijie);
            mediaPlayer.start();
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp)
                {
                    mediaPlayer.stop();
                    mediaPlayer.release();

                }
            });

        }catch (Exception e){ }

    }







}
