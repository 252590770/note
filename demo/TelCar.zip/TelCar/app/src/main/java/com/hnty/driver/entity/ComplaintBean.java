package com.hnty.driver.entity;

import com.google.gson.Gson;


public class ComplaintBean {


     

    public int code;
    public String msg;
    public BodyBean body;

    @Override
    public String toString() {

        return new Gson().toJson(this);
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public BodyBean getBody() {
        return body;
    }

    public void setBody(BodyBean body) {
        this.body = body;
    }


    public static class BodyBean {
    }
}
