package com.hnty.driver.model.modelimpl;

import android.util.Log;
import android.view.LayoutInflater;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.GetListParam;
import com.hnty.driver.entity.GetListResult;
import com.hnty.driver.entity.LoginParam;
import com.hnty.driver.entity.UserInfoBean;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.inter.OnGetListInfoListener;
import com.hnty.driver.inter.OnLoginListener;
import com.hnty.driver.model.modelinter.InfoListModel;
import com.hnty.driver.model.modelinter.LoginModel;
import com.hnty.driver.util.NetworkUtil;
import com.hnty.driver.util.SPTool;

import java.util.ArrayList;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by L on 2018/1/12.
 */

public class LoginModelImpl implements LoginModel {

    @Override
    public void sendLogin(LoginParam param, final OnLoginListener loginListener) {


        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            loginListener.onError("没有网络o");
            return;
        }


        Log.i("ccccccccc","param.method="+param.method);
        Log.i("ccccccccc","param.driver_tell="+param.driver_tell);
        Log.i("ccccccccc","param.carNo="+param.carno);
        Log.i("ccccccccc","param.driver_pass="+param.driver_pass);
        Log.i("ccccccccc","param.driver_ismi="+param.driver_ismi);


        MyApplication.getAPI().sendLogin(param.method,param.driver_tell,param.carno,param.driver_pass,param.driver_ismi)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<UserInfoBean>() {
                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull UserInfoBean bean) {

                        try {

                            if(bean.code==1){
                                loginListener.onSuccess(bean);
                            }else {
                                loginListener.onError(bean.msg);
                            }


                        }catch (Exception e){
                            loginListener.onError("数据错误");
                        }
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        loginListener.onError("数据错误");
                        Log.i("ccccccc","onError="+e.toString());
                    }

                    @Override
                    public void onComplete() {

                    }
                });





    }


}
