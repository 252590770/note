package com.hnty.driver.model.modelimpl;

import android.util.Log;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.FinishOrderBean;
import com.hnty.driver.entity.FinishOrderParam;
import com.hnty.driver.entity.OrderStatusParam;
import com.hnty.driver.inter.OnDriverVoiceListener;
import com.hnty.driver.inter.OnFinishOrderListener;
import com.hnty.driver.model.modelinter.FinishOrderModel;
import com.hnty.driver.model.modelinter.OrderStatusModel;
import com.hnty.driver.util.NetworkUtil;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by L on 2018/1/12.
 */

public class FinishOrderModelImpl implements FinishOrderModel {

    @Override
    public void sendFinishOrder(FinishOrderParam param, final OnFinishOrderListener listener) {


        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            listener.OnFinishOrderError("没有网络o");
            return;
        }


        MyApplication.getAPI().sendFinishOrder(
                param.method,
                param.voice_state,
                param.driver_id,
                param.voice_order,
                param.driver_latitude,
                param.driver_longitude  )
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<FinishOrderBean>() {
                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull FinishOrderBean bean) {
                        try {

                            if(bean.code==1){
                                listener.OnFinishOrderSuccess(bean.msg);
                            }else {
                                listener.OnFinishOrderError(bean.msg);
                            }


                        }catch (Exception e){
                            listener.OnFinishOrderError(("数据错误"));
                        }
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        listener.OnFinishOrderError(("数据错误"));
                        Log.i("ccccccc","onError="+e.toString());
                    }

                    @Override
                    public void onComplete() {
                    }
                });







    }



}
