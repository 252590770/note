package com.hnty.driver.inter;


import com.hnty.driver.entity.DriverGetUserBean;

/**
 * Created by L on 2018/1/12.
 */

public interface OnDriverGetUserListener {

    void onDriverGetUserSuccess(DriverGetUserBean bean);
    void onDriverGetUserError(String errStr);

}
