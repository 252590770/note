package com.hnty.driver.entity;

/**
 * Created by L on 2018/1/11.
 */

public class SendDriverPositionParam {
    public String method;
    public String driver_latitude;
    public String driver_longitude;
    public String driver_id;

    public SendDriverPositionParam(String method, String driver_latitude, String driver_longitude, String driver_id) {
        this.method = method;
        this.driver_latitude = driver_latitude;
        this.driver_longitude = driver_longitude;
        this.driver_id = driver_id;
    }
}
