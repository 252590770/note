package com.hnty.driver.inter;


/**
 * Created by L on 2018/1/12.
 */

public interface OnRegisterListener {

    void onRegisterSuccess(String str);
    void onRegisterError(String err);

}
