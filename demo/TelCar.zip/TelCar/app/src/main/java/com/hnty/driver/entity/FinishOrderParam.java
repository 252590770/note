package com.hnty.driver.entity;

/**
 * Created by L on 2018/1/11.
 */

public class FinishOrderParam {
    public String method;
    public String voice_state;
    public String driver_id;
    public String voice_order;
    public String driver_longitude;
    public String driver_latitude;


    public FinishOrderParam() {
    }

    public FinishOrderParam(String method, String voice_state, String driver_id, String voice_order,  String driver_latitude,String driver_longitude) {
        this.method = method;
        this.voice_state = voice_state;
        this.driver_id = driver_id;
        this.voice_order = voice_order;
        this.driver_longitude = driver_longitude;
        this.driver_latitude = driver_latitude;
    }
}
