package com.hnty.driver;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DownloadManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.PowerManager;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.hnty.driver.activity.LoginActivity;
import com.hnty.driver.activity.MainComplainDialog;
import com.hnty.driver.activity.MainTopDialog;
import com.hnty.driver.activity.MyMessageActivity;
import com.hnty.driver.activity.MyNoticeActivity;
import com.hnty.driver.activity.OrderDetailsActivity;
import com.hnty.driver.activity.PersonalInformationActivity;
import com.hnty.driver.activity.RankingActivity;
import com.hnty.driver.activity.ScreenListener;
import com.hnty.driver.activity.SettingActivity;
import com.hnty.driver.activity.UserKnowActivity;
import com.hnty.driver.activity.VoiceOrderListActivity;
import com.hnty.driver.application.MyApplication;
import com.hnty.driver.base.NetWorkChangReceiver;
import com.hnty.driver.base.PhoneBroadcastReceiver;
import com.hnty.driver.base.SMSBroadcastReceiver;
import com.hnty.driver.databinding.ActivityMainBinding;
import com.hnty.driver.entity.ComplaintOrderBean;
import com.hnty.driver.entity.DriverOutBean;
import com.hnty.driver.entity.DriverOutParam;
import com.hnty.driver.entity.EventBean;
import com.hnty.driver.entity.GetCodeForUpdateCarNoBean;
import com.hnty.driver.entity.GetDriverOrderStateBean;
import com.hnty.driver.entity.OrderLocationBean;
import com.hnty.driver.entity.OrderStatusParam;
import com.hnty.driver.entity.OutLineDriverBean;
import com.hnty.driver.entity.OutLineDriverParam;
import com.hnty.driver.entity.PushOrderBean;
import com.hnty.driver.entity.UpDateCarNoParam;
import com.hnty.driver.entity.UpLoadTokenParam;
import com.hnty.driver.entity.UpdateBean;
import com.hnty.driver.entity.UpdateDriverBean;
import com.hnty.driver.entity.UpdateDriverVerParam;
import com.hnty.driver.entity.UserInfoBean;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.impl.PermissionResultListener;
import com.hnty.driver.inter.OnCodeForUpdateCarNoListener;
import com.hnty.driver.inter.OnDriverOrderStateListener;
import com.hnty.driver.inter.OnDriverOutListener;
import com.hnty.driver.inter.OnDriverVoiceListener;
import com.hnty.driver.inter.OnGetOrderLocationListener;
import com.hnty.driver.inter.OnOutLineDriverListener;
import com.hnty.driver.inter.OnSendDriverPositionListener;
import com.hnty.driver.inter.OnSkanCodeInfoListener;
import com.hnty.driver.inter.OnUpDateCarNoListener;
import com.hnty.driver.inter.OnUpLoadTokenListener;
import com.hnty.driver.inter.OnUpdateDriverVerListener;
import com.hnty.driver.inter.OnUpdateListener;
import com.hnty.driver.model.modelimpl.DriverOrderStateModelImpl;
import com.hnty.driver.model.modelimpl.DriverOutModelImpl;
import com.hnty.driver.model.modelimpl.GetIdentifyingCodeModelImpl;
import com.hnty.driver.model.modelimpl.OrderStatusModelImpl;
import com.hnty.driver.model.modelimpl.OutLineDriverModelImpl;
import com.hnty.driver.model.modelimpl.ScanCodeInfoModelImpl;
import com.hnty.driver.model.modelimpl.UpDateCarNoModelImpl;
import com.hnty.driver.model.modelimpl.UpLoadTokenModelImpl;
import com.hnty.driver.model.modelimpl.UpdateDriverVerModelImpl;
import com.hnty.driver.model.modelimpl.UpdateModelImpl;
import com.hnty.driver.services.LocationService;
import com.hnty.driver.tts.MiniTTS;
import com.hnty.driver.update.UpdateManager;
import com.hnty.driver.util.CommonUtils;
import com.hnty.driver.util.GetPostUrl;
import com.hnty.driver.util.HttpConnectionUtil;
import com.hnty.driver.util.MyUtil;
import com.hnty.driver.util.SPTool;
import com.hnty.driver.util.ToastUtil;
import com.hnty.driver.util.VoiceUtils;
import com.hnty.driver.view.statusbar.StatusBarUtil;
import com.squareup.picasso.Picasso;
import com.yzq.zxinglibrary.android.CaptureActivity;
import com.yzq.zxinglibrary.bean.ZxingConfig;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.net.URLEncoder;
import java.util.Date;
import java.util.Iterator;

import static com.hnty.driver.finals.Constant.MyPushOrderBean;

public class MainActivity extends Activity implements OnUpdateListener, OnDriverOutListener, OnOutLineDriverListener, OnGetOrderLocationListener,
        View.OnClickListener, OnDriverVoiceListener, PopupWindow.OnDismissListener, OnSendDriverPositionListener, OnUpdateDriverVerListener  {
    public static final String TAG = "MainActivity";
    private Context context;
    private NetWorkChangReceiver netWorkChangReceiver;
    private final static int REQUEST_IGNORE_BATTERY_CODE = 5001;
    private IGetData iGetData;
    private ScreenListener mScreenListener;
    private SMSBroadcastReceiver mSMSBroadcastReceiver;
    private LinearLayout drawerLayout;
    private DownBroadcastReceiver dbrecv;

    private PopupWindow popupWindow;
    private int navigationHeight;

    private PhoneBroadcastReceiver callgReceiver;
    private String[] time;
    private String distance;

    public static MainActivity mainActivity;

    UpdateModelImpl updateModel;
    private int initsum=0;
    boolean isFirst = false;
    private  int startint=0;
    long CURRENT_TIME;

    // 一定需要对应的bean
    private ActivityMainBinding mBinding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//保持屏幕高亮
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);//竖屏显示
        EventBus.getDefault().register(this);
        context = this;
        getLoginIMSI();
        mainActivity = this;
        updateModel = new UpdateModelImpl();

        initId();
        StatusBarUtil.setColor(this, CommonUtils.getColor(R.color.colorTheme), 0);

        int resourceId = getResources().getIdentifier("navigation_bar_height", "dimen", "android");
        navigationHeight = getResources().getDimensionPixelSize(resourceId);


        updateModel.checkUpdate(null, this);

        dbrecv = new DownBroadcastReceiver();
        //2.创建intent-filter对象
        IntentFilter filter = new IntentFilter();
        filter.addAction(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        //3.注册广播接收者
        registerReceiver(dbrecv, filter);


        //注册网络状态监听广播
        netWorkChangReceiver = new NetWorkChangReceiver();
        IntentFilter filternet = new IntentFilter();
        filternet.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        filternet.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        filternet.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netWorkChangReceiver, filternet);


        mSMSBroadcastReceiver = new SMSBroadcastReceiver();
        IntentFilter intentFiltersms = new IntentFilter(SMSBroadcastReceiver.SMS_RECEIVED_ACTION);
        intentFiltersms.setPriority(Integer.MAX_VALUE);
        registerReceiver(mSMSBroadcastReceiver, intentFiltersms);


        //注册电话广播
//        callgReceiver = new PhoneBroadcastReceiver();
//        IntentFilter filtercall = new IntentFilter();
//        filtercall.addAction(".PhoneBroadcastReceiver");
//        registerReceiver(callgReceiver, filtercall);

        mSMSBroadcastReceiver.setOnReceivedMessageListener(new SMSBroadcastReceiver.OnReceivedMessageListener() {
            @Override
            public void onReceived(String message) {
                //do something
                if (message.indexOf("在线测试 如有打扰敬请谅解！") > 0) {
                    //ToastUtil.show(MainActivity.this,message);
                    initService();
                }

            }
        });

        onUpdateDriverver();

        initScreenListener();

        initsum=0;

        if (!isIgnoringBatteryOptimizations())
        {
            gotoSettingIgnoringBatteryOptimizations();
        }

        initService();
        initGPS();
        startint=0;

        setPayIv();

        new Thread(){
            @Override
            public void run() {
                super.run();


                while (true){
                    if(!SPTool.getBoolean(MainActivity.this,"InBackground")){
                        //在前台
                        getDriverOrderState();

                        Log.i("117","前台   getDriverOrderState");


                    }else {
                        Log.i("117"," 后台  后台");

                    }


                    try {
                        sleep(20000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }


            }
        }.start();



//        yuYin(getString(R.string.app_name)+"友情提醒：理性抢单，安全驾驶,123456789");
        yuYin(getString(R.string.app_name)+"友情提醒：理性抢单，安全驾驶");




    }






    void setPayIv(){


        if(SPTool.getUserInfo(MainActivity.this)==null){
            return;
        }
        //713974207319617067.png
        Picasso.with(MainActivity.this)
                .load(Constant.baseUrl+Constant.travel+"/driverImages/"+SPTool.getUserInfo(MainActivity.this).body.driver_img.trim())
//                .load("http://221.210.80.244:8088/travel/driverImages/713974207319617067.png")
                .into(mBinding.include.ivPay);




    }




    @Override
    public void onResume() {
        super.onResume();

        if (SPTool.getUserInfo(this) == null) {
            mBinding.include.btnOnDuty.setText("出车");
            mBinding.include.topMenu.setVisibility(View.INVISIBLE);
            mBinding.include.line1.setVisibility(View.INVISIBLE);
            mBinding.include.line2.setVisibility(View.INVISIBLE);
            mBinding.include.line3.setVisibility(View.INVISIBLE);
        } else {
            mBinding.include.topMenu.setVisibility(View.VISIBLE);
            mBinding.include.line1.setVisibility(View.VISIBLE);
            mBinding.include.line2.setVisibility(View.VISIBLE);
            mBinding.include.line3.setVisibility(View.VISIBLE);
        }
        getDriverOrderState();

        Log.i("802","OrderList().size == "+MyApplication.getOrderList().size());
        if (MyApplication.getOrderList().size() > 0) {
            removeOutOfDateOrder();
        }

        SPTool.putBoolean(MainActivity.this, "InBackground", false);

        if (SPTool.getMyPushOrderInfo(this) == null) {
            mBinding.include.tvGetMoney.setTextColor(getResources().getColor(R.color.black));
            mBinding.include.tvUnFinishedOrder.setVisibility(View.GONE);
        } else {
            mBinding.include.tvGetMoney.setTextColor(getResources().getColor(R.color.red));
            mBinding.include.tvUnFinishedOrder.setVisibility(View.VISIBLE);
        }

    }



    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(EventBean event) {
        switch (event.code) {
            case 1://系统公告
                mBinding.include.tvNotice.setText(SPTool.getString(MainActivity.this, Constant.Notice));
                break;

            case 2://收到通知内容   播报第一条订单
                Log.i("522", "收到通知内容   播报第一条订单");


                if(  SPTool.getBoolean(context,"VoiceOrderListActivityAlive")){
                    break;
                }

                if (MyApplication.getOrderList().size() > 0) {

                    Intent intent2 = new Intent(MainActivity.this, MainTopDialog.class);
                    intent2.putExtra("PushOrderBean", MyApplication.getOrderList().get(0));
                    startActivity(intent2);
                }

                break;

            case 3://续播订单

//                if(  SPTool.getBoolean(context,"VoiceOrderListActivityAlive")){
//                    break;
//                }
//
//                Intent intent3 = new Intent(MainActivity.this, MainTopDialog.class);
//                intent3.putExtra("PushOrderBean", MyApplication.getOrderList().get(0));
//                startActivity(intent3);
                break;

            case 4://别人接单

                getDriverOrderState();

                try {
                    ComplaintOrderBean bean = new Gson().fromJson(event.result, ComplaintOrderBean.class);
//                    MyApplication.removeBean(-1,bean.body.voice_order);
//
                    ///////////////////////////////////////////////
                    Intent intent = new Intent(MainActivity.this, MainComplainDialog.class);
                    intent.putExtra("bean", bean);
                    startActivity(intent);


                } catch (Exception e) {
                    Log.e("425", "Exception  ==" + e.toString());
                }
                break;

            case 5://续播声音

                try {
                    MainTopDialog.mainTopDialog.finish();
                } catch (Exception e) {
                }

                break;


            case 12:
                initsum=2018;
                mBinding.include.ivState.setBackground(getResources().getDrawable(R.drawable.icon_out_line));
                mBinding.include.btnOnDuty.setText("掉线了");
                Toast.makeText(this, "网络异常", Toast.LENGTH_SHORT).show();
                break;
            case 13:

                if (initsum==2018) {
                    initsum=0;
                    initService();
                    getDriverOrderState();
                }


                break;
            case 14:
                Log.e("callphoneend", "Exception  ==" );
                initService();
            case 15: {
                String getresut = event.result;
                if (getresut != null) {
                    if (getresut.indexOf("restartdriver") > -1) {
                        initService();
                    }
                }
            }
            break;
            case 16: {


                String gettoken = event.result;
                if (gettoken != null) {
                    if (SPTool.getUserInfo(MainActivity.this) != null) {
                        upLoadToken(SPTool.getUserInfo(MainActivity.this).body.driver_id, gettoken);
                    }
                }
            }
            break;

            case 17:
            {
                outLineDriver();
            }
            break;
            case 1008://续播声音

            {
                SPTool.putString(MainActivity.this, Constant.MyPushOrderBean, "");
                mBinding.include.tvGetMoney.setTextColor(getResources().getColor(R.color.black));
                mBinding.include.tvUnFinishedOrder.setVisibility(View.GONE);
            }
            break;


            case 1011://广告
            {
                yuYin(event.result);
            }
            break;
            case 1020://新订单
            {

                if(  SPTool.getBoolean(context,"VoiceOrderListActivityAlive")){
                    break;
                }

                yuYin("有新订单");
            }

            break;


        }
    };

    void removeOutOfDateOrder(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {

                    Log.i("802","new Thread  run() ");


                    Iterator<PushOrderBean> sListIterator = MyApplication.getOrderList().iterator();
                    while(sListIterator.hasNext()){
                        PushOrderBean bean1 = sListIterator.next();

                        Log.i("802","PushOrderBean == "+bean1.toString());


                        if (bean1  !=null && bean1.body!=null && bean1.body.oper_date!=null) {
                            try{

                                Log.i("802","PushOrderBean == "+bean1.toString());
                                Log.i("802","time  min == "+(((System.currentTimeMillis() / 1000) - (Long.parseLong(MyUtil.dateFormat(bean1.body.oper_date, 12)) / 1000)) / 60));


                                if ((((System.currentTimeMillis() / 1000) - (Long.parseLong(MyUtil.dateFormat(bean1.body.oper_date, 12)) / 1000)) / 60) >= 3) {
                                    sListIterator.remove();
                                    Log.i("802","remove ()");
                                }
                            }catch (Exception ee)
                            {
                                ee.printStackTrace();
                            }

                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    android.os.Process.killProcess(android.os.Process.myPid());
                }

                Log.i("802","OrderList().size() == "+MyApplication.getOrderList().size());


                if (MyApplication.getOrderList().size() > 0) {
                    Log.i("666", "startActivity(intentDialog)");
                    if(MainTopDialog.mainTopDialog==null|| MainTopDialog.mainTopDialog.isDestroyed()) {
                        Intent intentDialog = new Intent(MainActivity.this, MainTopDialog.class);
                        intentDialog.putExtra("PushOrderBean", MyApplication.getOrderList().get(0));
                        startActivity(intentDialog);
                        Log.i("802", "startActivity");

                    }
                }



            }

        }).start();


    }


    //////////////////////////////////////屏幕解锁监听//////////////////////////////////////

    void initScreenListener() {

        mScreenListener = new ScreenListener(this);
        mScreenListener.begin(new ScreenListener.ScreenStateListener() {
            @Override
            public void onUserPresent() {
                Log.i("602", "onUserPresent");
            }

            public void onScreenOn() {
                Log.i("onScreenOn","onScreenOn");
                if (startint>0)
                {
                    initService();
                }
                startint++;
            }

            @Override
            public void onScreenOff() {
                startint=1;
                Log.i("602","onScreenOff");
            }
        });

    }
    //////////////////////////////////////屏幕解锁监听//////////////////////////////////////


    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
        SPTool.putBoolean(this, "InBackground", true);
    }

    @Override
    protected void onDestroy() {


        if(SPTool.getInt(this,"DriverState")==1) {

            // 如果系统提供了默认的异常处理器，则交给系统去结束我们的程序，否则就由我们自己结束自己
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            @SuppressLint("WrongConstant")
            PendingIntent restartIntent = PendingIntent.getActivity(
                    getApplicationContext(), 0, intent,Intent.FLAG_ACTIVITY_NEW_TASK);
            //退出程序
            AlarmManager mgr = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
            mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 1000,
                    restartIntent); // 1秒钟后重启应用
        }



        unregisterReceiver(dbrecv);
        unregisterReceiver(netWorkChangReceiver);
//        unregisterReceiver(callgReceiver);
        unregisterReceiver(mSMSBroadcastReceiver);

        EventBus.getDefault().unregister(this);
        super.onDestroy();



    }




    UpLoadTokenModelImpl upLoadTokenModel;
    OnUpLoadTokenListener loadTokenListener;

    void upLoadToken(String id, String token) {

        if (upLoadTokenModel == null) {
            upLoadTokenModel = new UpLoadTokenModelImpl();
        }

        if (loadTokenListener == null) {
            loadTokenListener = new OnUpLoadTokenListener() {
                @Override
                public void onUpLoadTokenSuccess(String s) {

                }

                @Override
                public void onUpLoadTokenError(String errStr) {

                }
            };
        }


        UpLoadTokenParam param = new UpLoadTokenParam();
        param.id = id;
        param.token = token;

        upLoadTokenModel.upLoadToken(param, loadTokenListener);

    }


    private void initId() {
        drawerLayout = mBinding.drawerLayout;
        mBinding.include.tvNotice.setText(SPTool.getString(MainActivity.this, Constant.Notice) + "                                    " + SPTool.getString(MainActivity.this, Constant.Notice) + "                                    ");
        mBinding.include.btnAwait.setOnClickListener(this);
        mBinding.include.btnGetMoney.setOnClickListener(this);
        mBinding.include.btnOnDuty.setOnClickListener(this);
        mBinding.include.ivState.setOnClickListener(this);
        mBinding.include.llTopMenu.setOnClickListener(this);
        mBinding.include.llTopLeft.setOnClickListener(this);
        mBinding.include.llRanking.setOnClickListener(this);


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_search:
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

    }

    @Override
    public void onBackPressed() {

        Log.i("522", "进入后台");
        SPTool.putBoolean(this, "InBackground", true);
        moveTaskToBack(false);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.llRanking:

                RankingActivity.start(MainActivity.this);

                break;

            case R.id.llTopLeft://扫描二维码



                if (SPTool.getUserInfo(this) == null) {
                    ToastUtil.show(MainActivity.this, "请先登录");
                    startActivity(new Intent(MainActivity.this, LoginActivity.class));
                    return;
                }


                MyMessageActivity.start(context);


//                if(SPTool.getMyPushOrderInfo(MainActivity.this)==null){
//                    ToastUtil.show("当前未接单!");
//                    return;
//                }
//
//                Intent intent = new Intent(MainActivity.this, CaptureActivity.class);
//                                /*ZxingConfig是配置类
//                                 *可以设置是否显示底部布局，闪光灯，相册，
//                                 * 是否播放提示音  震动
//                                 * 设置扫描框颜色等
//                                 * 也可以不传这个参数
//                                 * */
//                ZxingConfig config = new ZxingConfig();
//                config.setPlayBeep(true);//是否播放扫描声音 默认为true
//                config.setShake(true);//是否震动  默认为true
//                config.setDecodeBarCode(true);//是否扫描条形码 默认为true
//                config.setReactColor(R.color.white);//设置扫描框四个角的颜色 默认为淡蓝色
//                config.setFrameLineColor(R.color.white);//设置扫描框边框颜色 默认无色
//                config.setFullScreenScan(false);//是否全屏扫描  默认为true  设为false则只会在扫描框中扫描
//                intent.putExtra(com.yzq.zxinglibrary.common.Constant.INTENT_ZXING_CONFIG, config);
//                startActivityForResult(intent, 1019);

                break;
            case R.id.llTopMenu:

                if (SPTool.getUserInfo(this) == null) {
                    ToastUtil.show(MainActivity.this, "请先登录");
                    startActivity(new Intent(MainActivity.this, LoginActivity.class));
                    return;
                }


                SettingActivity.start(MainActivity.this);
//				PersonalInformationActivity.start(MainActivity.this);
                break;

            case R.id.rl_header_bg:
                mBinding.drawerLayout.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (SPTool.getUserInfo(MainActivity.this) == null) {
                            ToastUtil.show(MainActivity.this, "请先登录");
                            startActivity(new Intent(MainActivity.this, LoginActivity.class));
                            return;
                        }

                        PersonalInformationActivity.start(MainActivity.this);
                    }
                }, 360);
                break;
            case R.id.ll_nav_trip:
                mBinding.drawerLayout.postDelayed(new Runnable() {
                    @Override
                    public void run() {

                    }
                }, 360);
                break;
            case R.id.ll_nav_money:
                mBinding.drawerLayout.postDelayed(new Runnable() {
                    @Override
                    public void run() {

                    }
                }, 360);
                break;


            case R.id.ll_nav_message: //我的订单
                mBinding.drawerLayout.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        MyMessageActivity.start(MainActivity.this);
                    }
                }, 360);
                break;

            case R.id.ll_nav_notice://系统公告

                mBinding.drawerLayout.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        MyNoticeActivity.start(MainActivity.this);
                    }
                }, 360);


                break;


            case R.id.ll_nav_update://检查更新

                SPTool.putBoolean(MainActivity.this, Constant.UserGetUpDate, true);
                showProgressDialog("请稍等");
                updateModel.checkUpdate(null, this);

                break;


            case R.id.ll_nav_guide:
                mBinding.drawerLayout.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        UserKnowActivity.start(MainActivity.this);
                    }
                }, 360);
                break;
            case R.id.ll_nav_setting:
                mBinding.drawerLayout.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        LoginActivity.start(MainActivity.this);
                    }
                }, 360);
                break;
            case R.id.btnGetMoney:

                if (SPTool.getUserInfo(this) == null) {
                    ToastUtil.show(MainActivity.this, "请先登录");
                    startActivity(new Intent(MainActivity.this, LoginActivity.class));
                    return;
                }

                if (SPTool.getMyPushOrderInfo(this) == null) {
                    ToastUtil.show(this, "没有未完成订单!");
                } else {


                    if (SPTool.getString(this, Constant.GetOrderTime).equals("")) {
                        Date date = new Date();
                        int sec = (int) (date.getTime() / 1000) - 120; // 60*60*1000
                        SPTool.putString(this, Constant.GetOrderTime, sec + "");
                    }

                    startActivity(new Intent(this, OrderDetailsActivity.class));
                }


                break;
            case R.id.btnAwait://未抢订单

                startActivity(new Intent(this, VoiceOrderListActivity.class));
                break;

            case R.id.btnOnDuty: //出车
            case R.id.ivState: //出车


                if (mBinding.include.btnOnDuty.getText().toString().trim().equals("出车")) {
                    driverOut();

                } else {//下班

                    final AlertDialog.Builder dialog = new AlertDialog.Builder(this);
                    dialog.setTitle("确认下班吗");
                    dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                            outLineDriver();
                            arg0.dismiss();

                        }
                    });
                    dialog.setNeutralButton("取消", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                            arg0.dismiss();
                        }
                    });
                    dialog.show();

                }
                break;


        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 100) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.canDrawOverlays(this)) {

                } else {
                    Toast.makeText(this, "ACTION_MANAGE_OVERLAY_PERMISSION权限已被拒绝", Toast.LENGTH_SHORT).show();
                    ;
                }
            }

        }


        if (requestCode == REQUEST_IGNORE_BATTERY_CODE) {
            if(resultCode == RESULT_OK)
            {
                Log.d("Hello World!","开启省电模式成功");
            }else if (resultCode == RESULT_CANCELED)
            {
                Toast.makeText(this, "请用户开启忽略电池优化~", Toast.LENGTH_LONG).show();
            }

        }




        // 扫描二维码/条码回传
        if (requestCode == 1019 && resultCode == RESULT_OK) {
            if (data != null) {

                String content = data.getStringExtra(com.yzq.zxinglibrary.common.Constant.CODED_CONTENT);
                scanCodeInfo(content);
            }
        }

    }

    /////////////////上传二维码信息/////////////////
    ScanCodeInfoModelImpl scanCodeInfoModel;
    OnSkanCodeInfoListener onSkanCodeInfoListener;

    void scanCodeInfo(String code) {
        if (scanCodeInfoModel == null) {
            scanCodeInfoModel = new ScanCodeInfoModelImpl();
        }
        if (onSkanCodeInfoListener == null) {
            onSkanCodeInfoListener = new OnSkanCodeInfoListener() {
                @Override
                public void onSkanCodeSuccess(String str) {
                    ToastUtil.show(MainActivity.this, str);
                }

                @Override
                public void onSkanCodeError(String errStr) {
                    ToastUtil.show(MainActivity.this, errStr);
                }
            };
        }
        scanCodeInfoModel.scanCodeInfo(code,
                SPTool.getUserInfo(MainActivity.this).body.driver_id+"",
                ""+SPTool.getMyPushOrderInfo(MainActivity.this).body.voice_tell,
                ""+SPTool.getMyPushOrderInfo(MainActivity.this).body.voice_order,
                onSkanCodeInfoListener);
    }
    /////////////////上传二维码信息/////////////////


    private void openPopupWindow(View v) {
        //防止重复按按钮
        if (popupWindow != null && popupWindow.isShowing()) {
            return;
        }
        //设置PopupWindow的View
        View view = LayoutInflater.from(this).inflate(R.layout.view_popupwindow, null);
        popupWindow = new PopupWindow(view, RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        //设置背景,这个没什么效果，不添加会报错
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        //设置点击弹窗外隐藏自身
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        //设置动画
        popupWindow.setAnimationStyle(R.style.PopupWindow);
        //设置位置
        popupWindow.showAtLocation(v, Gravity.BOTTOM, 0, navigationHeight);
        //设置消失监听
        popupWindow.setOnDismissListener(this);
        //设置PopupWindow的View点击事件
        setOnPopupViewClick(view);
        //设置背景色
        setBackgroundAlpha(0.5f);
    }

    private void setOnPopupViewClick(View view) {
        TextView tv_pick_phone, tv_pick_zone, tv_cancel;
        tv_pick_phone = (TextView) view.findViewById(R.id.tv_pick_phone);
        tv_pick_zone = (TextView) view.findViewById(R.id.tv_pick_zone);
        tv_cancel = (TextView) view.findViewById(R.id.tv_cancel);
        tv_pick_phone.setOnClickListener(this);
        tv_pick_zone.setOnClickListener(this);
        tv_cancel.setOnClickListener(this);
    }


    //设置屏幕背景透明效果
    public void setBackgroundAlpha(float alpha) {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.alpha = alpha;
        getWindow().setAttributes(lp);
    }


    @Override
    public void onUpdateSuccess(UpdateBean bean) {

        try {
            int version_num_yun = Integer.parseInt(bean.body.version_num.trim());

            Log.i("cccccc", "getVersion==" + getVersion());
            Log.i("caijiao","url == " + bean.body.version_url.trim());

            if (version_num_yun > getVersion()) {

                new UpdateManager(this).checkUpdate(false,version_num_yun,bean.body.version_url);
//                showTipDialog(2, "提示", "APP有重大更新!请升级", bean.body.version_url);
            } else {
                if (SPTool.getBoolean(MainActivity.this, Constant.UserGetUpDate)) {
                    ToastUtil.show(this, "当前已是最新版本");
                }
                SPTool.putBoolean(MainActivity.this, Constant.UserGetUpDate, false);
            }
        } catch (Exception e) {
            ToastUtil.show(this, "当前已是最新版本!");
            Log.i("cccccc", "e==" + e);
        }
        dissmissProgressDialog();


    }

    @Override
    public void onUpdateError(Object err) {
        dissmissProgressDialog();
    }

    //return 当前应用的版本号
    public int getVersion() {
        int versionCode = 1;
        try {
            PackageManager manager = getPackageManager();
            PackageInfo info = manager.getPackageInfo(this.getPackageName(), 0);
            versionCode = info.versionCode;

            if (versionCode < 1) {
                return 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("versionCode", "Exception", e);
        }
        return versionCode;
    }

    //显示进度框
    private ProgressDialog progDialog = null;//

    private void showProgressDialog(String str) {
        if (progDialog == null)
            progDialog = new ProgressDialog(this);
        progDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progDialog.setIndeterminate(false);
        progDialog.setCancelable(true);
        progDialog.setMessage(str);
        progDialog.show();
    }

    //隐藏进度框
    private void dissmissProgressDialog() {
        if (progDialog != null) {
            progDialog.dismiss();
        }
    }


    //接单
    OrderStatusModelImpl orderStatusModel = null;

    void jiedan(String statue) {
        if (orderStatusModel == null) {
            orderStatusModel = new OrderStatusModelImpl();
        }

        PushOrderBean bean = SPTool.getPushOrderInfo(MainActivity.this);
        UserInfoBean userInfoBean = SPTool.getUserInfo(MainActivity.this);


        showProgressDialog("请稍等...");
        OrderStatusParam param = new OrderStatusParam("getDrivervocie", statue,
                userInfoBean.body.driver_id,
                bean.body.voice_order,
                SPTool.getString(MainActivity.this, "Driver_Lat"),
                SPTool.getString(MainActivity.this, "Driver_Lon")
        );
        orderStatusModel.sendOrderStatus(param, MainActivity.this);
    }

    @Override
    public void onSuccess(String str) {
        Log.i("cccccc", "接单 Success==" + str);

        ToastUtil.show(MainActivity.this, "接单成功！");

        SPTool.putBoolean(MainActivity.this, Constant.OrderState, true);
        SPTool.putString(MainActivity.this, MyPushOrderBean, SPTool.getPushOrderInfo(MainActivity.this).toString());

        showGPSDialog(2, "提示", "接单成功，导航至乘客位置");
        dissmissProgressDialog();

    }

    @Override
    public void onError(String err) {
        Log.i("cccccc", "接单 Error==" + err);

        ToastUtil.show(MainActivity.this, err);
        dissmissProgressDialog();
    }
    //接单

    @Override
    public void onDismiss() {
    }


    //提示对话框
    public Dialog dialog;
    public TextView btn_one;
    public TextView btn_right;


    public interface ClickSureListener {
        public void click();
    }

    private ClickSureListener clickSureListener;

    public void showTipDialog(int type, String titleStr, String contentStr, final String version_url) {
        if (dialog == null) {
            dialog = new AlertDialog.Builder(MainActivity.this).create();
        }

        LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
        View view = (View) inflater.inflate(R.layout.dialog_base, null);
        TextView title = (TextView) view.findViewById(R.id.title);
        TextView content = (TextView) view.findViewById(R.id.content);
        btn_one = (TextView) view.findViewById(R.id.btn_one);
        LinearLayout layout = (LinearLayout) view
                .findViewById(R.id.bottom_layout);
        btn_right = (TextView) view.findViewById(R.id.btn_right);
        if (type == 1) {
            btn_one.setVisibility(View.VISIBLE);
            layout.setVisibility(View.GONE);
        } else if (type == 2) {
            btn_one.setVisibility(View.GONE);
            layout.setVisibility(View.VISIBLE);
        }
        btn_one.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });

        btn_right.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });
        title.setText(titleStr);
        content.setText(contentStr);

        view.findViewById(R.id.btn_left).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

        view.findViewById(R.id.btn_right).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //"http://ps.tupppai.com/wefun_v1.0.1.apk"
                        Uri uri = Uri.parse("http://" + version_url.trim());
                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent);
                        dialog.dismiss();
                    }
                });

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.show();
        dialog.getWindow().setContentView(view);
    }

    public void showGPSDialog(int type, String titleStr, String contentStr) {
        if (dialog == null) {
            dialog = new AlertDialog.Builder(MainActivity.this).create();
        }

        LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
        View view = (View) inflater.inflate(R.layout.dialog_base, null);
        TextView title = (TextView) view.findViewById(R.id.title);
        TextView content = (TextView) view.findViewById(R.id.content);
        btn_one = (TextView) view.findViewById(R.id.btn_one);
        LinearLayout layout = (LinearLayout) view
                .findViewById(R.id.bottom_layout);
        btn_right = (TextView) view.findViewById(R.id.btn_right);
        if (type == 1) {
            btn_one.setVisibility(View.VISIBLE);
            layout.setVisibility(View.GONE);
        } else if (type == 2) {
            btn_one.setVisibility(View.GONE);
            layout.setVisibility(View.VISIBLE);
        }
        btn_one.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });

        btn_right.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });
        title.setText(titleStr);
        content.setText(contentStr);

        view.findViewById(R.id.btn_left).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

        view.findViewById(R.id.btn_right).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //"开始导航
                        dialog.dismiss();
                    }
                });

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.show();
        dialog.getWindow().setContentView(view);
    }

    private void initGPS() {
        LocationManager locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        // 判断GPS模块是否开启，如果没有则开启
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            Toast.makeText(MainActivity.this, "请打开GPS", Toast.LENGTH_SHORT).show();
            final AlertDialog.Builder dialog = new AlertDialog.Builder(this);
            dialog.setTitle("提示");
            dialog.setMessage("请打开GPS连接");
            dialog.setPositiveButton("设置", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface arg0, int arg1) {
                    // 转到手机设置界面，用户设置GPS
                    Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                    Toast.makeText(MainActivity.this, "打开后直接点击返回键即可，若不打开返回下次将再次出现", Toast.LENGTH_SHORT).show();
                    startActivityForResult(intent, 0); // 设置完成后返回到原来的界面
                    arg0.dismiss();
                }
            });
            dialog.setNeutralButton("取消", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface arg0, int arg1) {
                    arg0.dismiss();
                }
            });
            dialog.show();
        } else {
//            searchRouteResult(startPoint, endPoint);//路径规划
            // 弹出Toast
//          Toast.makeText(TrainDetailsActivity.this, "GPS is ready",Toast.LENGTH_LONG).show();
//          // 弹出对话框
//          new AlertDialog.Builder(this).setMessage("GPS is ready").setPositiveButton("OK", null).show();
        }
    }


    ///////////////////出车////////出车///////////出车//////////////
    DriverOutModelImpl outModel;

    void driverOut() {

        if (SPTool.getUserInfo(this) == null) {
            ToastUtil.show(MainActivity.this, "请先登录");
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
            return;
        }

        if (outModel == null) {
            outModel = new DriverOutModelImpl();
        }

        DriverOutParam param;
        param = new DriverOutParam("driverout", SPTool.getUserInfo(this).body.driver_id);
        outModel.driverOut(param, this);

    }

    @Override
    public void onDriverOutSuccess(DriverOutBean bean) {


        Intent service = new Intent(this,LocalService.class);
        service.setAction("MainActivity.START");
        service.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        service.putExtra("CMD",1);
        startService(service);

        SPTool.putInt(MainActivity.this,Constant.FinishOrderTimeStr,bean.body.orderend_time);
        mBinding.include.ivState.setBackground(getResources().getDrawable(R.drawable.icon_go_off));
        mBinding.include.btnOnDuty.setText("下班");
        SPTool.putString(MainActivity.this, Constant.Notice, bean.body.notice_desc);
        SPTool.putInt(MainActivity.this, Constant.DriverState, 1);
        MyApplication.getInstance().PlayDriverOnLine();

        mBinding.include.tvNotice.setText(SPTool.getString(MainActivity.this, Constant.Notice));

        try {
            if(bean.body.driver_work.trim().length()>1){
                dialogChoice(bean.body.driver_work.trim());
            }else {
                Log.e("dialogChoice","无顶班车辆");
            }
        }catch (Exception e){
            Log.e("dialogChoice",e.toString());
        }

        new Handler().postDelayed(
                new Runnable() {
                    @Override
                    public void run() {

                        initService();
                    }
                },2000);


    }

    @Override
    public void onDriverOutError(String errStr) {
        ToastUtil.show(this, errStr);
    }
    ///////////////////出车////////出车///////////出车//////////////


    //////////////////////////////司机下线//////////////////////////
    OutLineDriverModelImpl outLineDriverModel;

    void outLineDriver() {
        if (outLineDriverModel == null) {
            outLineDriverModel = new OutLineDriverModelImpl();
        }

        if(SPTool.getUserInfo(this)==null){
            return;
        }

        OutLineDriverParam param;
        param = new OutLineDriverParam("outlinedriver", SPTool.getUserInfo(this).body.driver_id);
        outLineDriverModel.outLineDriver(param, this);


    }

    private boolean isIgnoringBatteryOptimizations(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            String packageName = getPackageName();
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            return pm.isIgnoringBatteryOptimizations(packageName);
        }
        return false;
    }

    private void gotoSettingIgnoringBatteryOptimizations() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                Intent intent = new Intent();

                String packageName = getPackageName();
                intent.setAction(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                // intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                intent.setData(Uri.parse("package:" + packageName));
                startActivityForResult(intent, REQUEST_IGNORE_BATTERY_CODE);
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }

    private void setpoweroption() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                Intent intent = new Intent();

                String packageName = getPackageName();
                intent.setAction(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                // intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                intent.setData(Uri.parse("package:" + packageName));
                startActivityForResult(intent, REQUEST_IGNORE_BATTERY_CODE);
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }



    @Override
    public void onOutLineDriverSuccess(OutLineDriverBean bean) {


        mBinding.include.btnOnDuty.setText("出车");
        SPTool.putInt(MainActivity.this,Constant.DriverState,0);
        Intent location = new Intent(this,LocationService.class);
        location.putExtra("CMD",2);
        stopService(location);


        Intent RomoteServiceun = new Intent(this,RomoteService.class);
        RomoteServiceun.putExtra("CMD",3);
        startService(RomoteServiceun);

        Intent LocalService = new Intent(this,LocalService.class);
        LocalService.putExtra("CMD",2);
        startService(LocalService);

        MyApplication.getInstance().driveroffLine();

    }

    @Override
    public void onOutLineDriverError(String errStr) {
        ToastUtil.show(this, errStr);
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        manager.restartPackage(getPackageName());
    }
    //////////////////////////////司机下线//////////////////////////


    //////////////////////////////司机版本//////////////////////////
    UpdateDriverVerModelImpl DriverModelVer;

    void onUpdateDriverver() {

        if (SPTool.getUserInfo(this) == null) {
            return;
        }

        if (DriverModelVer == null) {
            DriverModelVer = new UpdateDriverVerModelImpl();
        }

        String strinfo=Build.MANUFACTURER+Build.MODEL+Build.VERSION.RELEASE+Build.CPU_ABI+Build.VERSION.SDK_INT+getVersion();

        strinfo=strinfo.replaceAll("\\.","-");
        strinfo=strinfo.replaceAll("-","");
        strinfo=strinfo.replaceAll(" ","");
        Log.i("strinfo",strinfo);

        UpdateDriverVerParam param;
        param = new UpdateDriverVerParam("updatedriverver", SPTool.getUserInfo(this).body.driver_id, ""+strinfo);
        DriverModelVer.onUpdateDriverver(param, this);
    }

    @Override
    public void onUpdateDriverVerSuccess(UpdateDriverBean bean) {

    }

    @Override
    public void onUpdateDriververError(String errStr) {

    }
    //////////////////////////////司机版本//////////////////////////


    //////////////////////////////上传定位返回结果//////////////////////////
    @Override
    public void onPositionSuccess(String str) {
        Log.i("cccccc", "onPositionSuccess=" + str);
    }

    @Override
    public void onPositionError(Object err) {
        Log.i("cccccc", "onPosition  err=" + err.toString());
    }
    //////////////////////////////上传定位返回结果//////////////////////////


    //////////////////////////////获取别的司机接单位置//////////////////////////
    private GetPostUrl getPost = GetPostUrl.getGetPost();
    private HttpConnectionUtil httpConnect = HttpConnectionUtil.getHttp();

    void setGetOrderLocation(final TextView tv, final String lon, final String lat) {


        new Thread() {
            @Override
            public void run() {
                try {

                    String location = lon + "," + lat;
                    String url = "http://restapi.amap.com/v3/geocode/regeo?output=JSON&location=" + location
                            + "&key=d6a0cb18838da2ebb137e2a800e478db&radius=0&extensions=base";
                    String locationStr = getPost.get(url);
//                    String locationStr = getPost.get("http://restapi.amap.com/v3/geocode/regeo?output=JSON&location=116.481488,39.990464&key=d6a0cb18838da2ebb137e2a800e478db&radius=0&extensions=base");

                    Log.i("423", "url == " + url);
                    Log.i("423", "---------------------------------------------------------------");
                    SPTool.putString(MainActivity.this, Constant.ComplaintOrderBean, locationStr);
                    Log.i("423", locationStr);
                    Log.i("423", "---------------------------------------------------------------");

                    final OrderLocationBean orderLocationBean = new Gson().fromJson(locationStr, OrderLocationBean.class);

                    Log.i("423", "   formatted_address== " + orderLocationBean.regeocode.formatted_address);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // refresh ui 的操作代码
                            tv.setText(orderLocationBean.regeocode.formatted_address);
                        }
                    });


                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.start();


    }

    @Override
    public void onGetLocationSuccess(OrderLocationBean bean) {
        ToastUtil.show(this, "OrderLocationBean");
    }

    @Override
    public void onGetLocationError(String errStr) {
        ToastUtil.show(this, errStr);
    }
    //////////////////////////////获取别的司机接单位置//////////////////////////


    ////////////////////////////获取司机状态/////////////////////////////////
    DriverOrderStateModelImpl getStateModel;
    OnDriverOrderStateListener listener;

    void getDriverOrderState() {
        if (getStateModel == null) {
            getStateModel = new DriverOrderStateModelImpl();
        }

        if (SPTool.getUserInfo(this) == null) {
            return;
        }
        if (listener == null) {
            listener = new OnDriverOrderStateListener() {
                @Override
                public void onDriverOrderStateSuccess(GetDriverOrderStateBean bean) {// 0 未出车     1 出车

                    mBinding.include.btnOnDuty.setText("下班");
                    mBinding.include.ivState.setBackground(getResources().getDrawable(R.drawable.icon_go_off));
                    mBinding.include.tvRanking.setText(bean.body.driver_rank);

                    //////////////////////更新本地排名//////////////////////
                    UserInfoBean userInfoBean = SPTool.getUserInfo(MainActivity.this);
                    userInfoBean.body.driver_rank = bean.body.driver_rank;
                    SPTool.putContent(MainActivity.this, Constant.UserInfoBean, userInfoBean.toString());
                    //////////////////////更新本地排名//////////////////////

                    mBinding.include.tvTotal.setText(bean.body.count);
                    mBinding.include.tvComplaint.setText(bean.body.complaint_count);



                    mBinding.include.tvPastOrder.setText(bean.body.lostorder_count);
                    if(bean.body.lostorder_count.equals("0")){
                        mBinding.include.tvPastOrder.setVisibility(View.INVISIBLE);
                    }else {
                        mBinding.include.tvPastOrder.setVisibility(View.VISIBLE);
                    }


                    if (bean.body.out_state.equals("0")) {
                        mBinding.include.btnOnDuty.setText("出车");
                        mBinding.include.ivState.setBackground(getResources().getDrawable(R.drawable.icon_run));
                        SPTool.putInt(MainActivity.this, Constant.DriverState, 0);
                    } else {
                        mBinding.include.btnOnDuty.setText("下班");
                        mBinding.include.ivState.setBackground(getResources().getDrawable(R.drawable.icon_go_off));
                        SPTool.putInt(MainActivity.this, Constant.DriverState, 1);

                        Intent service = new Intent(MainActivity.this,LocalService.class);
                        service.setAction("MainActivity.START");
                        service.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        service.putExtra("CMD",1);
                        startService(service);

                    }

                    if (bean.body.voice_tell != null) {
                        PushOrderBean pushOrderBean;
                        pushOrderBean = new PushOrderBean();
                        pushOrderBean.body = new PushOrderBean.BodyBean();
                        pushOrderBean.body.voice_tell = bean.body.voice_tell.trim();
                        pushOrderBean.body.voice_file = bean.body.voice_file.trim();
                        pushOrderBean.body.voice_order = bean.body.voice_order.trim();
                        pushOrderBean.body.voice_name = bean.body.voice_name.trim();
                        pushOrderBean.body.oper_date = bean.body.oper_date.trim();
                        pushOrderBean.body.voice_state = bean.body.voice_state.trim();
                        SPTool.putString(MainActivity.this, Constant.MyPushOrderBean, pushOrderBean.toString());
                        Log.i("425", "pushOrderBean  ==  " + pushOrderBean.toString());
                        mBinding.include.tvGetMoney.setTextColor(getResources().getColor(R.color.red));
                        mBinding.include.tvUnFinishedOrder.setVisibility(View.VISIBLE);

                    } else {
                        SPTool.putString(MainActivity.this, Constant.MyPushOrderBean, "");
                        mBinding.include.tvGetMoney.setTextColor(getResources().getColor(R.color.black));
                        mBinding.include.tvUnFinishedOrder.setVisibility(View.GONE);

                    }

                }

                @Override
                public void onDriverOrderStateError(String errStr) {

                }
            };
        }

        getStateModel.getDriverOrderState(SPTool.getUserInfo(this).body.driver_id, listener);


    }
    ////////////////////////////获取司机状态/////////////////////////////////


    public class DownBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(intent.getAction())) {

                if (SPTool.getPushOrderInfo(context) != null) {
                    if (SPTool.getPushOrderInfo(context).body != null) {
                        VoiceUtils.with(context).playAudio(SPTool.getPushOrderInfo(context).body.voice_name.trim());
                    }
                }

            }
        }
    }

    public class startActivityBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {

            if (".myBroadcastAction".equals(intent.getAction())) {
                Log.i("522", "startActivityBroadcastReceiver");
//                Intent intent2 = new Intent(getApplicationContext(), MainActivity.class);
//                intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
//                startActivity(intent2);
            }
        }
    }


    ///////////////////////////////获取运行时权限/////////////////////////////
    final int PER_REQUEST_CODE = 0;

    private void getLoginIMSI() {

        performRequestPermissions(getString(R.string.permission_imei),
                new String[]{
                        Manifest.permission.READ_PHONE_STATE,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.READ_PHONE_STATE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.WAKE_LOCK,
                        Manifest.permission.DISABLE_KEYGUARD,
                        Manifest.permission.RECEIVE_BOOT_COMPLETED,
                        Manifest.permission.SYSTEM_ALERT_WINDOW,
                }
                , PER_REQUEST_CODE,
                new PermissionResultListener() {
                    @Override
                    public void onPermissionDenied() {

                    }

                    @Override
                    public void onPermissionGranted() {

                        try {


                        } catch (Exception E) {
                            E.printStackTrace();
                        }

                    }
                });


    }

    //请求码
    private int mRequestCode;
    //运行时权限接口
    private PermissionResultListener mListener;

    protected void performRequestPermissions(String desc, String[] permissions,
                                             int requestCode,
                                             PermissionResultListener listener) {
        if (permissions == null || permissions.length == 0) {
            return;
        }
        mRequestCode = requestCode;
        mListener = listener;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkEachSelfPermission(permissions)) {// 检查是否声明了权限
                requestEachPermissions(desc, permissions, requestCode);
            } else {// 已经申请权限
                if (mListener != null) {
                    mListener.onPermissionGranted();
                }
            }
        } else {
            if (mListener != null) {
                mListener.onPermissionGranted();
            }
        }
    }

    /**
     * 检察每个权限是否申请
     *
     * @param permissions
     * @return true 需要申请权限,false 已申请权限
     */
    private boolean checkEachSelfPermission(String[] permissions) {
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) !=
                    PackageManager.PERMISSION_GRANTED) {
                return true;
            }
        }
        return false;
    }

    private void requestEachPermissions(String desc, String[] permissions, int requestCode) {
        if (shouldShowRequestPermissionRationale(permissions)) {// 需要再次声明
            showRationaleDialog(desc, permissions, requestCode);
        } else {
            ActivityCompat.requestPermissions(MainActivity.this, permissions, requestCode);
        }
    }


    /**
     * 再次申请权限时，是否需要声明
     *
     * @param permissions
     * @return
     */
    private boolean shouldShowRequestPermissionRationale(String[] permissions) {
        for (String permission : permissions) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 弹出声明的 Dialog
     *
     * @param desc
     * @param permissions
     * @param requestCode
     */
    private void showRationaleDialog(String desc, final String[] permissions,
                                     final int requestCode) {
        final android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.tips))
                .setMessage(desc)
                .setPositiveButton(getResources().getString(R.string.sure),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                ActivityCompat.requestPermissions(MainActivity.this,
                                        permissions, requestCode);
                            }
                        })
                .setNegativeButton(getResources().getString(R.string.cancel),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        })
                .setCancelable(false)
                .show();
    }
    ///////////////////////////////获取运行时权限/////////////////////////////

    private void initService() {


        //不进行任何特殊处理,在原生系统中可以实现
//	  Intent intent = new Intent(this,AlarmReceiver.class);
//	  PendingIntent sender = PendingIntent.getBroadcast(this,0,intent,0);
//	  Calendar calendar = Calendar.getInstance();
//	  calendar.setTimeInMillis(System.currentTimeMillis());
//	  calendar.add(Calendar.SECOND,5);
//	  AlarmManager manager = (AlarmManager) getSystemService(ALARM_SERVICE);
//	  manager.set(AlarmManager.RTC_WAKEUP,calendar.getTimeInMillis(),sender);
//	  manager.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime()+5000, 5000, sender);



        //通过AIDL实现双进程守护
        Intent service = new Intent(this,LocalService.class);
        service.setAction("MainActivity.START");
        service.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        service.putExtra("CMD",1);
        startService(service);

        Intent remoteService = new Intent(this,RomoteService.class);
        startService(remoteService);

        Intent locationsv = new Intent(this, LocationService.class);
        startService(locationsv);



    }










    //////////////////////////单选
    String carNo = "";
    private void dialogChoice( String  str) {


         final String items[] = str.split("\\s+");
        carNo = items[0];
        AlertDialog.Builder builder = new AlertDialog.Builder(this, 3);
        builder.setTitle("选择代班车辆");
//        builder.setIcon(R.drawable.logo1);
        builder.setCancelable(false);
        builder.setSingleChoiceItems(items, 0,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        carNo = items[which];
                    }
                });
        builder.setPositiveButton("请求车主验证码", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                showProgressDialog("请稍等");
                getCodeForUpdateCarNo(carNo);
                dialog.dismiss();
            }
        });

        final AlertDialog dialog = builder.create();
        dialog.show();
        try {

            int dividerId = dialog.getContext().getResources().getIdentifier("android:id/titleDivider", null, null);
            if (dividerId != 0) {
                View divider = dialog.findViewById(dividerId);
                divider.setBackgroundColor(MainActivity.this.getResources().getColor(R.color.black));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, 2);
                divider.setLayoutParams(lp);
            }
            Field mAlert = AlertDialog.class.getDeclaredField("mAlert");
            mAlert.setAccessible(true);
            Object mAlertController = mAlert.get(dialog);
            //通过反射修改title字体大小和颜色
            Field mTitle = mAlertController.getClass().getDeclaredField("mTitleView");
            mTitle.setAccessible(true);
            TextView mTitleView = (TextView) mTitle.get(mAlertController);
            mTitleView.setTextSize(14);
            mTitleView.setTextColor(Color.BLACK);
            //通过反射修改message字体大小和颜色
            Field mMessage = mAlertController.getClass().getDeclaredField("mMessageView");
            mMessage.setAccessible(true);
            TextView mMessageView = (TextView) mMessage.get(mAlertController);
            mMessageView.setTextSize(18);
            mMessageView.setTextColor(Color.GREEN);
        } catch (IllegalAccessException e1) {
            e1.printStackTrace();
        } catch (NoSuchFieldException e2) {
            e2.printStackTrace();
        }
    }


    ////////////////////////////可输入的对框框////////////////////////////
    private void dialogEditText(String str, final int code) {
        final EditText editText = new EditText(this);
        editText.setHint("点击输入验证码");
        editText.setInputType(EditorInfo.TYPE_CLASS_NUMBER);
        editText.setGravity(Gravity.CENTER);
        editText.setCursorVisible(false);
        editText.setBackground(null);
        editText.setHighlightColor(getResources().getColor(R.color.black));
        final AlertDialog.Builder builder = new AlertDialog.Builder(this,3);
        builder.setCancelable(false);
        builder.setTitle("请输入车主提供的验证码");
//        builder.setMessage(str);
        builder.setView(editText);
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        final AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(editText.getText())){
                    Toast.makeText(MainActivity.this, "请输入验证码", Toast.LENGTH_LONG).show();
                }else {

                    Log.i("验证码",editText.getText().toString().trim());

                    if(editText.getText().toString().trim().equals(""+code)){
                        showProgressDialog("请稍等");
                        driverOutByCarInfo(carNo);
                        dialog.dismiss();
                    }else {
                        Toast.makeText(MainActivity.this, "验证码错误", Toast.LENGTH_LONG).show();
                    }


                }
            }
        });

        try {

            int dividerId = dialog.getContext().getResources().getIdentifier("android:id/titleDivider", null, null);
            if (dividerId != 0) {
                View divider = dialog.findViewById(dividerId);
                divider.setBackgroundColor(MainActivity.this.getResources().getColor(R.color.transparent));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, 2);
                divider.setLayoutParams(lp);
            }
            Field mAlert = AlertDialog.class.getDeclaredField("mAlert");
            mAlert.setAccessible(true);
            Object mAlertController = mAlert.get(dialog);
            //通过反射修改title字体大小和颜色
            Field mTitle = mAlertController.getClass().getDeclaredField("mTitleView");
            mTitle.setAccessible(true);
            TextView mTitleView = (TextView) mTitle.get(mAlertController);
            mTitleView.setTextSize(18);
            mTitleView.setTextColor(Color.BLACK);
            //通过反射修改message字体大小和颜色
            Field mMessage = mAlertController.getClass().getDeclaredField("mMessageView");
            mMessage.setAccessible(true);
            TextView mMessageView = (TextView) mMessage.get(mAlertController);
            mMessageView.setTextSize(18);
            mMessageView.setTextColor(Color.GREEN);
        } catch (IllegalAccessException e1) {
            e1.printStackTrace();
        } catch (NoSuchFieldException e2) {
            e2.printStackTrace();
        }


    }
    ////////////////////////////可输入的对框框////////////////////////////


    ////////////////////获取更新车牌验证码////////////////////
    GetIdentifyingCodeModelImpl identifyingCodeModel;
    OnCodeForUpdateCarNoListener onCodeForUpdateCarNoListener;
    void getCodeForUpdateCarNo(String car_no) {
		if(identifyingCodeModel == null){
            identifyingCodeModel = new GetIdentifyingCodeModelImpl();
        }

        if(onCodeForUpdateCarNoListener == null){
            onCodeForUpdateCarNoListener = new OnCodeForUpdateCarNoListener() {
                @Override
                public void onCodeSuccess(GetCodeForUpdateCarNoBean bean) {
                    dissmissProgressDialog();
                    dialogEditText(carNo,bean.body.num);
                }

                @Override
                public void onCodeError(String errStr) {
                    dissmissProgressDialog();
                    Toast.makeText(MainActivity.this, errStr, Toast.LENGTH_LONG).show();
                }
            };
        }


        try {
            identifyingCodeModel.getCodeForUpdateCarNo( URLEncoder.encode(carNo, "utf-8"),onCodeForUpdateCarNoListener);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

    }
    ////////////////////获取更新车牌验证码////////////////////



    ////////////////////更新车牌////////////////////
    UpDateCarNoModelImpl upDateCarNoModel;
    OnUpDateCarNoListener onUpDateCarNoListener;
    void driverOutByCarInfo(final String car_no){
        if(upDateCarNoModel == null){
            upDateCarNoModel = new UpDateCarNoModelImpl();
        }

        if(onUpDateCarNoListener == null){
            onUpDateCarNoListener =  new OnUpDateCarNoListener() {
                @Override
                public void onUpDateCarNoSuccess(String str) {
                    Toast.makeText(MainActivity.this, str, Toast.LENGTH_LONG).show();
                    SPTool.putString(MainActivity.this,Constant.CarNo,car_no);
                    dissmissProgressDialog();
                }

                @Override
                public void onUpDateCarNoError(String errStr) {
                    Toast.makeText(MainActivity.this, errStr, Toast.LENGTH_LONG).show();
                    dissmissProgressDialog();
                }
            };
        }



        try {
            UpDateCarNoParam param= new UpDateCarNoParam();
            param.method = "driveroutbycar";
            param.driver_id = SPTool.getUserInfo(MainActivity.this).body.driver_id;
            param.car_no = URLEncoder.encode(car_no, "utf-8");
            upDateCarNoModel.driverOutByCarInfo(param,onUpDateCarNoListener);

        } catch (Exception e) {
            e.printStackTrace();
        }



    }
    ////////////////////更新车牌////////////////////



    MiniTTS tts;//语音播报
    void  yuYin (final String str){


        performRequestPermissions(getString(R.string.permission_imei),
                new String[]{
                        Manifest.permission.MODIFY_AUDIO_SETTINGS
                }
                , PER_REQUEST_CODE,
                new PermissionResultListener() {
                    @Override
                    public void onPermissionDenied() {

                    }

                    @Override
                    public void onPermissionGranted() {

                        try {

                            tts = new MiniTTS(context);
                            tts.initPermission().initTTs();
                            tts.speak(str);
//                                    tts.speak("测试2");

                        }catch (Exception E)
                        {
                            E.printStackTrace();
                        }

                    }
                });
    }



//    final protected int PER_REQUEST_CODE =0;
//    //请求码
//    private int mRequestCode;
//    //运行时权限接口
//    private PermissionResultListener mListener;
//    protected void performRequestPermissions(String desc, String[] permissions,
//                                             int requestCode,
//                                             PermissionResultListener listener) {
//        if (permissions == null || permissions.length == 0) {
//            return;
//        }
//        mRequestCode = requestCode;
//        mListener = listener;
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            if (checkEachSelfPermission(permissions)) {// 检查是否声明了权限
//                requestEachPermissions(desc, permissions, requestCode);
//            } else {// 已经申请权限
//                if (mListener != null) {
//                    mListener.onPermissionGranted();
//                }
//            }
//        } else {
//            if (mListener != null) {
//                mListener.onPermissionGranted();
//            }
//        }
//    }
//
//
//
//    /**
//     * 检察每个权限是否申请
//     *
//     * @param permissions
//     * @return true 需要申请权限,false 已申请权限
//     */
//    private boolean checkEachSelfPermission(String[] permissions) {
//        for (String permission : permissions) {
//            if (ContextCompat.checkSelfPermission(this, permission) !=
//                    PackageManager.PERMISSION_GRANTED) {
//                return true;
//            }
//        }
//        return false;
//    }
//
//    private void requestEachPermissions(String desc, String[] permissions, int requestCode) {
//        if (shouldShowRequestPermissionRationale(permissions)) {// 需要再次声明
//            showRationaleDialog(desc, permissions, requestCode);
//        } else {
//            ActivityCompat.requestPermissions(MainTopDialog.this, permissions, requestCode);
//        }
//    }
//
//
//    /**
//     * 再次申请权限时，是否需要声明
//     *
//     * @param permissions
//     * @return
//     */
//    private boolean shouldShowRequestPermissionRationale(String[] permissions) {
//        for (String permission : permissions) {
//            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
//                return true;
//            }
//        }
//        return false;
//    }
//
//    /**
//     * 弹出声明的 Dialog
//     *
//     * @param desc
//     * @param permissions
//     * @param requestCode
//     */
//    private void showRationaleDialog(String desc, final String[] permissions,
//                                     final int requestCode) {
//        final android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
//        builder.setTitle(getString(R.string.tips))
//                .setMessage(desc)
//                .setPositiveButton(getResources().getString(R.string.sure),
//                        new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialogInterface, int i) {
//                                ActivityCompat.requestPermissions(MainTopDialog.this,
//                                        permissions, requestCode);
//                            }
//                        })
//                .setNegativeButton(getResources().getString(R.string.cancel),
//                        new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialogInterface, int i) {
//                                dialogInterface.dismiss();
//                            }
//                        })
//                .setCancelable(false)
//                .show();
//    }


}