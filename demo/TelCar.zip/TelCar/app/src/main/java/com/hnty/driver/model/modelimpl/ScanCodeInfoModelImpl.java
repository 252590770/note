package com.hnty.driver.model.modelimpl;

import android.util.Log;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.BaseBean;
import com.hnty.driver.inter.OnSkanCodeInfoListener;
import com.hnty.driver.util.NetworkUtil;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by L on 2018/1/12.
 */

public class ScanCodeInfoModelImpl{


    public void scanCodeInfo(String card_num ,String driver_id,String voice_tell,String voice_order, final OnSkanCodeInfoListener listener) {


        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
//            Toast.makeText(App.getContext(), "没有网络O", Toast.LENGTH_SHORT).show();
            listener.onSkanCodeError( "没有网络o");
            return;
        }

        Log.i("cccccc","param.toString()=="+card_num.toString());

        MyApplication.getAPI().scanCodeInfo("skanCode",""+card_num ,""+driver_id,""+voice_tell,""+voice_order )
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<BaseBean>() {
                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull BaseBean bean) {


                        try {
                            if(bean.code==1){
                                listener.onSkanCodeSuccess(bean.msg);
                            }else{
                                listener.onSkanCodeError(bean.msg);
                            }

                        }catch (Exception e){
                            listener.onSkanCodeError(  "数据错误"); ;
                        }
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        //listener.onError(new Exception("数据错误"));
                        Log.i("ccccccc","onError="+e.toString());
                    }

                    @Override
                    public void onComplete() {
                    }
                });

    }



}
