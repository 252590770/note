package com.hnty.driver.activity;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Handler;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.hnty.driver.MainActivity;
import com.hnty.driver.R;
import com.hnty.driver.application.MyApplication;
import com.hnty.driver.base.BaseActivity;
import com.hnty.driver.databinding.ActivityPersonalInformationBinding;
import com.hnty.driver.entity.LoginParam;
import com.hnty.driver.entity.UserInfoBean;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.impl.PermissionResultListener;
import com.hnty.driver.inter.OnLoginListener;
import com.hnty.driver.model.modelimpl.LoginModelImpl;
import com.hnty.driver.net.UploadFileThread;
import com.hnty.driver.util.CameraDialog;
import com.hnty.driver.util.GlideImagePickerLoader;
import com.hnty.driver.util.MsgBox;
import com.hnty.driver.util.SPTool;
import com.hnty.driver.util.ToastUtil;
import com.hnty.driver.view.CircleImageView;
import com.lzy.imagepicker.ImagePicker;
import com.lzy.imagepicker.view.CropImageView;
import com.yalantis.ucrop.UCrop;
import com.yalantis.ucrop.UCropActivity;

import java.io.File;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import jp.wasabeef.glide.transformations.CropCircleTransformation;

import static com.hnty.driver.R.styleable.View;

/**
 * Created by Administrator on 2017/4/26.
 */

public class PersonalInformationActivity extends BaseActivity<ActivityPersonalInformationBinding> implements View.OnClickListener
,CameraDialog.OnActionCameraSelect,DialogInterface.OnCancelListener,OnLoginListener
{
    private static final int IMAGE_PICKER = 1;
    private Context context;
    private String etNameStr,etPsdStr,etPsdTwoStr;
    private static final int PER_REQUEST_CODE = 2;
    private Uri resultUri;
    private String filePath;

    private SimpleDateFormat sdf = new SimpleDateFormat("yyyMMddHHmmss");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_information);
        setTitle("个人信息");
        context = this;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//来保持屏幕高亮
        showContentView();
        bindingView.btnSendHttp.setOnClickListener(this);
//        bindingView.ivHead.setOnClickListener(this);
    }


    @Override
    protected void onResume() {
        super.onResume();

        getIMSI();

    }

    /**
     * 设置用户头像
     */
    protected void setImageUserIcon() {

        try {
            UserInfoBean getUserInfo= SPTool.getUserInfo(this);

            if(getUserInfo.body.driver_img.equals("")){
                return;
            }





        }catch (Exception e){



        }


    }



    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivHead:  //设置头像
                CameraDialog.showSheet(this, this, this);
                break;


            case R.id.btnSendHttp:


                SPTool.putBoolean(this,Constant.IsLogin,false);
                SPTool.putContent(this, Constant.UserInfoBean,"");
                startActivity(new Intent(this,MainActivity.class));

//                if(filePath==null){
//                    finish();
//                    return;
//                }
//
//                if(getStringOK()){
//                    uploadUserIcon(filePath);
//                }


                break;

        }
    }

    //判断是否填写正确
    private boolean getStringOK() {
        // TODO Auto-generated method stub

        boolean ok = true;

        etNameStr = bindingView.etName.getText().toString().trim();

        if(etNameStr.length()==0){

            ToastUtil.show(this, "请输入姓名");
            ok = false;

        }else  if(etPsdStr.length()==0) {

            ToastUtil.show(this, "请输入密码");
            ok = false;

        }else  if(etPsdTwoStr.length()==0) {

            ToastUtil.show(this, "请确认密码");
            ok = false;

        }else  if(!etPsdStr.equals(etPsdTwoStr)) {

            ToastUtil.show(this, "两次密码不一致");
            ok = false;

        }
        return ok;
    }












    private void initImagePicker()
    {
        ImagePicker imagePicker = ImagePicker.getInstance();
        imagePicker.setImageLoader(new GlideImagePickerLoader());   //设置图片加载器
        imagePicker.setShowCamera(true);  //显示拍照按钮
        imagePicker.setCrop(true);        //允许裁剪（单选才有效）
        imagePicker.setSaveRectangle(true); //是否按矩形区域保存
//        imagePicker.setSelectLimit(9);    //选中数量限制
        imagePicker.setMultiMode(false); //单选
        imagePicker.setStyle(CropImageView.Style.CIRCLE);  //裁剪框的形状
        imagePicker.setFocusWidth(800);   //裁剪框的宽度。单位像素（圆形自动取宽高最小值）
        imagePicker.setFocusHeight(800);  //裁剪框的高度。单位像素（圆形自动取宽高最小值）
        imagePicker.setOutPutX(1000);//保存文件的宽度。单位像素
        imagePicker.setOutPutY(1000);//保存文件的高度。单位像素
    }

    public static void start(Context mContext) {
        Intent intent = new Intent(mContext, PersonalInformationActivity.class);
        mContext.startActivity(intent);
    }


//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (resultCode == ImagePicker.RESULT_CODE_ITEMS) {
//            if (data != null && requestCode == IMAGE_PICKER) {
//                ArrayList<ImageItem> images = (ArrayList<ImageItem>) data.getSerializableExtra(ImagePicker.EXTRA_RESULT_ITEMS);
////                showHeadImg(images.get(0).path);
//            } else {
//                Toast.makeText(this, "没有数据", Toast.LENGTH_SHORT).show();
//            }
//        }
//    }
//    private void showHeadImg(String url)
//    {
//        Glide.with(this).load(url).into(bindingView.profileImage);
//        Glide.with(this).load(url)
//                .bitmapTransform(new BlurTransformation(getApplicationContext()))
//                .into(bindingView.bgImage);
//    }

    @Override
    public void onCameraClick(int whichButton) {
        switch (whichButton) {
            case 0: {//拍照

                break;
            }
            case 1: {//从相册选择

                break;
            }
        }
    }

    @Override
    public void onCancel(DialogInterface dialog) {

    }







    //请求码
    private int mRequestCode;
    //运行时权限接口
    private PermissionResultListener mListener;
    protected void performRequestPermissions(String desc, String[] permissions,
                                             int requestCode,
                                             PermissionResultListener listener) {
        if (permissions == null || permissions.length == 0) {
            return;
        }
        mRequestCode = requestCode;
        mListener = listener;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkEachSelfPermission(permissions)) {// 检查是否声明了权限
                requestEachPermissions(desc, permissions, requestCode);
            } else {// 已经申请权限
                if (mListener != null) {
                    mListener.onPermissionGranted();
                }
            }
        } else {
            if (mListener != null) {
                mListener.onPermissionGranted();
            }
        }
    }


    private boolean checkEachSelfPermission(String[] permissions) {
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) !=
                    PackageManager.PERMISSION_GRANTED) {
                return true;
            }
        }
        return false;
    }


    private void requestEachPermissions(String desc, String[] permissions, int requestCode) {
        if (shouldShowRequestPermissionRationale(permissions)) {// 需要再次声明
            showRationaleDialog(desc, permissions, requestCode);
        } else {
            ActivityCompat.requestPermissions(PersonalInformationActivity.this, permissions, requestCode);
        }
    }


    private boolean shouldShowRequestPermissionRationale(String[] permissions) {
        for (String permission : permissions) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                return true;
            }
        }
        return false;
    }


    private void showRationaleDialog(String desc, final String[] permissions,
                                     final int requestCode) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.tips))
                .setMessage(desc)
                .setPositiveButton(getResources().getString(R.string.sure),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                ActivityCompat.requestPermissions(PersonalInformationActivity.this,
                                        permissions, requestCode);
                            }
                        })
                .setNegativeButton(getResources().getString(R.string.cancel),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        })
                .setCancelable(false)
                .show();
    }


    private void initUCrop(Uri uri) {
        //Uri destinationUri = RxPhotoTool.createImagePathUri(this);

        SimpleDateFormat timeFormatter = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.CHINA);
        long time = System.currentTimeMillis();
        String imageName = timeFormatter.format(new Date(time));

        Uri destinationUri = Uri.fromFile(new File(getCacheDir(), imageName + ".jpeg"));

        UCrop.Options options = new UCrop.Options();
        //设置裁剪图片可操作的手势
        options.setAllowedGestures(UCropActivity.SCALE, UCropActivity.ROTATE, UCropActivity.ALL);
        //设置隐藏底部容器，默认显示
        //options.setHideBottomControls(true);
        //设置toolbar颜色
        options.setToolbarColor(ActivityCompat.getColor(this, R.color.colorPrimary));
        //设置状态栏颜色
        options.setStatusBarColor(ActivityCompat.getColor(this, R.color.colorPrimaryDark));

        //开始设置
        //设置最大缩放比例
        options.setMaxScaleMultiplier(5);
        //设置图片在切换比例时的动画
        options.setImageToCropBoundsAnimDuration(666);
        //设置裁剪窗口是否为椭圆
        //options.setOvalDimmedLayer(true);
        //设置是否展示矩形裁剪框
        // options.setShowCropFrame(false);
        //设置裁剪框横竖线的宽度
        //options.setCropGridStrokeWidth(20);
        //设置裁剪框横竖线的颜色
        //options.setCropGridColor(Color.GREEN);
        //设置竖线的数量
        //options.setCropGridColumnCount(2);
        //设置横线的数量
        //options.setCropGridRowCount(1);

        UCrop.of(uri, destinationUri)
                .withAspectRatio(1, 1)
                .withMaxResultSize(1000, 1000)
                .withOptions(options)
                .start(this);
    }


    private Handler mHandler = new Handler() {
        @Override
        public void dispatchMessage(Message msg) {
            super.dispatchMessage(msg);

            switch (msg.what) {
                case MsgBox.MSG_UPLOAD_FILE_FAILED: {
                    Toast.makeText(PersonalInformationActivity.this,
                            getResources().getString(R.string.update_failed),Toast.LENGTH_SHORT);
                }
                break;
                case MsgBox.MSG_UPLOAD_FILE_SUCCESS: {

                    Toast.makeText(PersonalInformationActivity.this,
                            getResources().getString(R.string.update_success),Toast.LENGTH_SHORT).show();
                    finish();
                }
                break;
            }
        }
    };


    /**
     * 上传文件
     */
    private void uploadUserIcon(String filePath) {
//        String UPLOAD_USER_IMAGE_URL="travel/setDriverinfo.action?method=ResetDriver&driver_name=";
//
//        String name = sdf.format(System.currentTimeMillis());
//        String url = Constant.baseUrl + UPLOAD_USER_IMAGE_URL
//                + bindingView.etName.getText().toString().trim()+ "&driver_tell=" + SPTool.getUserInfo(this).body.driver_tell
//                + "&driver_pass=" + bindingView.etPsd.getText().toString().trim() + "&driver_img="
//                + name + ".jpg";
//        UploadFileThread mThread = new UploadFileThread(url,
//                filePath, mHandler);
//        mThread.setContext(this);
//        mThread.start();

    }







    /////////////////////////同步余额///////////////////////

    final  int PER_REQUEST_CODE_ =0;
    String imei="";
    LoginModelImpl loginModel;
    private String getIMSI(){

        if(loginModel == null){
            loginModel = new LoginModelImpl();
        }

        performRequestPermissions(getString(R.string.permission_imei),
                new String[]{
                        Manifest.permission.READ_PHONE_STATE,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                }
                , PER_REQUEST_CODE_,
                new PermissionResultListener() {
                    @Override
                    public void onPermissionDenied() {

                    }

                    @Override
                    public void onPermissionGranted() {



                        try {


                            TelephonyManager telmg = (TelephonyManager)
                                    getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE);
                            imei = telmg.getSubscriberId();
                            LoginParam param;
                            param = new LoginParam("DriverLogin",
                                    URLEncoder.encode(SPTool.getString(PersonalInformationActivity.this,Constant.CarNo), "utf-8"),
                                    SPTool.getUserInfo(PersonalInformationActivity.this).body.driver_tell,
                                    SPTool.getUserInfo(PersonalInformationActivity.this).body.driver_pass,
                                    imei);
                            loginModel.sendLogin(param,PersonalInformationActivity.this);


                        }catch (Exception E)
                        {
                            E.printStackTrace();
                        }

                    }
                });


        return imei;
    }

    @Override
    public void onSuccess(UserInfoBean bean) {


        try{
            SPTool.putContent(this, Constant.UserInfoBean,bean.toString());
            bindingView.etName.setText(bean.body.driver_name);
            bindingView.etCarNo.setText(SPTool.getString(this,Constant.CarNo));
            setImageUserIcon();
        }catch (Exception e){

        }


    }

    @Override
    public void onError(String errStr) {

    }


    /////////////////////////同步余额///////////////////////







}