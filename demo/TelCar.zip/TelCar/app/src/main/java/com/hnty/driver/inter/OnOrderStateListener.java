package com.hnty.driver.inter;


import com.hnty.driver.entity.OrderStateBean;
import com.hnty.driver.entity.PushOrderBean;

/**
 * Created by L on 2018/1/12.
 */

public interface OnOrderStateListener {

    void onOrderStateSuccess(OrderStateBean bean);
    void onOrderStateError(Object err);
    void onComplete();

}
