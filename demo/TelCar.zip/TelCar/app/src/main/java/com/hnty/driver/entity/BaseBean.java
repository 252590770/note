package com.hnty.driver.entity;


public class BaseBean {


    public int code;
    public String msg;

}
