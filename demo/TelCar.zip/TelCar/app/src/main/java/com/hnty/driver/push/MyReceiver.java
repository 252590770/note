package com.hnty.driver.push;//package com.hnty.driver.push;
//
//import android.app.Activity;
//import android.content.BroadcastReceiver;
//import android.content.Context;
//import android.content.Intent;
//import android.media.MediaPlayer;
//import android.net.Uri;
//import android.os.Bundle;
//import android.text.TextUtils;
//import android.util.Log;
//import android.view.View;
//
//import com.google.gson.Gson;
//import com.hnty.driver.MainActivity;
//import com.hnty.driver.application.MyApplication;
//import com.hnty.driver.entity.PushOrderBean;
//import com.hnty.driver.finals.Constant;
//import com.hnty.driver.util.SPTool;
//import com.hnty.driver.util.ToastUtil;
//import com.hnty.driver.util.Tools;
//import com.iflytek.cloud.ErrorCode;
//import com.iflytek.cloud.InitListener;
//import com.iflytek.cloud.SpeechConstant;
//import com.iflytek.cloud.SpeechError;
//import com.iflytek.cloud.SpeechSynthesizer;
//import com.iflytek.cloud.SynthesizerListener;
//
//import org.json.JSONException;
//import org.json.JSONObject;
//
//import java.io.IOException;
//import java.util.Iterator;
//
//import cn.jpush.android.api.JPushInterface;
//
//import static com.hnty.driver.finals.Constant.baseUrl;
//
///**
// * 自定义接收器
// *
// * 如果不定义这个 Receiver，则：
// * 1) 默认用户会打开主界面
// * 2) 接收不到自定义消息
// */
//public class MyReceiver extends BroadcastReceiver {
//	private static final String TAG = "LinXinSiJiDuan";
//
//	@Override
//	public void onReceive(Context context, Intent intent) {
//		try {
//			Bundle bundle = intent.getExtras();
//			Log.d(TAG, "[MyReceiver] onReceive - " + intent.getAction() + ", extras: " + printBundle(bundle));
//
//			bundle.getString(JPushInterface.EXTRA_MESSAGE);
//
//			Log.d(TAG, "EXTRA_MESSAGE=" + bundle.getString(JPushInterface.EXTRA_MESSAGE));
//
//
//
//			if (JPushInterface.ACTION_REGISTRATION_ID.equals(intent.getAction())) {
//				String regId = bundle.getString(JPushInterface.EXTRA_REGISTRATION_ID);
//				Log.d(TAG, "[MyReceiver] 接收Registration Id : " + regId);
//				//send the Registration Id to your server...
//
//
//				Log.i("bbbbbb", "---------------> 1");
//
//			} else if (JPushInterface.ACTION_MESSAGE_RECEIVED.equals(intent.getAction())) {
//				processCustomMessage(context, bundle);
//
//				Log.i("bbbbbb", "---------------> 2");
//
//			} else if (JPushInterface.ACTION_NOTIFICATION_RECEIVED.equals(intent.getAction())) {
//
//				Log.i("bbbbbb", "---------------> 3");
//				String ALERT = bundle.getString(JPushInterface.EXTRA_ALERT);
//				Log.i("bbbbbb", "---------------> a");
//				Log.i("bbbbbb", "---------------> b");
//
//				String jsonStr = bundle.getString(JPushInterface.EXTRA_EXTRA);
//				PushOrderBean bean =  new Gson().fromJson(jsonStr, PushOrderBean.class);
//
//
//				SPTool.putString(context, Constant.PushOrderBean,bean.toString());
//				ToastUtil.show(context,bean.body.voice_name);
//
//
//
//				Log.i("bbbbbb", "---------------> jsonStr="+jsonStr);
//
//				MyApplication.playMedia(bean);
//
//				Log.i("bbbbbb","推送  根据订单编号获取订单信息=");
//
//				Constant.Driver_Lat = Double.parseDouble(bean.body.voice_lat.trim());
//				Constant.Driver_Lon = Double.parseDouble(bean.body.voice_lng.trim());
//
//				Log.i("bbbbbb","Constant.Driver_Lat"+Constant.Driver_Lat);
//				Log.i("bbbbbb","Constant.Driver_Lon"+Constant.Driver_Lon);
//
//
//				MainActivity.mIsFirstSetBounds = true ;
//
//
//
//			} else if (JPushInterface.ACTION_NOTIFICATION_OPENED.equals(intent.getAction())) {
//				Log.d(TAG, "[MyReceiver] 用户点击打开了通知");
//
//
//                Log.i("bbbbbb","用户点击打开了通知");
//
//				String jsonStr = bundle.getString(JPushInterface.EXTRA_EXTRA);
//				PushOrderBean bean =  new Gson().fromJson(jsonStr, PushOrderBean.class);
//
//                Log.i("bbbbbb","bean.voice_tell=="+bean.body.voice_tell);
//				Constant.tel = bean.body.voice_tell;
//
//				Intent i = new Intent(context, MainActivity.class);
//				i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP );
//				context.startActivity(i);
//
//
//			} else if (JPushInterface.ACTION_RICHPUSH_CALLBACK.equals(intent.getAction())) {
//				Log.d(TAG, "[MyReceiver] 用户收到到RICH PUSH CALLBACK: " + bundle.getString(JPushInterface.EXTRA_EXTRA));
//				//在这里根据 JPushInterface.EXTRA_EXTRA 的内容处理代码，比如打开新的Activity， 打开一个网页等..
//
//				Log.i("cccccc", "[MyReceiver] 用户收到到RICH PUSH CALLBACK: " + bundle.getString(JPushInterface.EXTRA_EXTRA));
//
//				Log.i("bbbbbb", "---------------> 4");
//
//			} else if(JPushInterface.ACTION_CONNECTION_CHANGE.equals(intent.getAction())) {
//				boolean connected = intent.getBooleanExtra(JPushInterface.EXTRA_CONNECTION_CHANGE, false);
//				Log.w(TAG, "[MyReceiver]" + intent.getAction() +" connected state change to "+connected);
//
//				Log.i("bbbbbb", "---------------> 5");
//
//			} else {
//				Log.d(TAG, "[MyReceiver] Unhandled intent - " + intent.getAction());
//
//				Log.i("bbbbbb", "---------------> 6");
//
//			}
//		} catch (Exception e){
//			Log.i("bbbbbb", "---------------> "+e.toString());
//		}
//
//	}
//
//	// 打印所有的 intent extra 数据
//	private static String printBundle(Bundle bundle) {
//		StringBuilder sb = new StringBuilder();
//		for (String key : bundle.keySet()) {
//			if (key.equals(JPushInterface.EXTRA_NOTIFICATION_ID)) {
//				sb.append("\nkey:" + key + ", value:" + bundle.getInt(key));
//			}else if(key.equals(JPushInterface.EXTRA_CONNECTION_CHANGE)){
//				sb.append("\nkey:" + key + ", value:" + bundle.getBoolean(key));
//			} else if (key.equals(JPushInterface.EXTRA_EXTRA)) {
//				if (TextUtils.isEmpty(bundle.getString(JPushInterface.EXTRA_EXTRA))) {
//					Log.i(TAG, "This message has no Extra data");
//					continue;
//				}
//
//				try {
//					JSONObject json = new JSONObject(bundle.getString(JPushInterface.EXTRA_EXTRA));
//					Iterator<String> it =  json.keys();
//
//					while (it.hasNext()) {
//						String myKey = it.next();
//						sb.append("\nkey:" + key + ", value: [" +
//								myKey + " - " +json.optString(myKey) + "]");
//					}
//				} catch (JSONException e) {
//					Log.e(TAG, "Get message extra JSON error!");
//				}
//
//			} else {
//				sb.append("\nkey:" + key + ", value:" + bundle.getString(key));
//			}
//		}
//		return sb.toString();
//	}
//
//	//send msg to MainActivity
//	private void processCustomMessage(Context context, Bundle bundle) {
////		if (MainActivity.isForeground) {
////			String message = bundle.getString(JPushInterface.EXTRA_MESSAGE);
////			String extras = bundle.getString(JPushInterface.EXTRA_EXTRA);
////			Intent msgIntent = new Intent(MainActivity.MESSAGE_RECEIVED_ACTION);
////			msgIntent.putExtra(MainActivity.KEY_MESSAGE, message);
////			if (!ExampleUtil.isEmpty(extras)) {
////				try {
////					JSONObject extraJson = new JSONObject(extras);
////					if (extraJson.length() > 0) {
////						msgIntent.putExtra(MainActivity.KEY_EXTRAS, extras);
////					}
////				} catch (JSONException e) {
////
////				}
////
////			}
////			LocalBroadcastManager.getInstance(context).sendBroadcast(msgIntent);
////		}
//	}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//	// 语音合成对象
//	private SpeechSynthesizer mTts;
//
//	void startSpeek(Context context,String str){
//		mTts = SpeechSynthesizer.createSynthesizer(context, mTtsInitListener);
//		setParam();
//
//		// 初始化合成对象
//
//		mTts.startSpeaking(str, mTtsListener);
//
//	}
//
//	// 默认发音人
//	private String voicer = "xiaoyan";
//	// 引擎类型
//	private String mEngineType = SpeechConstant.TYPE_CLOUD;
//	/**
//	 * 参数设置
//	 * @return
//	 */
//	private void setParam(){
//		// 清空参数
//		mTts.setParameter(SpeechConstant.PARAMS, null);
//		// 根据合成引擎设置相应参数
//		if(mEngineType.equals(SpeechConstant.TYPE_CLOUD)) {
//			mTts.setParameter(SpeechConstant.ENGINE_TYPE, SpeechConstant.TYPE_CLOUD);
//			// 设置在线合成发音人
//			mTts.setParameter(SpeechConstant.VOICE_NAME, voicer);
//			//设置合成语速
//			mTts.setParameter(SpeechConstant.SPEED, "50");
//			//设置合成音调
//			mTts.setParameter(SpeechConstant.PITCH,"50");
//			//设置合成音量
//			mTts.setParameter(SpeechConstant.VOLUME, "50");
//		}else {
//			mTts.setParameter(SpeechConstant.ENGINE_TYPE, SpeechConstant.TYPE_LOCAL);
//			// 设置本地合成发音人 voicer为空，默认通过语记界面指定发音人。
//			mTts.setParameter(SpeechConstant.VOICE_NAME, "");
//			/**
//			 * TODO 本地合成不设置语速、音调、音量，默认使用语记设置
//			 * 开发者如需自定义参数，请参考在线合成参数设置
//			 */
//		}
//		//设置播放器音频流类型
//		mTts.setParameter(SpeechConstant.STREAM_TYPE, "3");
//		// 设置播放合成音频打断音乐播放，默认为true
//		mTts.setParameter(SpeechConstant.KEY_REQUEST_FOCUS, "false");
//
//		// 设置音频保存路径，保存音频格式支持pcm、wav，设置路径为sd卡请注意WRITE_EXTERNAL_STORAGE权限
//		// 注：AUDIO_FORMAT参数语记需要更新版本才能生效
//		//mTts.setParameter(SpeechConstant.AUDIO_FORMAT, "wav");
//		//mTts.setParameter(SpeechConstant.TTS_AUDIO_PATH, Environment.getExternalStorageDirectory()+"/msc/tts.wav");
//	}
//
//
//	/**
//	 * 初始化监听。
//	 */
//	private InitListener mTtsInitListener = new InitListener() {
//		@Override
//		public void onInit(int code) {
//			Log.d(TAG, "InitListener init() code = " + code);
//			if (code != ErrorCode.SUCCESS) {
//				Log.e("ccc","初始化失败,错误码："+code);
//			} else {
//				// 初始化成功，之后可以调用startSpeaking方法
//				// 注：有的开发者在onCreate方法中创建完合成对象之后马上就调用startSpeaking进行合成，
//				// 正确的做法是将onCreate中的startSpeaking调用移至这里
//			}
//		}
//	};
//
//
//	/**
//	 * 合成回调监听。
//	 */
//	private SynthesizerListener mTtsListener = new SynthesizerListener() {
//
//		@Override
//		public void onSpeakBegin() {
//			Log.e("ccc","开始播放");
//		}
//
//		@Override
//		public void onSpeakPaused() {
//			Log.e("ccc","暂停播放");
//		}
//
//		@Override
//		public void onSpeakResumed() {
//			Log.e("ccc","继续播放");
//		}
//
//		@Override
//		public void onBufferProgress(int percent, int beginPos, int endPos,
//									 String info) {
//			// 合成进度
////            mPercentForBuffering = percent;
////            showTip(String.format(getString(R.string.tts_toast_format),
////                    mPercentForBuffering, mPercentForPlaying));
//		}
//
//		@Override
//		public void onSpeakProgress(int percent, int beginPos, int endPos) {
//			// 播放进度
////            mPercentForPlaying = percent;
////            showTip(String.format(getString(R.string.tts_toast_format),
////                    mPercentForBuffering, mPercentForPlaying));
//		}
//
//		@Override
//		public void onCompleted(SpeechError error) {
//			if (error == null) {
//				Log.e("ccc","播放完成");
//			} else if (error != null) {
//				Log.e("ccc",""+error.getPlainDescription(true));
//			}
//		}
//
//		@Override
//		public void onEvent(int eventType, int arg1, int arg2, Bundle obj) {
//
//		}
//	};
//
//
//
//
//
//
//
//
//
//
//}
