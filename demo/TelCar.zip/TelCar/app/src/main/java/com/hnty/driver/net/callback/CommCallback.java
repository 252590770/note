package com.hnty.driver.net.callback;

import com.hnty.driver.net.response.BaseResponse;


public interface CommCallback {
	void noNet(int flag);
	void noData(int flag);
	void faild(int flag, BaseResponse response);
	void netExc(int flag);
}
