package com.hnty.driver.entity;

import com.google.gson.Gson;

/**
 * Created by Think-pc on 2018/5/27.
 */

public class UpdateDriverBean {
    public int code;
    public String msg;


    @Override
    public String toString() {

        return new Gson().toJson(this);
    }

}
