package com.hnty.driver.inter;


import com.hnty.driver.entity.PushOrderBean;

/**
 * Created by L on 2018/1/12.
 */

public interface OnVoiceOrderStateListener {

    void OnVoiceOrderStateSuccess(PushOrderBean bean);
    void OnVoiceOrderStateError(String errStr);

}
