package com.hnty.driver.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.hnty.driver.R;
import com.hnty.driver.application.MyApplication;
import com.hnty.driver.base.BaseActivity;
import com.hnty.driver.databinding.ActivityMyNoticeBinding;
import com.hnty.driver.entity.VoiceOrderByIdBean;
import com.hnty.driver.entity.VoiceOrderStateParam;
import com.hnty.driver.inter.VoiceOrderByIdListener;
import com.hnty.driver.model.modelimpl.VoiceOrderByIdModelImpl;
import com.hnty.driver.util.SPTool;
import com.hnty.driver.util.ToastUtil;


public class MyNoticeActivity extends BaseActivity<ActivityMyNoticeBinding> implements VoiceOrderByIdListener {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_notice);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//来保持屏幕高亮


        setTitle("系统公告");
//        getMyOrder();

    }

    //获取历史订单
    VoiceOrderByIdModelImpl model;
    void getMyOrder (){
//        if(model == null){
//            model = new VoiceOrderByIdModelImpl();
//        }
//        if(SPTool.getUserInfo(MyApplication.getContext())==null){
//            ToastUtil.show(MyNoticeActivity.this,"请登录");
//            return;
//        }
//        showProgressDialog("请稍等...");
//
//        VoiceOrderStateParam param;
//        param = new VoiceOrderStateParam("getVoiceOrderbyid", SPTool.getUserInfo(MyApplication.getContext()).body.driver_id);
//        model.getVoiceOrderState(param,this);

    }



    @Override
    public void onVoiceOrderByIdSuccess(final VoiceOrderByIdBean bean) {
        dissmissProgressDialog();
        bindingView.listView .setAdapter(new BaseAdapter() {
            @Override
            public int getCount() {
                return bean.body.size();
            }

            @Override
            public Object getItem(int position) {
                return bean.body.get(position);
            }

            @Override
            public long getItemId(int position) {
                return position;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                ViewHolder holder = new ViewHolder();
                if(convertView == null ){
                    convertView = LayoutInflater.from(MyApplication.getContext()).inflate(R.layout.past_order_item,null);
                    holder.tvTel = (TextView) convertView.findViewById(R.id.tvTel);
                    holder.tvTime = (TextView) convertView.findViewById(R.id.tvTime);
                    holder.tvStart = (TextView) convertView.findViewById(R.id.tvStart);
                    holder.tvEnd = (TextView) convertView.findViewById(R.id.tvEnd);
                    convertView.setTag(holder);
                }else {
                    holder = (ViewHolder) convertView.getTag();
                }

                holder.tvTel.setText("电话："+bean.body.get(position).voice_tell);
                holder.tvTime.setText("时间："+"");
                holder.tvTime.setVisibility(View.GONE);
                holder.tvStart.setText("出发地："+bean.body.get(position).voice_file);
                holder.tvEnd.setText("目的地："+bean.body.get(position).voice_end);
                return convertView;
            }

            class ViewHolder {
                TextView tvTel,tvTime,tvStart,tvEnd;
            }

        });

    }


    @Override
    public void onVoiceOrderByIdError(String err) {
        dissmissProgressDialog();
        ToastUtil.show(MyNoticeActivity.this,err);
    }

    //显示进度框
    private ProgressDialog progDialog = null;//
    private void showProgressDialog(String str) {
        if (progDialog == null)
            progDialog = new ProgressDialog(this);
        progDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progDialog.setIndeterminate(false);
        progDialog.setCancelable(true);
        progDialog.setMessage(str);
        progDialog.show();
    }
    //隐藏进度框
    private void dissmissProgressDialog() {
        if (progDialog != null) {
            progDialog.dismiss();
        }
    }


    public static void start(Context mContext) {
        Intent intent = new Intent(mContext, MyNoticeActivity.class);
        mContext.startActivity(intent);
    }


}
