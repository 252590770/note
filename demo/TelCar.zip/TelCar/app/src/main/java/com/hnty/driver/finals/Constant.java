package com.hnty.driver.finals;

import android.os.Environment;


/**
 * Created by L on 2018/1/17.
 */

public class Constant {


    //项目主路径
    public static final String Project_PATH = Environment
            .getExternalStorageDirectory().getPath() + "/CallACar/";

    //头像路径
    public static final String USER_PATH = Project_PATH+ "user/";

    //异常日志路径
    public static final String LOG_PATH = Project_PATH+ "log/";

    //更新路径
    public static final String UPDATE_PATH =  Project_PATH+ "update/";

    public static final String UserInfoBean = "UserInfoBean";
    public static final String PSWBean = "PSWBean";
    public static final String PushOrderBean = "PushOrderBean";
    public static final String ComplaintOrderBean = "ComplaintOrderBean";
    public static final String MyPushOrderBean = "MyPushOrderBean";
    public static final String UserGetUpDate = "UserGetUpDate";

    public static final String OrderState = "OrderState";

    public static final String IsCheckedPSW = "IsCheckedPSW";
    public static final String IsLogin = "IsLogin";
    public static final String IsPlay = "IsPlay";
    public static final String CarNo = "CarNo";
    public static final String Notice = "Notice";
    public static final String AutoOpen = "AutoOpen";
    public static final String ReceiveRun = "ReceiveRun";
    public static final String ReceiveDrive = "ReceiveDrive";
    public static final String DriverState = "DriverState";
    public static final String CrashLog = "CrashLog";


    public static final int NeedPlay = 3001;


    public static final String GetOrderTime = "GetOrderTime";

    public static final String FinishOrderTimeStr ="FinishOrderTime";

//    public static final String IP = "223.100.111.77";//铁岭
//    public static final String IP = "221.210.80.244";//肇东出行
 //   public static final String IP = "202.111.175.140";//飞广出行(敦化)敦化
//    public static final String IP = "58.244.255.70";
//    public static final String IP = "119.48.141.30";//德惠出行
//    public static final String IP = "211.137.224.202";//大庆
//    public static final String IP = "111.26.200.85";//金宇
//    public static final String IP = "220.174.161.163";//立信  220.174.161.163
//    public static final String IP = "myhainanty.com";//磐石
//    public static final int PORT = 8088;
//    public static final String IP = "221.202.112.250";
//      public static final int PORT = 8088;



//    public static final String IP = "47.92.238.48"; //阿里云
//    public static final int PORT = 80;
//    public static final String travel ="travel";
//    public static int TCP_PORT = 9631;



//    public static final String IP = "47.92.238.48"; //铁岭出行
//    public static final int PORT = 9966;
//    public static final String travel ="travel";
//    public static int TCP_PORT = 9631;


    public static final String IP = "47.92.238.48"; //铁岭出行
    public static final int PORT = 80;
    public static final String travel ="travel_tl";
    public static int TCP_PORT = 9634;





//    public static final String IP = "47.92.238.48"; //庆安
//    public static final int PORT = 80;
//    public static final String travel ="travel_qa";
//    public static int TCP_PORT = 9632;

//    public static final String IP = "47.92.238.48"; //木兰
//    public static final int PORT = 80;
//    public static final String travel ="travel_ml";
//    public static int TCP_PORT = 9633;


//    public static final String IP = "202.111.175.140";//飞广出行(敦化)敦化
//    public static final int PORT = 8088;
//    public static final String travel ="travel";
//    public static int TCP_PORT = 9631;



//    public static final String IP = "192.168.0.253";//小雷
//    public static final int PORT = 8080;//小雷
//    public static final String travel ="travel";
//    public static int TCP_PORT = 9631;


//    public static final String IP = "192.168.0.253";
//    public static final int PORT = 8080;
//    public static final String baseUrl = "http://123.185.220.3:8088/";// 外网
//    public static final String baseUrl = "http://192.168.0.253:8080/";//  内网
    public static final String baseUrl = "http://"+IP+":"+PORT+"/";




    public static final int ERROR = 1001;// 网络异常
    public static final int ROUTE_START_SEARCH = 2000;
    public static final int ROUTE_END_SEARCH = 2001;
    public static final int ROUTE_BUS_RESULT = 2002;// 路径规划中公交模式
    public static final int ROUTE_DRIVING_RESULT = 2003;// 路径规划中驾车模式
    public static final int ROUTE_WALK_RESULT = 2004;// 路径规划中步行模式
    public static final int ROUTE_NO_RESULT = 2005;// 路径规划没有搜索到结果

    public static final int GEOCODER_RESULT = 3000;// 地理编码或者逆地理编码成功
    public static final int GEOCODER_NO_RESULT = 3001;// 地理编码或者逆地理编码没有数据

    public static final int POISEARCH = 4000;// poi搜索到结果
    public static final int POISEARCH_NO_RESULT = 4001;// poi没有搜索到结果
    public static final int POISEARCH_NEXT = 5000;// poi搜索下一页

    public static final int BUSLINE_LINE_RESULT = 6001;// 公交线路查询
    public static final int BUSLINE_id_RESULT = 6002;// 公交id查询
    public static final int BUSLINE_NO_RESULT = 6003;// 异常情况


    public static double Driver_Lat ;
    public static double Driver_Lon ;
    public static String tel ="" ;



}
