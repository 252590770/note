package com.hnty.driver.entity;


import java.io.Serializable;

public class DriverDetailBean implements Serializable {

    public int code;
    public String msg;
    public BodyBean body;

    public static class BodyBean implements Serializable{

        public String driver_name;
        public String driver_tell;
        public String driver_balance;
        public String car_no;

    }
}
