package com.hnty.driver;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.SystemClock;
import android.widget.Toast;

import com.hnty.driver.services.LocationService;
import com.hnty.driver.util.SPTool;

import static android.content.Context.ALARM_SERVICE;


public class AlarmReceiver extends BroadcastReceiver{
	@Override
	public void onReceive(Context context, Intent intent) {

		if(SPTool.getInt(context,"DriverState")==1) {
			Intent service = new Intent(context, LocalService.class);
			service.setAction("MainActivity.START");
			service.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			service.putExtra("CMD", 1);
			context.startService(service);

			Intent remoteService = new Intent(context, RomoteService.class);
			context.startService(remoteService);

			Intent locationsv = new Intent(context, LocationService.class);
			context.startService(locationsv);
		}





	}
}
