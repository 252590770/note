package com.hnty.driver.entity;

import com.google.gson.Gson;

public class OrderStatusParam {


    public String method;
    public String voice_state;
    public String driver_id;
    public String voice_order;
    public String getLatitude;
    public String getLongitude;

    public OrderStatusParam(String method,String driver_id) {
        this.method = method;
        this.driver_id = driver_id;

    }
    public OrderStatusParam() {

    }

    public OrderStatusParam(String method, String voice_state, String driver_id, String voice_order, String getLatitude, String getLongitude) {
        this.method = method;
        this.voice_state = voice_state;
        this.driver_id = driver_id;
        this.voice_order = voice_order;
        this.getLatitude = getLatitude;
        this.getLongitude = getLongitude;
    }


    @Override
    public String toString() {
        return new Gson().toJson(this);
    }
}