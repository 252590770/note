package com.hnty.driver.model.modelimpl;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.DriverCancelParam;
import com.hnty.driver.entity.DriverGetUserBean;
import com.hnty.driver.entity.DriverGetUserParam;
import com.hnty.driver.inter.OnDriverGetUserListener;
import com.hnty.driver.model.modelinter.DriverGetUserModel;
import com.hnty.driver.util.NetworkUtil;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;


public class DriverGetUserModelImpl implements DriverGetUserModel {


    @Override
    public void getUser(DriverGetUserParam param, final OnDriverGetUserListener listener) {


        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            listener.onDriverGetUserError("没有网络o");
            return;
        }

        MyApplication.getAPI().driverGetUser(param.method,param.driver_id,param.voice_order)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<DriverGetUserBean>(){

                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull DriverGetUserBean bean) {

                        try {

                            if(bean.code==1){
                                listener.onDriverGetUserSuccess(bean);
                            }else if(bean.code==0){
                                listener.onDriverGetUserError(bean.msg);
                            }
                        }catch (Exception e){
                            listener.onDriverGetUserError("数据错误" );
                        }
                    }
                    @Override
                    public void onError(@NonNull Throwable e) {
                        listener.onDriverGetUserError("数据错误");
                    }

                    @Override
                    public void onComplete() {
                    }
                });


    }



}
