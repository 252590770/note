package com.hnty.driver.util;

import android.app.Activity;
import android.text.Spannable;
import android.text.SpannableString;
import android.widget.TextView;




public class FinishOrderTimer extends MyCountDownTimer {

	private static FinishOrderTimer thisTimer;

	//当前对象
//	private Activity activity;

	//触发  发送验证码的事件
	private TextView tv;
	private Activity activity;


	public static FinishOrderTimer getInstance(long millisInFuture, long countDownInterval, TextView tv) {

		if(thisTimer == null){
			thisTimer = new FinishOrderTimer(millisInFuture,countDownInterval,tv);
		}
		return thisTimer;
	}

	public FinishOrderTimer(long millisInFuture, long countDownInterval, TextView tv) {
		super(millisInFuture, countDownInterval);
		// TODO Auto-generated constructor stub
		this.tv = tv;
	}

	public FinishOrderTimer(long millisInFuture, long countDownInterval, TextView tv, Activity activity) {
		super(millisInFuture, countDownInterval);
		// TODO Auto-generated constructor stub
		this.tv = tv;
		this.activity = activity;
	}



	@Override
	public void onTick(long millisUntilFinished) {
		// TODO Auto-generated method stub
		//设置不能点击
		tv.setClickable(false);

		//Java 整除（/） 和求余（%）

		millisUntilFinished = millisUntilFinished/1000;

		long m = millisUntilFinished /60;
		long s = millisUntilFinished %60;

		if(m!=0){
			tv.setText(m+ "分"+s+"秒后自动完成订单");  //倒计时时间
		}else {
			tv.setText(s+"秒后自动完成订单");  //倒计时时间
		}
		//背景设置成灰色 此时不能点击
		//tv.setBackgroundColor(activity.getResources().getColor(R.color.grey));
		Spannable span = new SpannableString(tv.getText().toString());
		//将倒计时  时间显示成黑色
//		span.setSpan(new ForegroundColorSpan(R.color.white), 0,3, Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
		tv.setText(span);
		
	}

	@Override
	public void onFinish() {
		// TODO Auto-generated method stub
		
		try { tv.setText("完成\n订单"); }catch (Exception e){}
		//重新获取点击功能
		try { tv.setClickable(true); }catch (Exception e){}

		try { activity.finish(); }catch (Exception e){}

		;
	}

}
