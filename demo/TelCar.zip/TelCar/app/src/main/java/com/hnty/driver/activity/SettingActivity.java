package com.hnty.driver.activity;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.WindowManager;

import com.haohao.switchbutton.SwitchButton;
import com.hnty.driver.R;
import com.hnty.driver.base.BaseActivity;
import com.hnty.driver.databinding.ActivitySettingBinding;
import com.hnty.driver.entity.LoginParam;
import com.hnty.driver.entity.UserInfoBean;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.impl.PermissionResultListener;
import com.hnty.driver.inter.OnLoginListener;
import com.hnty.driver.model.modelimpl.LoginModelImpl;
import com.hnty.driver.util.SPTool;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;


public class SettingActivity  extends BaseActivity <ActivitySettingBinding> implements View.OnClickListener{

    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        setTitle("设置");
        context = this;
        bindingView.switchButton.setStatus(!SPTool.getBoolean(context,Constant.AutoOpen));
        bindingView.switchButtonRun.setStatus(SPTool.getBoolean(context,Constant.ReceiveRun));
        bindingView.switchButtonDrive.setStatus(SPTool.getBoolean(context,Constant.ReceiveDrive));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//来保持屏幕高亮
        showContentView();
        init();
        bindingView.switchButton.setOnSwitchChangeListener(new SwitchButton.OnSwitchChangeListener() {
			@Override
			public void onSwitch(int status) {
				if(status == 1){
					SPTool.putBoolean(context, Constant.AutoOpen,false);
				}else {
					SPTool.putBoolean(context,Constant.AutoOpen,true);
				}
			}
		});
        bindingView.switchButtonRun.setOnSwitchChangeListener(new SwitchButton.OnSwitchChangeListener() {
            @Override
            public void onSwitch(int status) {
                if(status == 1){
                    SPTool.putBoolean(context, Constant.ReceiveRun,true);
                }else {
                    SPTool.putBoolean(context,Constant.ReceiveRun,false);
                }
            }
        });

        bindingView.switchButtonDrive.setOnSwitchChangeListener(new SwitchButton.OnSwitchChangeListener() {
            @Override
            public void onSwitch(int status) {
                if(status == 1){
                    SPTool.putBoolean(context, Constant.ReceiveDrive,true);
                }else {
                    SPTool.putBoolean(context,Constant.ReceiveDrive,false);
                }
            }
        });


        getIMSI();

    }


    @Override
    protected void onResume() {
        super.onResume();
    }

    private void init() {
        bindingView.btnPersonal.setOnClickListener(this);
        bindingView.myOrder.setOnClickListener(this);
        bindingView.updatePWD.setOnClickListener(this);
        bindingView.switchButton.setOnClickListener(this);
        bindingView.aboutUS.setOnClickListener(this);
        bindingView.upDate.setOnClickListener(this);

        bindingView.tvName.setText(SPTool.getUserInfo(context).body.driver_name);
        bindingView.tvCarNo.setText("车牌："+SPTool.getString(context,Constant.CarNo));



    }





    public static void start(Context mContext) {
        Intent intent = new Intent(mContext, SettingActivity.class);
        mContext.startActivity(intent);
    }

    //显示进度框
    private ProgressDialog progDialog = null;//

    private void showProgressDialog(String str) {
        if (progDialog == null)
            progDialog = new ProgressDialog(this);
        progDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progDialog.setIndeterminate(false);
        progDialog.setCancelable(true);
        progDialog.setMessage(str);
        progDialog.show();
    }

    //隐藏进度框
    private void dissmissProgressDialog() {
        if (progDialog != null) {
            progDialog.dismiss();
        }
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.btnPersonal:
                PersonalInformationActivity.start(context);
                break;
            case R.id.myOrder:
                MyMessageActivity.start(context);
                break;
            case R.id.updatePWD:
                UpdatePWDActivity.start(context);
                break;
            case R.id.switchButton:
                break;
            case R.id.aboutUS:
                UserKnowActivity.start(context);
                break;
            case R.id.upDate:
                UpDateActivity.start(context);
                break;

        }
    }


    final  int PER_REQUEST_CODE =0;
    LoginModelImpl loginModel;
    OnLoginListener loginListener;
    String imei="";
    private String getIMSI(){
        if(loginModel == null){
            loginModel = new LoginModelImpl();
        }
        if(loginListener == null){
            loginListener = new OnLoginListener() {
                @Override
                public void onSuccess(UserInfoBean bean) {

                }

                @Override
                public void onError(String errStr) {
                    startActivity(new Intent(context,VerificationActivity.class));
                }
            };
        }


        performRequestPermissions(getString(R.string.permission_imei),
                new String[]{
                        Manifest.permission.READ_PHONE_STATE
                }
                , PER_REQUEST_CODE,
                new PermissionResultListener() {
                    @Override
                    public void onPermissionDenied() {

                    }

                    @Override
                    public void onPermissionGranted() {

                        try {

                            TelephonyManager telmg = (TelephonyManager)
                                    getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE);
                            imei = telmg.getSubscriberId();

                            bindingView.tvTelNo.setText("串码："+imei);

                            LoginParam param;
                            param = new LoginParam("DriverLogin",
                                    URLEncoder.encode(SPTool.getString(context,Constant.CarNo), "utf-8"),
                                    SPTool.getUserInfo(context).body.driver_tell,
                                    SPTool.getUserInfo(context).body.driver_pass,
                                    imei);
                            loginModel.sendLogin(param,loginListener );


                        }catch (Exception E)
                        {
                            E.printStackTrace();
                        }

                    }
                });


        return imei;
    }

    //请求码
    private int mRequestCode;
    //运行时权限接口
    private PermissionResultListener mListener;
    protected void performRequestPermissions(String desc, String[] permissions,
                                             int requestCode,
                                             PermissionResultListener listener) {
        if (permissions == null || permissions.length == 0) {
            return;
        }
        mRequestCode = requestCode;
        mListener = listener;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkEachSelfPermission(permissions)) {// 检查是否声明了权限
                requestEachPermissions(desc, permissions, requestCode);
            } else {// 已经申请权限
                if (mListener != null) {
                    mListener.onPermissionGranted();
                }
            }
        } else {
            if (mListener != null) {
                mListener.onPermissionGranted();
            }
        }
    }

    /**
     * 检察每个权限是否申请
     *
     * @param permissions
     * @return true 需要申请权限,false 已申请权限
     */
    private boolean checkEachSelfPermission(String[] permissions) {
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) !=
                    PackageManager.PERMISSION_GRANTED) {
                return true;
            }
        }
        return false;
    }

    private void requestEachPermissions(String desc, String[] permissions, int requestCode) {
        if (shouldShowRequestPermissionRationale(permissions)) {// 需要再次声明
            showRationaleDialog(desc, permissions, requestCode);
        } else {
            ActivityCompat.requestPermissions(SettingActivity.this, permissions, requestCode);
        }
    }

    /**
     * 再次申请权限时，是否需要声明
     *
     * @param permissions
     * @return
     */
    private boolean shouldShowRequestPermissionRationale(String[] permissions) {
        for (String permission : permissions) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                return true;
            }
        }
        return false;
    }


    /**
     * 弹出声明的 Dialog
     *
     * @param desc
     * @param permissions
     * @param requestCode
     */
    private void showRationaleDialog(String desc, final String[] permissions,
                                     final int requestCode) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.tips))
                .setMessage(desc)
                .setPositiveButton(getResources().getString(R.string.sure),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                ActivityCompat.requestPermissions(SettingActivity.this,
                                        permissions, requestCode);
                            }
                        })
                .setNegativeButton(getResources().getString(R.string.cancel),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        })
                .setCancelable(false)
                .show();
    }



}