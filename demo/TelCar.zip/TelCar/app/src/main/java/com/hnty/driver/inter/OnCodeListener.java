package com.hnty.driver.inter;


import com.hnty.driver.entity.UserInfoBean;

/**
 * Created by L on 2018/1/12.
 */

public interface OnCodeListener {

    void onCodeSuccess(String code);
    void onCodeError(String errStr);

}
