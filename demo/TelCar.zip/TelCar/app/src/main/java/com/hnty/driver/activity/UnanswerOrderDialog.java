package com.hnty.driver.activity;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.hnty.driver.LocalService;
import com.hnty.driver.MainActivity;
import com.hnty.driver.R;
import com.hnty.driver.application.MyApplication;
import com.hnty.driver.databinding.MainTopDialogBinding;
import com.hnty.driver.entity.ComplaintParam;
import com.hnty.driver.entity.EventBean;
import com.hnty.driver.entity.OrderStatusParam;
import com.hnty.driver.entity.PushOrderBean;
import com.hnty.driver.entity.UserInfoBean;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.inter.ComplaintOrderListener;
import com.hnty.driver.inter.OnDriverVoiceListener;
import com.hnty.driver.model.modelimpl.ComplaintOrderModelImpl;
import com.hnty.driver.model.modelimpl.OrderStatusModelImpl;
import com.hnty.driver.util.MyUtil;
import com.hnty.driver.util.SPTool;
import com.hnty.driver.util.ToastUtil;
import com.hnty.driver.util.VoiceUtils;
import com.hnty.driver.util.VoiceUtils2;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class UnanswerOrderDialog extends Activity implements OnClickListener, OnDriverVoiceListener ,ComplaintOrderListener {


    Context context;
    public MainTopDialogBinding binding;

    public static UnanswerOrderDialog mainTopDialog;
    private LinearLayout llBottom;
    private LinearLayout btnListen;
    private LinearLayout btnGet;
    private LinearLayout btnComplain;
    private LinearLayout btnFinish;
    public TextView tvTel;
    public TextView tvTime;
    public TextView tvStart;
    public TextView tvEnd;
    public TextView tvMainBottomMid;
    LinearLayout ll;

    PushOrderBean orderBean;
    int mp3Long;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = this;
        mainTopDialog = this;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//保持屏幕高亮
        getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);//需要添加的语句

        binding = DataBindingUtil.setContentView(this, R.layout.main_top_dialog);

        binding.btnGetOrder.setBackground(getResources().getDrawable(R.drawable.circle_bg_gray));
        SPTool.putBoolean(context,"UnanswerOrderDialogAlive",true);

        orderBean = (PushOrderBean) getIntent().getSerializableExtra("pushBean");

        init();



        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {


                mp3Long =   MyApplication.playMedia(orderBean, LocalService.myService.mHandler);
                binding.progressView.setPercentage(100,mp3Long+250);


                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        binding.btnGetOrder.setOnClickListener(UnanswerOrderDialog.this);
                        binding.btnGetOrder.setBackground(getResources().getDrawable(R.drawable.circle_bg_red));
                        binding.ivSound.setClickable(true);

                    }
                }, (mp3Long+250));




            }
        }, 1000);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                try
                {
                    binding.btnGetOrder.setOnClickListener(UnanswerOrderDialog.this);
                    binding.btnGetOrder.setBackground(getResources().getDrawable(R.drawable.circle_bg_red));
                }catch (Exception e)
                {

                }
            }
        }, 12000);




        new Handler().
                postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        finish();
                    }
                }, 14000);

    }

    private void init() {
        binding.back.setOnClickListener(this);
        binding.tvTel.setOnClickListener(this);
        binding.ivSound.setOnClickListener(this);
        binding.ivSound.setClickable(false);

        binding.tvTel.setText("乘客电话:" + MyUtil.TelNoToStarts(orderBean.body.voice_tell.trim()));
        binding.tvCount.setText("乘坐次数:" + orderBean.body.count);

    }


    @Override
    public void onBackPressed() {

        if(VoiceUtils2.with(context).IsPlaying){

            return   ;
        }

        super.onBackPressed();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if(VoiceUtils2.with(context).IsPlaying){

            return  false ;
        }

        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        VoiceUtils.with(context).SetIsPlay(false);
        SPTool.putBoolean(context,"UnanswerOrderDialogAlive",false);
        EventBus.getDefault().unregister(this);
        super.onDestroy();

    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(EventBean event) {
        switch (event.code) {
            case 12:
//                binding.btnGetOrder.setOnClickListener(this);
//                binding.btnGetOrder.setBackground(getResources().getDrawable(R.drawable.circle_bg_red));
                break;

            case Constant.NeedPlay:
                try {
                    MyApplication.playMedia2(orderBean, LocalService.myService.mHandler);
                } catch (Exception e) {
                }
                break;
        }
    };


    @Override
    public boolean onTouchEvent(MotionEvent event) {
//		finish();
        return true;
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.back:


                if(VoiceUtils2.with(context).IsPlaying){

                    return   ;
                }

                finish();

                break;

            case R.id.btnGetOrder:


                if(binding.btnGetOrder.getText().toString().equals("抢单")){
                    jiedan("1");
                    binding.btnGetOrder.setClickable(false);
                }else {
                    showSinpleChioceDialog();
                }


                break;

            case R.id.tvTel:

                //showTellDialog(2,"提示","打电话联系乘客？",orderBean.body.voice_tell);

                break;
            case R.id.ivSound:

                MyApplication.playMedia2(orderBean, LocalService.myService.mHandler);
                break;
        }

    }


    ////////////////////////接单////////////////////////
    OrderStatusModelImpl orderStatusModel = null;

    void jiedan(String statue) {

        if (SPTool.getUserInfo(this) == null) {
            ToastUtil.show(context,"请登录！");
            return;
        }

        if (orderStatusModel == null) {
            orderStatusModel = new OrderStatusModelImpl();
        }
        UserInfoBean userInfoBean = SPTool.getUserInfo(context);
        //showProgressDialog("请稍等...");
        String lat = "";
        String lon = "";



        lat = SPTool.getString(context, "Driver_Lat").trim();
        lon = SPTool.getString(context, "Driver_Lon").trim();


        if (lat=="" || lon=="")
        {
            lat = "0.0" ;
            lon = "0.0" ;
        }

        OrderStatusParam param = new OrderStatusParam("getDrivervocie", statue,
                userInfoBean.body.driver_id,
                orderBean.body.voice_order,
                lat,
                lon
        );
        orderStatusModel.sendOrderStatus(param, UnanswerOrderDialog.this);
    }

    @Override
    public void onSuccess(String str) {
        Log.i("cccccc", "接单 Success==" + str);
//		showGPSDialog(2, "提示", "接单成功，导航至乘客位置");
        ToastUtil.show(context, "接单成功");

        MyApplication.getOrderList().clear();
        MyApplication.getInstance().jieDan();

        Date date = new Date();
        int sec = (int) (date.getTime() / 1000); // 60*60*1000
        SPTool.putString(context, Constant.GetOrderTime, sec + "");

        dissmissProgressDialog();

        startActivity(new Intent(context, OrderDetailsActivity.class));

        SPTool.putString(this, Constant.MyPushOrderBean, orderBean.toString());

        finish();

    }

    @Override
    public void onError(String err) {
        ToastUtil.show(this,err);
        Log.i("cccccc", "接单 Error==" + err);
        binding.btnGetOrder.setClickable(true);
        if (err.equals("账户余额为零请充值")) {
            MyApplication.getInstance().noMoreMoney();
        }


        dissmissProgressDialog();
    }
    ////////////////////////接单////////////////////////


    //////////////////进度框进度框进度框///////////////////
    //显示进度框
    private ProgressDialog progDialog = null;//

    private void showProgressDialog(String str) {
        if (progDialog == null)
            progDialog = new ProgressDialog(this);
        progDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progDialog.setIndeterminate(false);
        progDialog.setCancelable(true);
        progDialog.setMessage(str);
        progDialog.show();
    }

    //隐藏进度框
    private void dissmissProgressDialog() {
        if (progDialog != null) {
            progDialog.dismiss();
        }
    }
    //////////////////进度框进度框进度框///////////////////


    //////////////////打电话///////////////////
    //提示对话框
    public Dialog dialog;
    public TextView btn_one;
    public TextView btn_right;

    public interface ClickSureListener {
        public void click();
    }

    private ClickSureListener clickSureListener;

    public void showTellDialog(int type, String titleStr, String contentStr,final String tel) {
        if (dialog == null) {
            dialog = new AlertDialog.Builder(context).create();
        }
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = (View) inflater.inflate(R.layout.dialog_base, null);
        TextView title = (TextView) view.findViewById(R.id.title);
        TextView content = (TextView) view.findViewById(R.id.content);
        btn_one = (TextView) view.findViewById(R.id.btn_one);
        LinearLayout layout = (LinearLayout) view
                .findViewById(R.id.bottom_layout);
        btn_right = (TextView) view.findViewById(R.id.btn_right);
        if (type == 1) {
            btn_one.setVisibility(View.VISIBLE);
            layout.setVisibility(View.GONE);
        } else if (type == 2) {
            btn_one.setVisibility(View.GONE);
            layout.setVisibility(View.VISIBLE);
        }
        btn_one.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });

        btn_right.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });
        title.setText(titleStr);
        content.setText(contentStr);

        view.findViewById(R.id.btn_left).setOnClickListener(
                new OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

        view.findViewById(R.id.btn_right).setOnClickListener(
                new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        getTel(tel);
                        dialog.dismiss();
                    }
                });

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.show();
        dialog.getWindow().setContentView(view);
    }
    //提示对话框

    void getTel( String tel) {
        try {

            Log.i("bbbbbb", "tel==" + tel);
            Intent call = new Intent(Intent.ACTION_DIAL);
            Uri data = Uri.parse("tel:" + tel);
            call.setData(data);
            startActivity(call);
        } catch (Exception e) {
        }
    }
    //////////////////打电话///////////////////


    //////////////////司机投诉///////////////////
    //投诉显示单选对话框
    int mWhich;
    public void showSinpleChioceDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("选择投诉:");
//		builder.setIcon(R.drawable.driver_icon);
        final String[] items = new String[]{"远距离接单", "黑车",};
        builder.setSingleChoiceItems(items, 0, new DialogInterface.OnClickListener() {/*设置单选条件的点击事件*/
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mWhich = which;
            }
        });
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                touSu(mWhich);
            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        builder.setCancelable(false);
        builder.show();
    }

    private ComplaintOrderModelImpl complaintOrderModel;//comlain

    void touSu(int which) {
        if (complaintOrderModel == null) {
            complaintOrderModel = new ComplaintOrderModelImpl();
        }
        try {

            ComplaintParam param;
            param = new ComplaintParam("getDrivercomplaint", which + "",
                    SPTool.getUserInfo(context).body.driver_id,
                    orderBean.body.voice_order,
                    SPTool.getMyPushOrderInfo(this).body.voice_tell);
            complaintOrderModel.sendComplaint(param, this);
        } catch (Exception e) {
        }
    }

    @Override
    public void onComplaintSuccess(String str) {
        ToastUtil.show(context,str);
    }

    @Override
    public void onComplaintError(String errStr) {
        ToastUtil.show(context,errStr);
    }
    //////////////////司机投诉///////////////////

}
