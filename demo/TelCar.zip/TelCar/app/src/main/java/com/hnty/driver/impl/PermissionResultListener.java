package com.hnty.driver.impl;

/**
 * Created by L on 2017/11/1.
 */

public interface PermissionResultListener {

    void onPermissionGranted();
    void onPermissionDenied();
}
