package com.hnty.driver.model.modelinter;


import com.hnty.driver.entity.CodeParam;
import com.hnty.driver.entity.RegisterParam;
import com.hnty.driver.inter.OnCodeListener;
import com.hnty.driver.inter.OnRegisterListener;

/**
 * Created by L on 2018/1/12.
 */

public interface RegisterModel {

    void sendRegister(RegisterParam param, OnRegisterListener listener);

}
