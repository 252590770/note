package com.hnty.driver.net.callback;


import com.hnty.driver.net.response.BaseResponse;

import java.util.ArrayList;

/**
 * 请求网络完成回调接口
 */
public interface DataCallback extends  CommCallback {
	void success(BaseResponse baseResponse, int tag);
	void successString(String str, int tag);
	void successArrayReturnObject(ArrayList arrayList, int tag);
}
