package com.hnty.driver;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.SoundPool;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.Toast;

import com.hnty.driver.entity.EventBean;
import com.hnty.driver.services.LocationService;
import com.hnty.driver.util.SPTool;

import org.greenrobot.eventbus.EventBus;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by xiaoqi on 2016/10/9.
 *
 * 通过AppWidget实现进程保护
 */
public class MyWidgetProvider extends AppWidgetProvider{
	private static Timer myTimer;
	private static int index = 0;
	//定义我们要发送的事件


	@Override
	public void onDeleted(Context context, int[] appWidgetIds)
	{
		// TODO Auto-generated method stub
		super.onDeleted(context, appWidgetIds);

		System.out.println("onDeleted");
	}



	@Override
	public void onEnabled(Context context)
	{
		System.out.println("onEnabled");
		// TODO Auto-generated method stub
		super.onEnabled(context);


	}

	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds)
	{
		System.out.println("onUpdate");
		// TODO Auto-generated method stub
		super.onUpdate(context, appWidgetManager, appWidgetIds);
	}



	@Override
	public void onReceive(Context context, Intent intent)
	{
		// TODO Auto-generated method stub
		super.onReceive(context, intent);
	}



	class MyTask extends TimerTask
	{

		private Context mcontext = null;
		private Intent intent = null;

		public MyTask(Context context) {

			//新建一个要发送的Intent
			mcontext = context;
			//	intent = new Intent();
			//intent.setAction(broadCastStringtimesnb);
		}
		@Override
		public void run()
		{

			mcontext.sendBroadcast(intent);
		}

	}
}
