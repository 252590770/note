package com.hnty.driver.inter;


import com.hnty.driver.entity.OutLineDriverBean;

/**
 * Created by L on 2018/1/12.
 */

public interface OnOutLineDriverListener {

    void onOutLineDriverSuccess(OutLineDriverBean bean);
    void onOutLineDriverError(String errStr);

}
