package com.hnty.driver.inter;


import com.hnty.driver.entity.GetDriverOrderStateBean;

/**
 * Created by L on 2018/1/12.
 */

public interface OnDriverOrderStateListener {

    void onDriverOrderStateSuccess(GetDriverOrderStateBean bean);
    void onDriverOrderStateError(String errStr);

}
