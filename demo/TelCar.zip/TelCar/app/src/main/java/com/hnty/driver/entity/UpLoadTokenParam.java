package com.hnty.driver.entity;

/**
 * Created by L on 2018/1/11.
 */

public class UpLoadTokenParam {
    public String id;
    public String token;

    public UpLoadTokenParam() {
    }

    public UpLoadTokenParam(String id, String token) {
        this.id = id;
        this.token = token;
    }


}
