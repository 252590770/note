package com.hnty.driver.model.modelinter;


import com.hnty.driver.inter.OnGetDriverDetailListener;


public interface GetDriverDetailModel {

    void getDriverDetail(String ismi, OnGetDriverDetailListener listener);

}
