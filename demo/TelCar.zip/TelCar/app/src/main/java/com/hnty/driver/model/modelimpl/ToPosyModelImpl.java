package com.hnty.driver.model.modelimpl;

import android.util.Log;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.BaseBean;
import com.hnty.driver.entity.CodeParam;
import com.hnty.driver.inter.OnCodeListener;
import com.hnty.driver.inter.OnPosyListener;
import com.hnty.driver.model.modelinter.CodeModel;
import com.hnty.driver.util.NetworkUtil;
import com.hnty.driver.util.ToastUtil;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by L on 2018/1/12.
 */

public class ToPosyModelImpl {


    public void toPosy(String billNo ,String totalAmount , final OnPosyListener listener) {

        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            listener.onPosError("没有网络o");
            return;
        }

        MyApplication.getAPI().toPosy("toPosy",billNo,totalAmount)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<String>(){

                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull String bean) {

                        Log.i("code","onNext");

                        try {
                            listener.onPosSuccess(bean);
                        }catch (Exception e){
                            listener.onPosError("数据错误");
                        }
                    }
                    @Override
                    public void onError(@NonNull Throwable e) {
                        listener.onPosError("数据错误");
                    }

                    @Override
                    public void onComplete() {
                    }
                });


    }



}
