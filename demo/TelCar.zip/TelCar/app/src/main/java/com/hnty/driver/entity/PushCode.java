package com.hnty.driver.entity;

import com.google.gson.Gson;

import java.io.Serializable;

/**
 * Created by L on 2018/3/3.
 */

public class PushCode {
    public int code;
    public String msg;
    public PushCode.BodyBean body;

    public static class BodyBean implements Serializable {


        public String voice_order;


    }
    @Override
    public String toString() {
        return new Gson().toJson(this);
    }
}
