package com.hnty.driver.entity;


import com.google.gson.Gson;

public class UserInfoBean {

    public int code;
    public String msg;
    public BodyBean body;

    public static class BodyBean {
        public String driver_tell;
        public String driver_name;
        public String driver_img;
        public String driver_pass;
        public String driver_id;
        public String driver_balance;
        public String driver_rank;
        public String count;
    }

    @Override
    public String toString() {
        return new Gson().toJson(this);
    }

}
