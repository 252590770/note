package com.hnty.driver.base;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Handler;
import android.os.Message;
import android.provider.ContactsContract;
import android.telephony.TelephonyManager;
import android.util.Config;
import android.util.Log;


import com.hnty.driver.MainActivity;
import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.EventBean;
import com.hnty.driver.util.MsgBox;
import com.hnty.driver.util.SPTool;

import org.greenrobot.eventbus.EventBus;

import java.lang.reflect.Method;
import java.util.ArrayList;

public class PhoneBroadcastReceiver extends BroadcastReceiver {

    private int mCurrentState = TelephonyManager.CALL_STATE_IDLE ;
    private int mOldState = TelephonyManager.CALL_STATE_IDLE ;
    String TAG = "tag";
    TelephonyManager telMgr;
    private Context mContext;
    @Override
    public void onReceive(Context context, Intent intent) {
        mContext = context;
        telMgr = (TelephonyManager) context.getSystemService(Service.TELEPHONY_SERVICE);
        mOldState = SPTool.getInt(context,"FLAG_CALL_STATE");
        switch (telMgr.getCallState()) {
            //来电
            case TelephonyManager.CALL_STATE_RINGING:
                mCurrentState = TelephonyManager.CALL_STATE_RINGING;
                String number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);
                Log.v(TAG, "number:" + number);
                if(SPTool.getInt(context,"DriverState")==1) {
//                    Intent intent2 = new Intent(context, MainActivity.class);
//                    intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT );//
//                    context.startActivity(intent2);
                    EventBus.getDefault().post(new EventBean(14));

                    //
                }
                break;
            //响铃
            case TelephonyManager.CALL_STATE_OFFHOOK:
                mCurrentState = TelephonyManager.CALL_STATE_OFFHOOK;
                break;
            //挂断
            case TelephonyManager.CALL_STATE_IDLE:
                mCurrentState = TelephonyManager.CALL_STATE_IDLE;
                if(SPTool.getInt(context,"DriverState")==1) {
//                    Intent intent2 = new Intent(context, MainActivity.class);
//                    intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT );//
//                    context.startActivity(intent2);
                    EventBus.getDefault().post(new EventBean(14));
                }
                break;
        }

    }
}
