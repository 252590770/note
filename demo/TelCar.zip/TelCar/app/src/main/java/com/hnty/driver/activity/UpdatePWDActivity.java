package com.hnty.driver.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

import com.hnty.driver.R;
import com.hnty.driver.base.BaseActivity;
import com.hnty.driver.databinding.ActivityUpdatePasswordBinding;
import com.hnty.driver.entity.BaseBean;
import com.hnty.driver.entity.SetDriverInfoParam;
import com.hnty.driver.entity.UserInfoBean;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.inter.OnSetDriverInfoListener;
import com.hnty.driver.model.modelimpl.SetDriverInfoModelImpl;
import com.hnty.driver.util.SPTool;
import com.hnty.driver.util.ToastUtil;

/**
 * Created by Administrator on 2017/4/27.
 */

public class UpdatePWDActivity extends BaseActivity<ActivityUpdatePasswordBinding> {

    Context context;
    String etPSWStr;
    String etPSWStr2;
    String etPSWStr3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_password);
        setTitle("修改密码");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//来保持屏幕高亮
        showContentView();
        context = this;

        bindingView.btnSendHttp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(getStringOK()){
                    setDriverInfo();
                }

            }
        });
    }

    SetDriverInfoModelImpl infoModel;

    void setDriverInfo (){

        if(infoModel == null){
            infoModel = new SetDriverInfoModelImpl();
        }

        SetDriverInfoParam param = new SetDriverInfoParam();
        param.method = "ResetDriver";
        param.driver_name = SPTool.getUserInfo(context).body.driver_name;
        param.driver_tell = SPTool.getUserInfo(context).body.driver_tell;
        param.driver_pass = etPSWStr2;
        infoModel.setDriverinfo(param,listener);

    }

    OnSetDriverInfoListener listener = new OnSetDriverInfoListener() {
        @Override
        public void onSetDriverInfoSuccess(BaseBean bean) {

            UserInfoBean userInfo= SPTool.getUserInfo(context);
            userInfo.body.driver_pass = etPSWStr2;
            SPTool.putContent(context, Constant.UserInfoBean,userInfo.toString());
            SPTool.putContent(context, Constant.PSWBean,userInfo.toString());
            ToastUtil.show(context,bean.msg);
            finish();
        }

        @Override
        public void onSetDriverInfoError(String errStr) {
            ToastUtil.show(context,errStr);
        }
    };

    //判断是否填写正确
    private boolean getStringOK() {
        // TODO Auto-generated method stub

        boolean ok = true;

        etPSWStr = bindingView.etPSW.getText().toString().trim();
        etPSWStr2 = bindingView.etPSW2.getText().toString().trim();
        etPSWStr3 = bindingView.etPSW3.getText().toString().trim();

        if(etPSWStr.length()==0){

            ToastUtil.show(this, "请输入原始密码");
            ok = false;

        }else  if(!SPTool.getUserInfo(context).body.driver_pass.equals(etPSWStr)) {

            ToastUtil.show(this, "原始密码不正确");
            ok = false;

        }else  if(etPSWStr2.length()==0) {

            ToastUtil.show(this, "请输入新密码");
            ok = false;

        }else  if(etPSWStr3.length()==0) {

            ToastUtil.show(this, "请确认密码");
            ok = false;

        }else  if(!etPSWStr2.equals(etPSWStr3)) {

            ToastUtil.show(this, "两次密码不一致");
            ok = false;
        }
        return ok;
    }






    public static void start(Context mContext) {
        Intent intent = new Intent(mContext, UpdatePWDActivity.class);
        mContext.startActivity(intent);
    }




}