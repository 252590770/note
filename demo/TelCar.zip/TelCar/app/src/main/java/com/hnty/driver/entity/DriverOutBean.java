package com.hnty.driver.entity;

import com.google.gson.Gson;


public class DriverOutBean {


    public int code;
    public String msg;
    public BodyBean body;


    public static class BodyBean {

        public String notice_desc;
        public String voice_tell;
        public String voice_file;
        public String voice_order;
        public String voice_name;
        public String oper_date;
        public String voice_state;
        public String driver_work ;
        public String complaint_count;//投诉次数
        public int orderend_time ;
        public int cancel_time ;

    }

    @Override
    public String toString() {

        return new Gson().toJson(this);
    }

}
