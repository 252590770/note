package com.hnty.driver.activity;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.hnty.driver.R;
import com.hnty.driver.entity.BaseBean;
import com.hnty.driver.entity.CodeParam;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.impl.PermissionResultListener;
import com.hnty.driver.inter.OnCodeListener;
import com.hnty.driver.inter.OnRegisterListener;
import com.hnty.driver.inter.OnUpdateIsmiListener;
import com.hnty.driver.model.modelimpl.CodeModelImpl;
import com.hnty.driver.model.modelimpl.UpdateIsmiModelImpl;
import com.hnty.driver.util.CommonUtils;
import com.hnty.driver.util.SPTool;
import com.hnty.driver.util.Timer;
import com.hnty.driver.util.ToastUtil;
import com.hnty.driver.view.statusbar.StatusBarUtil;

import java.net.URLEncoder;


public class VerificationActivity extends Activity implements View.OnClickListener,OnCodeListener,OnRegisterListener {

    private TextView tvGetCode;
    private TextView etTel;
    private TextView etCar;
    private EditText etCode;
    private Button btnLogin;
    private String etCarnoStr,etTelStr,etCodeStr;

    private Context context;
    private int page = 1 ;
    private String codeFromService = "" ;

    private CodeModelImpl codeModel;
    private Timer timer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verification);

        // 设置透明状态栏
        StatusBarUtil.setColor(this, CommonUtils.getColor(R.color.colorTheme),0);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//来保持屏幕高亮
//        ((Toolbar)findViewById(R.id.tool_bar)).setTitle("校验账号");


        context = VerificationActivity.this;
        codeModel = new CodeModelImpl();
        initView();
        initEvent();
        setToolBar();

    }

    private void initView() {
        tvGetCode = (TextView) findViewById(R.id.tvGetCode);
        etTel = (TextView) findViewById(R.id.etTel);
        etCar = (TextView) findViewById(R.id.etCarno);
        etCode = (EditText) findViewById(R.id.etCode);
        btnLogin = (Button) findViewById(R.id.btnLogin);

        etTel.setText(SPTool.getUserInfo(context).body.driver_tell);
        etCar.setText(SPTool.getString(context, Constant.CarNo));


        //不可编辑
        etTel.requestFocus();
        etTel.setFocusable(true);
        etTel.setFocusableInTouchMode(true);
        etCar.requestFocus();
        etCar.setFocusable(true);
        etCar.setFocusableInTouchMode(true);

    }

    private void initEvent() {
        tvGetCode.setOnClickListener(this);
        btnLogin.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        String etTelStr = etTel.getText().toString().trim();


        switch (v.getId()) {

            case R.id.tvGetCode:


                if (TextUtils.isEmpty(etTelStr)) {
                    ToastUtil.show(this, "请输入手机号码");
                    return;
//                } else if (!Tools.T_String.isPhoneNum(etTelStr)) {
//                    ToastUtil.show(this, "手机号码格式不正确");
//                    return;
                }

                timer = new Timer(60000, 1000, this, tvGetCode);
                timer.start();

                CodeParam param = new CodeParam("getMessage",etTelStr);
                codeModel.getCode(param,this);

                break;

            case R.id.btnLogin:
                showProgressDialog("验证中...");
                new Handler().postDelayed(

                        new Runnable() {
                            @Override
                            public void run() {
                                getIMSI();
                            }
                        },
                        3000
                );

                break;
            default:
                break;
        }

    }


    final  int PER_REQUEST_CODE =0;
    String imei="";
    private String getIMSI(){



        performRequestPermissions(getString(R.string.permission_imei),
                new String[]{
                        Manifest.permission.READ_PHONE_STATE,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                }
                , PER_REQUEST_CODE,
                new PermissionResultListener() {
                    @Override
                    public void onPermissionDenied() {

                    }

                    @Override
                    public void onPermissionGranted() {

                        try {
                            TelephonyManager telmg = (TelephonyManager)
                                    getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE);
                            imei = telmg.getSubscriberId();

                            if(getStringOK()){
                                sendLogin(imei);
                            }

                        }catch (Exception E)
                        {
                            E.printStackTrace();
                        }

                    }
                });


        return imei;
    }

    //请求码
    private int mRequestCode;
    //运行时权限接口
    private PermissionResultListener mListener;
    protected void performRequestPermissions(String desc, String[] permissions,
                                             int requestCode,
                                             PermissionResultListener listener) {
        if (permissions == null || permissions.length == 0) {
            return;
        }
        mRequestCode = requestCode;
        mListener = listener;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkEachSelfPermission(permissions)) {// 检查是否声明了权限
                requestEachPermissions(desc, permissions, requestCode);
            } else {// 已经申请权限
                if (mListener != null) {
                    mListener.onPermissionGranted();
                }
            }
        } else {
            if (mListener != null) {
                mListener.onPermissionGranted();
            }
        }
    }



    /**
     * 检察每个权限是否申请
     *
     * @param permissions
     * @return true 需要申请权限,false 已申请权限
     */
    private boolean checkEachSelfPermission(String[] permissions) {
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) !=
                    PackageManager.PERMISSION_GRANTED) {
                return true;
            }
        }
        return false;
    }

    private void requestEachPermissions(String desc, String[] permissions, int requestCode) {
        if (shouldShowRequestPermissionRationale(permissions)) {// 需要再次声明
            showRationaleDialog(desc, permissions, requestCode);
        } else {
            ActivityCompat.requestPermissions(VerificationActivity.this, permissions, requestCode);
        }
    }


    /**
     * 再次申请权限时，是否需要声明
     *
     * @param permissions
     * @return
     */
    private boolean shouldShowRequestPermissionRationale(String[] permissions) {
        for (String permission : permissions) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                return true;
            }
        }
        return false;
    }


    /**
     * 弹出声明的 Dialog
     *
     * @param desc
     * @param permissions
     * @param requestCode
     */
    private void showRationaleDialog(String desc, final String[] permissions,
                                     final int requestCode) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.tips))
                .setMessage(desc)
                .setPositiveButton(getResources().getString(R.string.sure),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                ActivityCompat.requestPermissions(VerificationActivity.this,
                                        permissions, requestCode);
                            }
                        })
                .setNegativeButton(getResources().getString(R.string.cancel),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        })
                .setCancelable(false)
                .show();
    }



    //判断是否填写正确
    private boolean getStringOK() {
        // TODO Auto-generated method stub

        boolean ok = true;

        etTelStr = etTel.getText().toString().trim();
        etCarnoStr = etCar.getText().toString().trim();
        etCodeStr = etCode.getText().toString().trim();
         if(etTelStr.length()==0) {

            ToastUtil.show(context, "请输入电话");
            ok = false;

//        }else  if(!Tools.T_String.isPhoneNum(etTelStr)) {
//
//            ToastUtil.show(this, "手机号码格式不正确");
//            ok = false;



        }
        return ok;
    }

    /**
     * 设置titlebar
     */
    protected void setToolBar() {
//        setSupportActionBar(tool_bar);
//        ActionBar actionBar = getSupportActionBar();
//        if (actionBar != null) {
//            //去除默认Title显示
//            actionBar.setDisplayShowTitleEnabled(false);
//            actionBar.setDisplayHomeAsUpEnabled(true);
//            actionBar.setHomeAsUpIndicator(R.drawable.icon_back);
//        }
//        tool_bar.setTitle("注册");
//        tool_bar.setNavigationOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                onBackPressed();
//            }
//        });
    }


    @Override
    public void onCodeSuccess(String code) {
        ToastUtil.show(this,"验证码已发送");
        codeFromService = code;
    }

    @Override
    public void onCodeError(String errStr) {

    }

    @Override
    public void onRegisterSuccess(String str) {
        ToastUtil.show(VerificationActivity.this,str);

        finish();
    }

    @Override
    public void onRegisterError(String err) {
        Toast.makeText(context, err, Toast.LENGTH_SHORT).show();
    }





    private UpdateIsmiModelImpl  updateModel;
    private OnUpdateIsmiListener listener;
    void sendLogin (String imei){
        if(updateModel == null){
            updateModel = new UpdateIsmiModelImpl();
        }
        if(listener == null){
            listener =  new OnUpdateIsmiListener() {
                @Override
                public void onUpdateSuccess(BaseBean bean) {
                    ToastUtil.show(context,bean.msg);
                    finish();
                    dissmissProgressDialog();
                }

                @Override
                public void onUpdateError(String errStr) {
                    ToastUtil.show(context,errStr);
                    dissmissProgressDialog();
                }
            };
        }

        try {
            updateModel.updateIsmi(""+ SPTool.getUserInfo(context).body.driver_tell,
                    ""+URLEncoder.encode(SPTool.getString(context, Constant.CarNo), "utf-8"),
                    ""+imei,listener);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    //显示进度框
    private ProgressDialog progDialog = null;//

    private void showProgressDialog(String str) {
        if (progDialog == null)
            progDialog = new ProgressDialog(this);
        progDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progDialog.setIndeterminate(false);
        progDialog.setCancelable(false);
        progDialog.setMessage(str);
        progDialog.show();
    }

    //隐藏进度框
    private void dissmissProgressDialog() {
        if (progDialog != null) {
            progDialog.dismiss();
        }
    }




}
