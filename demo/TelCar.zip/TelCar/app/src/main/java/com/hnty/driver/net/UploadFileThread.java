package com.hnty.driver.net;


import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.google.gson.Gson;
import com.hnty.driver.entity.PushCode;
import com.hnty.driver.entity.UpDateUserImg;
import com.hnty.driver.entity.UserInfoBean;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.util.MsgBox;
import com.hnty.driver.util.SPTool;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.FileEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import java.io.File;


/**
 * Created by Silence on 2017/9/25.
 */

public class UploadFileThread extends Thread {


    private String url;
    private final Handler handler;
    private final String filePath;
    private Gson gson = new Gson();
    private UpDateUserImg bean ;
    private Context context;

    public UploadFileThread(String url, String filePath, Handler handler) {
        this.url = url;
        this.handler = handler;
        this.filePath = filePath;

    }

    public void  setContext(Context context){
        this.context = context;
    }


    @Override
    public void run() {
        super.run();

        Log.i("ccccccc","pic_upload_filePath="+filePath);
        Log.i("ccccccc","url="+this.url);

//        File file = new File(filePath);
        url = url.replaceAll(" ", "%20");
        HttpPost request = new HttpPost(this.url);
        HttpClient httpClient = new DefaultHttpClient();
//        FileEntity entity = new FileEntity(file, "binary/octet-stream");
        HttpResponse response;




        try {
//            request.setEntity(entity);
//            entity.setContentEncoding("binary/octet-stream");
            response = httpClient.execute(request);
            // 如果返回状态为200，获得返回的结果
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                // 得到返回的字符串
                String result = EntityUtils.toString(response.getEntity());

                Log.i("cccccc","result="+result);


                PushCode code = new Gson().fromJson(result, PushCode.class);

                if(code.code == 1){
                    handler.sendEmptyMessage(MsgBox.MSG_UPLOAD_FILE_SUCCESS);
                }




//                bean = gson.fromJson(result, UpDateUserImg.class);

                Log.i("cccccc","pic_upload_result="+result);

//                if(null!=context){
//                    UserInfoBean userBean = SPTool.getUserInfo(context);
//                    userBean.body.driver_img = bean.msg.driver_img.trim();
//
//                    Log.i("cccccc","userBean.msg.driver_img="+userBean.body.driver_img);
//
//                    SPTool.putString(context, Constant.UserInfoBean,userBean.toString());
//                }



                return;
            }
            if (response.getStatusLine().getStatusCode() == 500) {
                handler.sendEmptyMessage(MsgBox.MSG_UPLOAD_FILE_FAILED);
                return;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 发送消息
     *
     * @param what
     * @param object
     */
    private void sendMessage(int what, Object object) {
        Message msg = new Message();
        msg.what = what;
        msg.obj = object;
        handler.sendMessage(msg);

    }
}
