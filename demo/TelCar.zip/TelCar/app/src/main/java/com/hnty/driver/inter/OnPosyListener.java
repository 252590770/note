package com.hnty.driver.inter;


/**
 * Created by L on 2018/1/12.
 */

public interface OnPosyListener {

    void onPosSuccess(String code);
    void onPosError(String errStr);

}
