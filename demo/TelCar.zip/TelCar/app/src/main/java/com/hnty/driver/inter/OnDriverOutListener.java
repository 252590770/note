package com.hnty.driver.inter;


import com.hnty.driver.entity.DriverOutBean;


public interface OnDriverOutListener {

    void onDriverOutSuccess(DriverOutBean newsEntity);
    void onDriverOutError(String errStr);

}
