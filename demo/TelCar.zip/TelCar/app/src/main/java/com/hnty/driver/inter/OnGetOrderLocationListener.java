package com.hnty.driver.inter;


import com.hnty.driver.entity.OrderLocationBean;

/**
 * Created by L on 2018/1/12.
 */

public interface OnGetOrderLocationListener {

    void onGetLocationSuccess(OrderLocationBean bean);
    void onGetLocationError(String errStr);

}
