package com.hnty.driver.activity;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.R;


public class KeepLiveActivity extends Activity {

    private static final String TAG = "kiven";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//      setContentView(R.layout.activity_main);
        Log.i(TAG, "KeepLiveActivity----onCreate!!!");
        Window window = getWindow();
        window.setGravity(Gravity.LEFT|Gravity.TOP);
        WindowManager.LayoutParams params = window.getAttributes();
        params.height = 100;
        params.width = 100;
        params.x = 0;
        params.y = 0;
        window.setAttributes(params);
        KeepLiveActivityManager.getInstance(this).setKeepLiveActivity(this);

    }

    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
        Log.i(TAG, "KeepLiveActivity----onDestroy!!!");
    }

}
