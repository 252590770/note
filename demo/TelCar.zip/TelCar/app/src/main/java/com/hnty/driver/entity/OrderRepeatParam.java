package com.hnty.driver.entity;

/**
 * Created by L on 2018/1/11.
 */

public class OrderRepeatParam {
    public String method;
    public String driver_id;
    public String voice_order ;

    public OrderRepeatParam() {
    }

    public OrderRepeatParam(String method, String driver_id, String voice_order) {
        this.method = method;
        this.driver_id = driver_id;
        this.voice_order = voice_order;
    }
}
