package com.hnty.driver.inter;


/**
 * Created by L on 2018/1/12.
 */

public interface OnSkanCodeInfoListener {

    void onSkanCodeSuccess(String newsEntity);
    void onSkanCodeError(String errStr);

}
