package com.hnty.driver.model.modelinter;


import com.hnty.driver.entity.GetListParam;
import com.hnty.driver.inter.OnGetListInfoListener;

/**
 * Created by L on 2018/1/12.
 */

public interface InfoListModel {

    void getInfoList(GetListParam param, OnGetListInfoListener getListInfoListener);

}
