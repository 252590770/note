package com.hnty.driver.entity;

/**
 * Created by L on 2018/1/11.
 */

public class LoginParam {
    public String method;
    public String carno;
    public String driver_tell;
    public String driver_pass;
    public String driver_ismi;

    public LoginParam() {
    }

    public LoginParam(String method, String carno, String driver_tell, String driver_pass, String driver_ismi) {
        this.method = method;
        this.carno = carno;
        this.driver_tell = driver_tell;
        this.driver_pass = driver_pass;
        this.driver_ismi = driver_ismi;
    }
}
