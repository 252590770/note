package com.hnty.driver.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;

import com.hnty.driver.R;
import com.hnty.driver.application.MyApplication;
import com.hnty.driver.autolist.MyAdapter;
import com.hnty.driver.autolist.PullToRefreshLayout;
import com.hnty.driver.autolist.PullableListView;
import com.hnty.driver.base.BaseActivity;
import com.hnty.driver.databinding.ActivityOrderListBinding;
import com.hnty.driver.entity.PastOrderListBean;
import com.hnty.driver.entity.PushOrderBean;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.inter.OnPastOrderListener;
import com.hnty.driver.model.modelimpl.PastOrderModelImpl;
import com.hnty.driver.model.modelimpl.VoiceOrderListModelImpl;
import com.hnty.driver.util.SPTool;


public class VoiceOrderListActivity extends BaseActivity<ActivityOrderListBinding> implements
        View.OnClickListener,/*OnVoiceOrderListListener,*/PullToRefreshLayout.OnRefreshListener ,
        PullableListView.OnLoadListener ,OnPastOrderListener {

    Context context = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_list);
        setTitle("未抢订单");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//保持屏幕高亮
        init();
        getPastOrderList();
        listViewSetOnItemClickListener();

        SPTool.putBoolean(context,"VoiceOrderListActivityAlive",true);

    }

    @Override
    public void onDestroy() {
        SPTool.putBoolean(context,"VoiceOrderListActivityAlive",false);
        super.onDestroy();
    }

    private void init() {
//        bindingView.refreshView.setOnRefreshListener(this);;
//        bindingView.listView.setOnLoadListener(this);;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.btnTopL://地图导航


                break;



        }
    }



    ///////////////////////////////////////////////////////////

    PastOrderModelImpl pastOrderModel;

    void getPastOrderList(){

        if(pastOrderModel == null){
            pastOrderModel = new PastOrderModelImpl();
        }
        pastOrderModel.getPastOrder(this,page+"");
    }


    @Override
    public void onPastOrderSuccess(PastOrderListBean PastOrder) {



        if(bindingView.listView.getAdapter()==null){
            adapter = new MyAdapter(context, PastOrder.body);
            bindingView.listView.setAdapter(adapter);
        }else if(page == 1){
            adapter.refresh(PastOrder.body);

        }else {
            adapter.addItem(PastOrder.body);
        }
    }

    @Override
    public void onPastOrderError(String errStr) {

        try {
//            bindingView.listView.finishLoading();
        }catch (Exception e){}
    }


    ///////////////////////////////////////////////////////////







    ////////////////////////获取订单列表////////////////////////

    VoiceOrderListModelImpl  voiceOrderListModel;
    MyAdapter adapter;
    int page = 1;

    @Override
    public void onRefresh(PullToRefreshLayout pullToRefreshLayout) {
        page = 1;
        getPastOrderList();
//        bindingView.refreshView.refreshFinish(PullToRefreshLayout.SUCCEED);
    }


    @Override
    public void onLoad(PullableListView pullableListView) {
        page ++;
        getPastOrderList();
//        bindingView.listView.finishLoading();
    }


    void listViewSetOnItemClickListener(){

        bindingView.listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                PastOrderListBean.BodyBean bean = (PastOrderListBean.BodyBean)bindingView.listView.getAdapter().getItem(position);

                PushOrderBean pushBean = null;
                pushBean = new PushOrderBean();
                pushBean.body = new PushOrderBean.BodyBean();

                try {

                    Log.i("cccccccc","voice_file=="+bean.voice_file);
                    Log.i("cccccccc","voice_end=="+bean.voice_end);
                    Log.i("cccccccc","driver_latitude=="+bean.driver_latitude);
                    Log.i("cccccccc","driver_longitude=="+bean.driver_longitude);
                    pushBean.msg = "";
                    pushBean.body.voice_order = bean.voice_order.trim();
                    pushBean.body.voice_name = bean.voice_name.trim();
                    pushBean.body.voice_end = bean.voice_end.trim();
                    pushBean.body.voice_tell = bean.voice_tell.trim();
                    pushBean.body.count = bean.rowNumber+"";
                    pushBean.body.driver_latitude = bean.driver_latitude.trim();
                    pushBean.body.driver_longitude = bean.driver_longitude.trim();
                    pushBean.body.get_latitude = bean.get_latitude.trim();
                    pushBean.body.get_longitude = bean.get_longitude.trim();
                    pushBean.body.voice_lat = bean.voice_lat.trim();
                    pushBean.body.voice_lng = bean.voice_lng.trim();
                }catch (Exception e){

                }

//                MyApplication.playMedia(pushBean);
                Log.i("VoiceOrderListActivity",pushBean.toString());
                Intent intent =  new Intent(VoiceOrderListActivity.this,UnanswerOrderDialog.class);
                intent.putExtra("pushBean",pushBean);
                startActivity(intent);

                finish();

            }
        });
    }

    ////////////////////////获取订单列表////////////////////////







}