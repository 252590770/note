package com.hnty.driver.model.modelimpl;

import android.util.Log;
import android.view.LayoutInflater;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.GetListParam;
import com.hnty.driver.entity.GetListResult;
import com.hnty.driver.inter.OnGetListInfoListener;
import com.hnty.driver.model.modelinter.InfoListModel;
import com.hnty.driver.util.NetworkUtil;

import java.util.ArrayList;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by L on 2018/1/12.
 */

public class InfoListModelImpl implements InfoListModel {


    @Override
    public void getInfoList(GetListParam param, final OnGetListInfoListener getListInfoListener) {

        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            getListInfoListener.onError(new Exception("没有网络o"));
            return;
        }

        LayoutInflater.from(MyApplication.getContext());

        MyApplication.getAPI().getListWithRx(param.method,param.order_id)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ArrayList<GetListResult>>() {
                    @Override
                    public void onSubscribe(@NonNull Disposable d) {
                    }

                    @Override
                    public void onNext(@NonNull ArrayList<GetListResult> listResults) {
                        try {
                            getListInfoListener.onSuccess(listResults);
                        }catch (Exception e){
                            getListInfoListener.onError(new Exception("数据错误"));
                        }

                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        getListInfoListener.onError(new Exception("数据错误"));
                        Log.i("ccccccc","onError="+e.toString());
                    }

                    @Override
                    public void onComplete() {
                    }
                });










    }

}
