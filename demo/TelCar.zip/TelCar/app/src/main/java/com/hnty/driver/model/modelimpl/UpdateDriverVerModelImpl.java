package com.hnty.driver.model.modelimpl;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.OutLineDriverBean;
import com.hnty.driver.entity.UpdateDriverBean;
import com.hnty.driver.entity.UpdateDriverVerParam;
import com.hnty.driver.inter.OnUpdateDriverVerListener;
import com.hnty.driver.model.modelinter.UpadateDriverVerModel;
import com.hnty.driver.util.NetworkUtil;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by Think-pc on 2018/5/27.
 */

public class UpdateDriverVerModelImpl implements UpadateDriverVerModel {
    @Override
    public void onUpdateDriverver(UpdateDriverVerParam param, final OnUpdateDriverVerListener listener) {

        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            listener.onUpdateDriververError("没有网络o");
            return;
        }

        MyApplication.getAPI().updateDriverver(param.method,param.driver_id,param.driver_ver)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<UpdateDriverBean>(){
                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }
                    @Override
                    public void onNext(@NonNull UpdateDriverBean bean) {
                        try {
                            if(bean.code==1){
                                listener.onUpdateDriverVerSuccess(bean);
                            }else if(bean.code==0){
                                listener.onUpdateDriververError(bean.msg);
                            }
                        }catch (Exception e){
                            listener.onUpdateDriververError("数据错误" );
                        }
                    }
                    @Override
                    public void onError(@NonNull Throwable e) {
                        listener.onUpdateDriververError("数据错误");
                    }

                    @Override
                    public void onComplete() {
                    }
                });

    }
}
