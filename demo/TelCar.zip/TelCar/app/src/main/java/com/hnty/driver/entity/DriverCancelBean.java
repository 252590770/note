package com.hnty.driver.entity;

public class DriverCancelBean {



    public int code;
    public String msg;
    public BodyBean body;

    public static class BodyBean {
    }
}
