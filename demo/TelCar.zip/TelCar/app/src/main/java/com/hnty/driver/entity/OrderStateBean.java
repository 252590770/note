package com.hnty.driver.entity;

import com.google.gson.Gson;


public class OrderStateBean {

 
    public int code;
    public String msg;
    public BodyBean body;

    @Override
    public String toString() {

        return new Gson().toJson(this);
    }

    public static class BodyBean {

        public String voice_tell;
        public String voice_file;
        public String voice_end;
        public String voice_order;
        public String voice_name;
        public String end_name;
        public String oper_date="";
        public String voice_state="";
        public String driver_id="";

    }
}
