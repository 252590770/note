package com.hnty.driver.entity;

import android.os.Parcelable;

import com.google.gson.Gson;

import java.io.Serializable;
import java.util.List;

public class VoiceOrderListBean implements Serializable {
 

    public int code;
    public String msg;
    public List<BodyBean> body;

    public static class BodyBean implements Serializable {

        public String voice_order;
        public int driver_balance;
        public int driver_charge;
        public String driver_name;
        public String voice_name;
        public String oper_date;
        public int rowNumber;
        public String end_name;
        public String voice_file;
        public String voice_lat;
        public String driver_latitude;
        public String driver_longitude;
        public String get_latitude;
        public String voice_state;
        public int id;
        public String voice_end;
        public String get_longitude;
        public String end_longitude;
        public String end_latitude;
        public int drivercount;
        public String voice_lng;
        public String driver_id;
        public String voice_tell;
        public String driver_tell;
    }

    @Override
    public String toString() {
        return new Gson().toJson(this);
    }
}
