package com.hnty.driver.activity;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.hnty.driver.LocalService;
import com.hnty.driver.MainActivity;
import com.hnty.driver.R;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.base.BaseActivity;
import com.hnty.driver.databinding.ActivityOrderDetailsBinding;
import com.hnty.driver.entity.ComplaintParam;
import com.hnty.driver.entity.DriverCancelBean;
import com.hnty.driver.entity.DriverCancelParam;
import com.hnty.driver.entity.DriverGetUserBean;
import com.hnty.driver.entity.DriverGetUserParam;
import com.hnty.driver.entity.FinishOrderParam;
import com.hnty.driver.entity.OrderRepeatBean;
import com.hnty.driver.entity.OrderRepeatParam;
import com.hnty.driver.entity.UserInfoBean;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.impl.PermissionResultListener;
import com.hnty.driver.inter.ComplaintOrderListener;
import com.hnty.driver.inter.OnDriverCancelListener;
import com.hnty.driver.inter.OnDriverGetUserListener;
import com.hnty.driver.inter.OnFinishOrderListener;
import com.hnty.driver.inter.OnOrderRepeatListener;
import com.hnty.driver.model.modelimpl.ComplaintOrderModelImpl;
import com.hnty.driver.model.modelimpl.DriverCancelModelImpl;
import com.hnty.driver.model.modelimpl.DriverGetUserModelImpl;
import com.hnty.driver.model.modelimpl.FinishOrderModelImpl;
import com.hnty.driver.model.modelimpl.OrderRepeatModelImpl;
import com.hnty.driver.tts.MiniTTS;
import com.hnty.driver.util.FinishOrderTimer;
import com.hnty.driver.util.MapDialog;
import com.hnty.driver.util.SPTool;
import com.hnty.driver.util.ToastUtil;

import java.net.URISyntaxException;
import java.util.Date;



public class OrderDetailsActivity extends BaseActivity<ActivityOrderDetailsBinding> implements
        View.OnClickListener ,OnFinishOrderListener ,ComplaintOrderListener,OnDriverCancelListener ,
        OnOrderRepeatListener ,MapDialog.OnActionCameraSelect,DialogInterface.OnCancelListener,OnDriverGetUserListener {


    Context context = this;

    static OrderDetailsActivity orderDetailsActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_details);
        setTitle("订单详情");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//保持屏幕高亮
        orderDetailsActivity = this;
        init();



    }


    public static OrderDetailsActivity  getInstant() {
        if(orderDetailsActivity == null){
            orderDetailsActivity = new OrderDetailsActivity();
        }

        return  orderDetailsActivity;
    }

    private FinishOrderTimer timer;
    private void init() {
        bindingView.btnTopL.setText("导航\n去接");
        bindingView.btnTopR.setText("接到\n乘客");
        bindingView.btnMidL.setText("取消\n订单");



        String orderTime = SPTool.getString(context,Constant.GetOrderTime);
        long orderTimeSec = Long.parseLong(orderTime);

        Date date =  new Date();
        long nowSec =  (date.getTime() / 1000); // 60*60*1000


        int FinishOrderTime = SPTool.getInt(this,Constant.FinishOrderTimeStr);

//        ToastUtil.show(context,"FinishOrderTime = "+FinishOrderTime);

        if(nowSec - orderTimeSec <FinishOrderTime){

            timer = new FinishOrderTimer((FinishOrderTime-(nowSec - orderTimeSec))*1000, 1000,  bindingView.btnMidR,orderDetailsActivity);
            timer.start();
        }else {
            bindingView.btnMidR.setText("完成订单");
        }



        bindingView.btnBottonL.setText("重发\n订单");
        bindingView.btnBottonR.setText("投诉\n司机");
        bindingView.tvTel.setText(SPTool.getMyPushOrderInfo(this).body.voice_tell);

        bindingView.btnTopL.setOnClickListener(this);
        bindingView.llDaoHang.setOnClickListener(this);
        bindingView.btnTopR.setOnClickListener(this);
        bindingView.btnMidL.setOnClickListener(this);
        bindingView.btnMidR.setOnClickListener(this);
        bindingView.llFinishOrder.setOnClickListener(this);
        bindingView.btnBottonL.setOnClickListener(this);
        bindingView.llComplain.setOnClickListener(this);
        bindingView.btnListen.setOnClickListener(this);
        bindingView.llTel.setOnClickListener(this);

    }


//    @Override
//    public void onBackPressed() {
//        ToastUtil.show(OrderDetailsActivity.this,"任务没有完成，不能返回！");
//    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.btnTopL://地图导航
            case R.id.llDaoHang://地图导航


                Log.i("asas","地图导航  "+SPTool.getMyPushOrderInfo(this).toString());

                if(SPTool.getMyPushOrderInfo(this).body.voice_lat == null){
                    ToastUtil.show(this,"没有获取到乘客位置");
                }else {
                    MapDialog.showSheet(this, this, this);
                }

                break;

            case R.id.btnTopR://接到乘客

                showReceiveDialog(2, "提示", "接到乘客?");

                break;

            case R.id.btnMidL://取消订单


                showTipDialog(2, "提示", "取消订单?");


                break;

            case R.id.btnMidR://完成订单
            case R.id.llFinishOrder://完成订单


                showFinishDialog(2, "提示", "完成订单?");


                break;

            case R.id.btnBottonL://重发订单

                showRepeatDialog(2, "提示", "重发订单?");

                break;

            case R.id.llComplain://投诉

                showSinpleChioceDialog();

                break;

            case R.id.btnListen://听单

                MyApplication.playMedia(SPTool.getMyPushOrderInfo(this), LocalService.myService.mHandler);

                break;

            case R.id.btnCall://打电话
            case R.id.llTel://打电话

                getTel();

                break;


        }
    }


    //////////////////打电话///////////////////
    void getTel() {



        try {
            if (SPTool.getMyPushOrderInfo(this) == null) {
                return;
            }
            String tel = "";
            tel = SPTool.getMyPushOrderInfo(this).body.voice_tell;
            Log.i("bbbbbb", "tel==" + tel);
            Intent call = new Intent(Intent.ACTION_DIAL);
            Uri data = Uri.parse("tel:" + tel);
            call.setData(data);
            startActivity(call);
        } catch (Exception e) {
        }
    }
    //////////////////打电话///////////////////





    ////////////////////////完成订单////////////////////////
    FinishOrderModelImpl finishOrderModel = null;
    void finishorder(String statue) {
        if (finishOrderModel == null) {
            finishOrderModel = new FinishOrderModelImpl();
        }


        UserInfoBean userInfoBean = SPTool.getUserInfo(context);

        if (userInfoBean == null) {
            return;
        }


        showProgressDialog("请稍等...");
        FinishOrderParam param = new FinishOrderParam("getDriverendVoicer", statue,
                userInfoBean.body.driver_id,
                SPTool.getMyPushOrderInfo(this).body.voice_order,
                SPTool.getString(context, "Driver_Lat"),
                SPTool.getString(context, "Driver_Lon")
        );

        finishOrderModel.sendFinishOrder(param, this);

    }

    @Override
    public void OnFinishOrderSuccess(String str) {

        try {  timer.cancel(); }catch (Exception e){Log.e("516","1   "+e.toString());}
        try { SPTool.putString(context, Constant.PushOrderBean, "");       }catch (Exception e){Log.e("516","1   "+e.toString());}
        try { SPTool.putString(MyApplication.getContext(), Constant.PushOrderBean, "");       }catch (Exception e){Log.e("516","2   "+e.toString());}
        try { SPTool.putString(context, Constant.MyPushOrderBean, "");       }catch (Exception e){Log.e("516","3   "+e.toString());}
        try { SPTool.putString(MyApplication.getContext(), Constant.MyPushOrderBean, "");       }catch (Exception e){Log.e("516","4   "+e.toString());}
        try { ToastUtil.show( context, str);     }catch (Exception e){Log.e("516","5   "+e.toString());}
        try { dissmissProgressDialog();       }catch (Exception e){Log.e("516","6   "+e.toString());}
        try { MainActivity.mainActivity.onResume();       }catch (Exception e){Log.e("516","7   "+e.toString());}
        try { orderDetailsActivity.finish();       }catch (Exception e){Log.e("516","8   "+e.toString());}

    }

    @Override
    public void OnFinishOrderError(String err) {
        Log.i("cccccc", "完成订单 Error==" + err);
        ToastUtil.show( context, err);
        dissmissProgressDialog();
        if(err.contains("点击接到乘客")){
            yuYin(err);
            return;
        }

        try {  timer.cancel(); }catch (Exception e){Log.e("516","1   "+e.toString());}
        try { SPTool.putString(context, Constant.PushOrderBean, "");       }catch (Exception e){Log.e("516","1   "+e.toString());}
        try { SPTool.putString(MyApplication.getContext(), Constant.PushOrderBean, "");       }catch (Exception e){Log.e("516","2   "+e.toString());}
        try { SPTool.putString(context, Constant.MyPushOrderBean, "");       }catch (Exception e){Log.e("516","3   "+e.toString());}
        try { SPTool.putString(MyApplication.getContext(), Constant.MyPushOrderBean, "");       }catch (Exception e){Log.e("516","4   "+e.toString());}
        try { MainActivity.mainActivity.onResume();       }catch (Exception e){Log.e("516","7   "+e.toString());}
        try { orderDetailsActivity.finish();       }catch (Exception e){Log.e("516","8   "+e.toString());}



    }
    ////////////////////////完成订单////////////////////////




    //////////////////司机投诉///////////////////
    //投诉显示单选对话框
    int mWhich;
    public void showSinpleChioceDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("选择投诉:");
//		builder.setIcon(R.drawable.driver_icon);
        final String[] items = new String[]{"爽约", "不文明",};
        builder.setSingleChoiceItems(items, 0, new DialogInterface.OnClickListener() {/*设置单选条件的点击事件*/
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mWhich = which;
            }
        });
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                touSu(mWhich);
            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        builder.setCancelable(false);
        builder.show();
    }

    private ComplaintOrderModelImpl complaintOrderModel;//comlain

    void touSu(int which) {
        if (complaintOrderModel == null) {
            complaintOrderModel = new ComplaintOrderModelImpl();
        }
        try {

            if (SPTool.getMyPushOrderInfo(context) == null) {
                return;
            }

            ComplaintParam param;
            param = new ComplaintParam("getDrivercomplaint", which + "",
                    SPTool.getMyPushOrderInfo(this).body.voice_tell ,
                    SPTool.getMyPushOrderInfo(context).body.voice_order,
                    SPTool.getMyPushOrderInfo(this).body.voice_tell);
            complaintOrderModel.sendComplaint(param, this);
        } catch (Exception e) {
        }
    }

    @Override
    public void onComplaintSuccess(String str) {
        ToastUtil.show(context,str);
    }

    @Override
    public void onComplaintError(String errStr) {
        ToastUtil.show(context,errStr);
    }
    //////////////////司机投诉///////////////////





    //////////////////取消订单///////////////////
    DriverCancelModelImpl cancelModel;

    void driverCancel(){

        if(SPTool.getUserInfo(this)==null){
            return;
        }

        if(cancelModel == null){
            cancelModel = new DriverCancelModelImpl();
        }

        DriverCancelParam param;
        param = new DriverCancelParam("driverCancel",SPTool.getUserInfo(this).body.driver_id,SPTool.getMyPushOrderInfo(this).body.voice_order);
        cancelModel.driverCancel(param,this);
    }

    @Override
    public void onDriverCancelSuccess(DriverCancelBean bean) {

        if(timer!=null){
            timer.cancel();
        }

        ToastUtil.show(context,bean.msg);
        SPTool.putString(context, Constant.PushOrderBean, "");
        SPTool.putString(context, Constant.MyPushOrderBean, "");
        finish();
    }

    @Override
    public void onDriverCancelError(String errStr) {
        ToastUtil.show(context,errStr);
    }
    //////////////////取消订单///////////////////


    //////////////////重发订单///////////////////
    OrderRepeatModelImpl repeatModel;
    void orderRepeat(){



        if(SPTool.getUserInfo(this)==null){
            return;
        }

        if(repeatModel == null){
            repeatModel = new OrderRepeatModelImpl();
        }
        OrderRepeatParam param;
        param = new OrderRepeatParam("orderRepeat",SPTool.getUserInfo(this).body.driver_id,SPTool.getMyPushOrderInfo(this).body.voice_order);

        SPTool.putString(context, Constant.PushOrderBean, "");
        SPTool.putString(context, Constant.MyPushOrderBean, "");

        repeatModel.orderRepeat(param,this);
    }

    @Override
    public void onOrderRepeatSuccess(OrderRepeatBean bean) {
//        SPTool.putString(context, Constant.PushOrderBean, "");
//        SPTool.putString(context, Constant.MyPushOrderBean, "");
        timer.cancel();
        finish();
    }

    @Override
    public void onOrderRepeatError(String errStr) {
//        SPTool.putString(context, Constant.PushOrderBean, "");
//        SPTool.putString(context, Constant.MyPushOrderBean, "");
        finish();
    }
    //////////////////重发订单///////////////////






    //////////////////进度框进度框进度框///////////////////
    //显示进度框
    private ProgressDialog progDialog = null;//
    private void showProgressDialog(String str) {
        if (progDialog == null)
            progDialog = new ProgressDialog(this);
        progDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progDialog.setIndeterminate(false);
        progDialog.setCancelable(true);
        progDialog.setMessage(str);
        progDialog.show();

    }
    //隐藏进度框
    private void dissmissProgressDialog() {
        if (progDialog != null) {
            progDialog.dismiss();
        }
    }
    //////////////////进度框进度框进度框///////////////////


    //////////////////选择地图对话框///////////////////
    @Override
    public void onCancel(DialogInterface dialog) {

    }

    @Override
    public void onCameraClick(int whichButton) {
        switch (whichButton) {
            case 0: {//高德

                try {



                    Intent intent = Intent.getIntent("androidamap://viewMap?" +
                            "sourceApplication=中国&" +
                            "poiname=乘客位置&" +
//                            "lat="+"40.047669&" +
//                            "lon=116.313082&" +
                            "lat="+SPTool.getMyPushOrderInfo(this).body.voice_lat +"&"+
                            "lon="+SPTool.getMyPushOrderInfo(this).body.voice_lng +"&"+
                            "dev=0");

                    Log.i("onCameraClick","lat="+SPTool.getMyPushOrderInfo(this).body.voice_lat);
                    Log.i("onCameraClick","lon="+SPTool.getMyPushOrderInfo(this).body.voice_lng);


                    Log.i("onCameraClick","lat="+"40.047669");
                    Log.i("onCameraClick","lon=116.313082");

                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                     ToastUtil.show(context,"请先安装高德地图");
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }

                break;
            }
            case 1: {//百度

                try {
                    Intent intent = null;
                    intent = Intent.getIntent("intent://map/marker?" +
//                            "location=40.047669,116.313082&" +
                            "location="+SPTool.getMyPushOrderInfo(this).body.voice_lat+","+SPTool.getMyPushOrderInfo(this).body.voice_lng+"&" +
                            "title=我的位置&" +
                            "content=乘客位置&" +
                            "src=yourCompanyName|yourAppName#Intent;scheme=bdapp;package=com.baidu.BaiduMap;end");
                    startActivity(intent); //启动调用
                } catch (ActivityNotFoundException e) {
                    ToastUtil.show(context,"请先安装百度地图");
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }


                break;
            }
        }
    }
    //////////////////选择地图对话框///////////////////




    /////////////////////////提示对话框/////////////////////////
    public Dialog dialog;
    public TextView btn_one;
    public TextView btn_right;



    public interface ClickSureListener {
        public void click();
    }

    private ClickSureListener clickSureListener;

    public void showTipDialog(int type, String titleStr, String contentStr) {
        if (dialog == null) {
            dialog = new AlertDialog.Builder(this).create();
        }

        LayoutInflater inflater = LayoutInflater.from(this);
        View view = (View) inflater.inflate(R.layout.dialog_base, null);
        TextView title = (TextView) view.findViewById(R.id.title);
        TextView content = (TextView) view.findViewById(R.id.content);
        btn_one = (TextView) view.findViewById(R.id.btn_one);
        LinearLayout layout = (LinearLayout) view
                .findViewById(R.id.bottom_layout);
        btn_right = (TextView) view.findViewById(R.id.btn_right);
        if (type == 1) {
            btn_one.setVisibility(View.VISIBLE);
            layout.setVisibility(View.GONE);
        } else if (type == 2) {
            btn_one.setVisibility(View.GONE);
            layout.setVisibility(View.VISIBLE);
        }
        btn_one.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });

        btn_right.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });
        title.setText(titleStr);
        content.setText(contentStr);

        view.findViewById(R.id.btn_left).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

        view.findViewById(R.id.btn_right).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        driverCancel();
                        dialog.dismiss();
                    }
                });

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.show();
        dialog.getWindow().setContentView(view);
    }


    public void showReceiveDialog(int type, String titleStr, String contentStr) {
        if (dialog == null) {
            dialog = new AlertDialog.Builder(this).create();
        }

        LayoutInflater inflater = LayoutInflater.from(this);
        View view = (View) inflater.inflate(R.layout.dialog_base, null);
        TextView title = (TextView) view.findViewById(R.id.title);
        TextView content = (TextView) view.findViewById(R.id.content);
        btn_one = (TextView) view.findViewById(R.id.btn_one);
        LinearLayout layout = (LinearLayout) view
                .findViewById(R.id.bottom_layout);
        btn_right = (TextView) view.findViewById(R.id.btn_right);
        if (type == 1) {
            btn_one.setVisibility(View.VISIBLE);
            layout.setVisibility(View.GONE);
        } else if (type == 2) {
            btn_one.setVisibility(View.GONE);
            layout.setVisibility(View.VISIBLE);
        }
        btn_one.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });

        btn_right.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });
        title.setText(titleStr);
        content.setText(contentStr);

        view.findViewById(R.id.btn_left).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

        view.findViewById(R.id.btn_right).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        driverGetUser();
                        dialog.dismiss();
                    }
                });

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.show();
        dialog.getWindow().setContentView(view);
    }


    public void showRepeatDialog(int type, String titleStr, String contentStr) {
        if (dialog == null) {
            dialog = new AlertDialog.Builder(this).create();
        }

        LayoutInflater inflater = LayoutInflater.from(this);
        View view = (View) inflater.inflate(R.layout.dialog_base, null);
        TextView title = (TextView) view.findViewById(R.id.title);
        TextView content = (TextView) view.findViewById(R.id.content);
        btn_one = (TextView) view.findViewById(R.id.btn_one);
        LinearLayout layout = (LinearLayout) view
                .findViewById(R.id.bottom_layout);
        btn_right = (TextView) view.findViewById(R.id.btn_right);
        if (type == 1) {
            btn_one.setVisibility(View.VISIBLE);
            layout.setVisibility(View.GONE);
        } else if (type == 2) {
            btn_one.setVisibility(View.GONE);
            layout.setVisibility(View.VISIBLE);
        }
        btn_one.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });

        btn_right.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub

                clickSureListener.click();
            }
        });
        title.setText(titleStr);
        content.setText(contentStr);

        view.findViewById(R.id.btn_left).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

        view.findViewById(R.id.btn_right).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        orderRepeat();
                        dialog.dismiss();
                    }
                });

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.show();
        dialog.getWindow().setContentView(view);
    }


    public void showFinishDialog(int type, String titleStr, String contentStr) {
        if (dialog == null) {
            dialog = new AlertDialog.Builder(this).create();
        }

        LayoutInflater inflater = LayoutInflater.from(this);
        View view = (View) inflater.inflate(R.layout.dialog_base, null);
        TextView title = (TextView) view.findViewById(R.id.title);
        TextView content = (TextView) view.findViewById(R.id.content);
        btn_one = (TextView) view.findViewById(R.id.btn_one);
        LinearLayout layout = (LinearLayout) view
                .findViewById(R.id.bottom_layout);
        btn_right = (TextView) view.findViewById(R.id.btn_right);
        if (type == 1) {
            btn_one.setVisibility(View.VISIBLE);
            layout.setVisibility(View.GONE);
        } else if (type == 2) {
            btn_one.setVisibility(View.GONE);
            layout.setVisibility(View.VISIBLE);
        }
        btn_one.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });

        btn_right.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub

                clickSureListener.click();
            }
        });
        title.setText(titleStr);
        content.setText(contentStr);

        view.findViewById(R.id.btn_left).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

        view.findViewById(R.id.btn_right).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finishorder("2");
                        dialog.dismiss();
                    }
                });

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.show();
        dialog.getWindow().setContentView(view);
    }

    /////////////////////////提示对话框/////////////////////////


    /////////////////////////接到乘客/////////////////////////

    DriverGetUserModelImpl getUserModel;
    void driverGetUser (){//travel/drivergetuserInfo.action?method=drivergetuser

        if(getUserModel == null){
            getUserModel = new DriverGetUserModelImpl();
        }

        UserInfoBean userInfoBean = SPTool.getUserInfo(context);

        if (userInfoBean == null) {
            return;
        }

        DriverGetUserParam param;
        param = new DriverGetUserParam("drivergetuser",
                userInfoBean.body.driver_id,
                SPTool.getMyPushOrderInfo(this).body.voice_order);
        getUserModel.getUser(param,this);


    }


    @Override
    public void onDriverGetUserSuccess(DriverGetUserBean bean) {
        ToastUtil.show(this,"已提交平台");
    }

    @Override
    public void onDriverGetUserError(String errStr) {
        ToastUtil.show(this,"失败!");
    }

    /////////////////////////接到乘客/////////////////////////







    public static void start(Context mContext) {
        Intent intent = new Intent(mContext, OrderDetailsActivity.class);
        mContext.startActivity(intent);
    }

    MiniTTS tts;//语音播报
    void  yuYin (final String str){


        performRequestPermissions(getString(R.string.permission_imei),
                new String[]{
                        Manifest.permission.MODIFY_AUDIO_SETTINGS
                }
                , PER_REQUEST_CODE,
                new PermissionResultListener() {
                    @Override
                    public void onPermissionDenied() {

                    }

                    @Override
                    public void onPermissionGranted() {

                        try {

                            tts = new MiniTTS(context);
                            tts.initPermission().initTTs();
                            tts.speak(str);
//                                    tts.speak("测试2");

                        }catch (Exception E)
                        {
                            E.printStackTrace();
                        }

                    }
                });
    }



    final protected int PER_REQUEST_CODE =0;
    //请求码
    private int mRequestCode;
    //运行时权限接口
    private PermissionResultListener mListener;
    protected void performRequestPermissions(String desc, String[] permissions,
                                             int requestCode,
                                             PermissionResultListener listener) {
        if (permissions == null || permissions.length == 0) {
            return;
        }
        mRequestCode = requestCode;
        mListener = listener;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkEachSelfPermission(permissions)) {// 检查是否声明了权限
                requestEachPermissions(desc, permissions, requestCode);
            } else {// 已经申请权限
                if (mListener != null) {
                    mListener.onPermissionGranted();
                }
            }
        } else {
            if (mListener != null) {
                mListener.onPermissionGranted();
            }
        }
    }



    /**
     * 检察每个权限是否申请
     *
     * @param permissions
     * @return true 需要申请权限,false 已申请权限
     */
    private boolean checkEachSelfPermission(String[] permissions) {
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) !=
                    PackageManager.PERMISSION_GRANTED) {
                return true;
            }
        }
        return false;
    }

    private void requestEachPermissions(String desc, String[] permissions, int requestCode) {
        if (shouldShowRequestPermissionRationale(permissions)) {// 需要再次声明
            showRationaleDialog(desc, permissions, requestCode);
        } else {
            ActivityCompat.requestPermissions(this, permissions, requestCode);
        }
    }


    /**
     * 再次申请权限时，是否需要声明
     *
     * @param permissions
     * @return
     */
    private boolean shouldShowRequestPermissionRationale(String[] permissions) {
        for (String permission : permissions) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 弹出声明的 Dialog
     *
     * @param desc
     * @param permissions
     * @param requestCode
     */
    private void showRationaleDialog(String desc, final String[] permissions,
                                     final int requestCode) {
        final android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.tips))
                .setMessage(desc)
                .setPositiveButton(getResources().getString(R.string.sure),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                ActivityCompat.requestPermissions(OrderDetailsActivity.this,
                                        permissions, requestCode);
                            }
                        })
                .setNegativeButton(getResources().getString(R.string.cancel),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        })
                .setCancelable(false)
                .show();
    }





}