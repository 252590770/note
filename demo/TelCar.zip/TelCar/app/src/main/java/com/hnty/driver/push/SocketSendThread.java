package com.hnty.driver.push;

import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.google.gson.Gson;
import com.hnty.driver.R;
import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.EventBean;
import com.hnty.driver.entity.PushCode;
import com.hnty.driver.entity.PushOrderBean;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.util.MsgBox;
import com.hnty.driver.util.SPTool;
import com.hnty.driver.util.ToastUtil;
import com.hnty.driver.util.VoiceUtils;

import org.greenrobot.eventbus.EventBus;


/**
 * 开关机注销
 *
 * @author Silence
 */
public class SocketSendThread extends Thread {

    private Context context;
    private ClientSocket mSocket;
    private boolean mConectFlag = false;
    private String msgByte;
    private int command;
    private Handler mHandler;

    public SocketSendThread(Context context,ClientSocket socket, String msgByte,
                            int command, Handler handler) {
        super();
        this.context = context;
        this.mSocket = socket;
        this.msgByte = msgByte;
        this.command = command;
        this.mHandler = handler;


    }

    @Override
    public void run() {
        super.run();


        if (mSocket == null) {
            mSocket = new ClientSocket(ConnectURL.TCP_PORT);

        }



       if (!mConectFlag) {
            mConectFlag = mSocket.createConnection();
       }


//        if (mSocket!=null) {
//            mSocket.createConnection();
//        }


        Log.i("cccccc", "run()" + "    1");

        byte[] readbuff = new byte[1024 * 50];
        try {
            Log.i("cccccc", "run()" + "    2");
            String driver_id = msgByte;
            String driverParam = "";
            Log.i("cccccc", "driver_id == " + driver_id);

            if (driver_id.length() == 1) {
                driverParam = "     " + driver_id;
            } else if (driver_id.length() == 2) {
                driverParam = "    " + driver_id;
            } else if (driver_id.length() == 3) {
                driverParam = "   " + driver_id;
            } else if (driver_id.length() == 4) {
                driverParam = "  " + driver_id;
            } else if (driver_id.length() == 5) {
                driverParam = " " + driver_id;
            } else if (driver_id.length() == 6) {
                driverParam = "" + driver_id;
            } else if (driver_id.length() > 6) {
                ToastUtil.show(MyApplication.getContext(), "用户数量超过限制,请联系技术人员!");
            }

            String carNo =  SPTool.getString(context,Constant.CarNo);

            Log.i("419","carNo.length = "+carNo.length());

            String carNoFormat = String.format("%1$-10s",carNo);

            Log.i("419","carNoFormat = "+carNoFormat);
            driverParam+=carNoFormat;




            mSocket.sendLogin(driverParam, 0x01);

            DataInputStream inputstream;
            int ilen = 0;
            while (true) {
                if (mSocket.socket == null) {
                    mHandler.sendEmptyMessage(MsgBox.MSG_SHUTDOWN_FAILED);
                    break;
                }

                if (mSocket.socket.isClosed()) {
                    mHandler.sendEmptyMessage(MsgBox.MSG_SHUTDOWN_FAILED);
                    break;
                }
                if (!mSocket.socket.isConnected()) {
                    mHandler.sendEmptyMessage(MsgBox.MSG_SHUTDOWN_FAILED);
                    break;
                }
                Arrays.fill(readbuff, (byte) 0);//清空数组

                inputstream = mSocket.getMessageStream();
                if (inputstream.available()>0)
                {
                    ilen = inputstream.read(readbuff);

                    if (readbuff[0] == 0x5a && readbuff[2] == 0x04) {
                        mHandler.sendEmptyMessage(MsgBox.MSG_BEAT);

                    } else if (readbuff[0] == 0x5a && readbuff[2] == 0x01) {
                        Message msg = new Message();
                        msg.what = MsgBox.MSG_SHUTDOWN_SUCCESS;
                        msg.obj = mSocket;
                        mHandler.sendMessage(msg);

                    } else if (readbuff[0] == 0x5a && readbuff[2] == 0x03) {//新订单推送

                        String content = new String(readbuff, 9, ilen).trim();
                        Message msg = new Message();
                        msg.what = MsgBox.MSG_CONTENT;
                        msg.obj = content;

                        Log.e("cccccc", "接收到的消息  0x03  content  == " + content);
                        PushCode bean = new Gson().fromJson(content, PushCode.class);


                        Log.e("7181","1");


                        if( bean.code == 1003){ //别人接单  推送的消息

                            msg.what = MsgBox.MSG_ON_OTHER_ORDER;
                            msg.obj = content;
                            mHandler.sendMessage(msg);

                            Log.e("7181","2");


                        }else if( bean.code == 1008){

                            EventBus.getDefault().post(new EventBean(1008,(String)msg.obj));

                            Log.e("7181","3");

                        }else if( bean.code == 1009){//跑腿

                            Log.e("7181","4");

                            if(SPTool.getBoolean(context,Constant.ReceiveRun)){
                                SPTool.putString(MyApplication.getContext(), Constant.PushOrderBean, content);
                                MyApplication.getOrderList().add(SPTool.getPushOrderInfo(context));
                                Log.i("dd   订单", "接收到新订单   存储到集合 1");
                                msg.what = MsgBox.MSG_CONTENT;
                                mHandler.sendMessage(msg);
//                                MyApplication.getInstance().playRunOrder();
                            }


                        }else if( bean.code == 1010){//代驾


                            Log.e("7181","5");


                            if(SPTool.getBoolean(context,Constant.ReceiveDrive)){
                                SPTool.putString(MyApplication.getContext(), Constant.PushOrderBean, content);
                                MyApplication.getOrderList().add(SPTool.getPushOrderInfo(context));
                                Log.i("dd   订单", "接收到新订单   存储到集合2");
                                msg.what = MsgBox.MSG_CONTENT;
                                mHandler.sendMessage(msg);
                                MyApplication.getInstance().playDriveOrder();
                            }

                        }else {

                            Log.e("7181","6");



                            SPTool.putString(MyApplication.getContext(), Constant.PushOrderBean, content);
                            MyApplication.getOrderList().add(SPTool.getPushOrderInfo(context));
                            Log.i("dd   订单", "接收到新订单   存储到集合3");
                            msg.what = MsgBox.MSG_CONTENT;
                            mHandler.sendMessage(msg);
//                            MyApplication.getInstance().playNewOrder();
                            EventBus.getDefault().post(new EventBean(1020));


                        }
                        Log.i("cccccc", "接收到的消息  PushOrderBean  == " + bean.toString());
                    }else if (readbuff[0] == 0x5a && readbuff[2] == 0x05) {//踢下线


                        String content = new String(readbuff, 3, ilen).trim();
                        Log.e("out", "接收到的消息  0x05  content  == " + content);
                        Message msg = new Message();
                        msg.what = MsgBox.MSG_ON_CAR_NO_SAME;
                        msg.obj = content;

                        if(content.trim().equals( SPTool.getString(context,Constant.CarNo))){

                            mHandler.sendMessage(msg);
                            MyApplication.getInstance().driverOutLine();

                        }
                    }else if (readbuff[0] == 0x5a && readbuff[2] == 0x06) {

                        String content = new String(readbuff, 3, ilen).trim();
                        Log.e("out", "接收到的消息  content  == " + content);


                        Message msg = new Message();
                        msg.what = MsgBox.MSG_ON_NOTICE;
                        msg.obj = content;
                        mHandler.sendMessage(msg);
                    }
                }else
                {
                    Log.e("socketmain", "no data");
                }

                sleep(500);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            mHandler.sendEmptyMessage(MsgBox.MSG_SHUTDOWN_FAILED);
        }


    }

    /**
     * 发送命令
     *
     * @param
     */
    private boolean sendData() {
        byte[] readbuff = new byte[128];
        try {
            DataInputStream inputstream = mSocket.getMessageStream();
            int ilen = inputstream.read(readbuff);
            if (ilen >= 3) {
                if (readbuff[0] == 0x5a && readbuff[3] == command) {
                    mHandler.sendEmptyMessage(MsgBox.MSG_SHUTDOWN_SUCCESS);
                    Log.e("ilen+++++++++++", "====" + command);

                    return true;
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }


        return false;
    }

    /**
     * 发送消息
     *
     * @param what
     * @param object
     */
    private void sendMessage(int what, Object object) {
        Message msg = new Message();
        msg.what = what;
        msg.obj = object;
        mHandler.sendMessage(msg);

    }
}
