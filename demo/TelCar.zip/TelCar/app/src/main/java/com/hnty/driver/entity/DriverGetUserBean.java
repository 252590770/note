package com.hnty.driver.entity;

/**
 * Created by L on 2018/1/11.
 */

public class DriverGetUserBean {



    public int code;
    public String msg;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
