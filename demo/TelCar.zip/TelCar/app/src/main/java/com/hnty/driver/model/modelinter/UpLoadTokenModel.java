package com.hnty.driver.model.modelinter;


import com.hnty.driver.entity.UpLoadTokenParam;
import com.hnty.driver.inter.OnUpLoadTokenListener;

/**
 * Created by L on 2018/1/12.
 */

public interface UpLoadTokenModel {

    void upLoadToken(UpLoadTokenParam param, OnUpLoadTokenListener listener);

}
