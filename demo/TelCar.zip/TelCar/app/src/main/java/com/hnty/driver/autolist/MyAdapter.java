package com.hnty.driver.autolist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;


import com.hnty.driver.MainActivity;
import com.hnty.driver.R;
import com.hnty.driver.entity.PastOrderListBean;
import com.hnty.driver.entity.VoiceOrderListBean;
import com.hnty.driver.util.MyUtil;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class MyAdapter extends BaseAdapter
{
	List<PastOrderListBean.BodyBean> items;
	Context context;

	public MyAdapter(Context context, List<PastOrderListBean.BodyBean> items)
	{
		this.context = context;
		this.items = items;
	}


	public void refresh(List<PastOrderListBean.BodyBean> items)
	{
		this.items.clear();
		this.items.addAll(items);
		notifyDataSetChanged();
	}


	public void refresh(List<PastOrderListBean.BodyBean> items, ListView listView)
	{
		this.items.clear();
		this.items.addAll(items);
		notifyDataSetChanged();


		listView.scrollTo(0,0);
	}

	public void addItem(List<PastOrderListBean.BodyBean> items)
	{
		this.items.addAll(items);
		notifyDataSetChanged();
	}

	@Override
	public int getCount()
	{
		return items.size();
	}

	@Override
	public Object getItem(int position)
	{
		return items.get(position);
	}

	@Override
	public long getItemId(int position)
	{
		return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {

		ViewHolder holder;
		if(convertView == null){
			convertView = LayoutInflater.from(context).inflate(R.layout.item_main_order_list,null);
			holder = new ViewHolder();
			holder.tvTel = (TextView) convertView.findViewById(R.id.tvTel);
			holder.tvTime = (TextView) convertView.findViewById(R.id.tvTime);
			convertView.setTag(holder);
		}else {
			holder = (ViewHolder) convertView.getTag();
		}

		holder.tvTel.setText("乘客电话:"+MyUtil.TelNoToStarts(items.get(position).voice_tell.trim()));
		try {
			SimpleDateFormat CeshiFmt1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// HH   // 24小时制
			Date mDate = CeshiFmt1.parse(items.get(position).oper_date.trim());
			SimpleDateFormat CeshiFmt11 = new SimpleDateFormat("MM-dd HH:mm:ss");// HH  07-05 12:00
			holder.tvTime.setText("下单时间:"+CeshiFmt11.format(mDate));
		} catch (ParseException e) {
			e.printStackTrace();
		}




//		holder.tvTime.setText("下单时间:"+"上午 12:20:30");
//		holder.tvTel.setText("乘客电话:"+"15339202227");


//		if(items.get(position).voice_state.equals("0")){
//			holder.llBack.setBackgroundColor(context.getResources().getColor(R.color.white));
//		}else if(items.get(position).voice_state.equals("1")) {
//			holder.llBack.setBackgroundColor(context.getResources().getColor(R.color.azure));
//		}else if(items.get(position).voice_state.equals("2")) {
//			holder.llBack.setBackgroundColor(context.getResources().getColor(R.color.baby_blue));
//		}else if(items.get(position).voice_state.equals("3")) {
//			holder.llBack.setBackgroundColor(context.getResources().getColor(R.color.baby_blue));
//		}

		return convertView;
	}

	class ViewHolder {
		TextView tvTel,tvTime;
//		LinearLayout llBack;
	}

}
