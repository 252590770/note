package com.hnty.driver.model.modelimpl;

import android.util.Log;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.inter.OnPosyListener;
import com.hnty.driver.util.NetworkUtil;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by L on 2018/1/12.
 */

public class GetPosyModelImpl {


    public interface OnGetPosyListener {
        void onGetPosySuccess(String cede);
        void onGetPosyError(String errStr);
    }


    public void getPosy(String billNo  , final OnGetPosyListener listener) {

        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            listener.onGetPosyError("没有网络o");
            return;
        }

        MyApplication.getAPI().getPosy("getPosy",billNo)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<String>(){

                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull String bean) {

                        Log.i("code","onNext");

                        try {
                            listener.onGetPosySuccess(bean);
                        }catch (Exception e){
                            listener.onGetPosyError("数据错误");
                        }
                    }
                    @Override
                    public void onError(@NonNull Throwable e) {
                        listener.onGetPosyError(e.toString());
                    }

                    @Override
                    public void onComplete() {
                    }
                });


    }




}
