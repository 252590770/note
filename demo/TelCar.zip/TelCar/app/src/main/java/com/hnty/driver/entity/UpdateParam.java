package com.hnty.driver.entity;

/**
 * Created by L on 2018/1/11.
 */

public class UpdateParam {
    public String method;

    public UpdateParam() {
    }

    public UpdateParam(String method) {
        this.method = method;
    }
}
