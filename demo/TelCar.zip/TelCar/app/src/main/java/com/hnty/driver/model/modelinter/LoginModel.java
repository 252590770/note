package com.hnty.driver.model.modelinter;


import com.hnty.driver.entity.GetListParam;
import com.hnty.driver.entity.LoginParam;
import com.hnty.driver.inter.OnGetListInfoListener;
import com.hnty.driver.inter.OnLoginListener;

/**
 * Created by L on 2018/1/12.
 */

public interface LoginModel {

    void sendLogin(LoginParam param, OnLoginListener loginListener);

}
