package com.hnty.driver.push;

import com.hnty.driver.finals.Constant;

public class ConnectURL {
	/*** URL */
	public static String REMOTE_IP = "192.168.0.197";
	// public static String REMOTE_IP = "220.174.161.163";
	public static String TCP_IP = Constant.IP;
	/*** 端口 */
	 public static String PORT = Constant.PORT+"";
	/*** IP和端口 */
	public static String IP_POST = "http://" + REMOTE_IP + PORT;
	/***  */
	public static String LOGINSTR = "/CustomPostManger";
	// public static String LOGINSTR = "/CustomPost";
	/*** TCP端口 */
	public static int TCP_PORT = Constant.TCP_PORT;
	/*** 上传文件 */
	public static String UPLOAD_FILE_URL = LOGINSTR
			+ "/uploadFileInfo.action?method=uploadFileInformation";
	/*** 上传文件 */
	// public static String UPLOAD_FILE_URL = LOGINSTR
	// + "/uploadFile.action?method=insertFileInfos";
	/*** 打开文件 */
	public static String OPEN_FILE_URL = LOGINSTR
			+ "/openFile.action?method=openFileUrl&file_name=";
	/*** 修改密码 */
	public static String EDIT_PASS_URL = LOGINSTR
			+ "/updateUserInfo.action?method=updateInformation";
	/*** 修改密码 */
	public static String EDIT_PASS_NO_PIC_URL = LOGINSTR
			+ "/updateUserInformation.action?method=updateUserInfo";
	/** 注册接口 */
	public static String REGISTER_USER_URL = LOGINSTR
			+ "/registerUser.action?method=regist";
	/** 登录接口 */
	public static String LOGIN_URL = LOGINSTR
			+ "/loginUser.action?method=login";
	/** 查询默认设备上面的所有文件 */
	public static String SEARCH_DEFAULT_FILE_URL = LOGINSTR
			+ "/searchDefaultFile.action?method=searchDefaultFileInfo";
	/** 根据设备编号查询所有文件 */
	public static String SEARCH_FILE_ORDER_DEVICE_URL = LOGINSTR
			+ "/searchFileOrderDeviceNo.action?method=searchFileOrderDeviceNo";
	/** 根据设备编号查询所有文件 */
	public static String SEARCH_ALL_FILE_URL = LOGINSTR
			+ "/searchAllFileInfo.action?method=searchAllFile";
	/** 查询默认设备 */
	public static String SEARCH_DEFAULT_DEVICE_URL = LOGINSTR
			+ "/searchDeviceNo.action?method=searchDefaultDeviceInfo";
	/** 查询所有设备 */
	public static String SEARCH_ALL_DEVICE_URL = LOGINSTR
			+ "/searchAllDeviceNo.action?method=searchAllDeviceInfo";
	/** 查询所有设备 */
	public static String QUERY_ALL_DEVICE_URL = LOGINSTR
			+ "/queryAllDeviceNo.action?method=queryAllDeviceInfo";
	/** 添加设备 */
	public static String ADD_DEVICE_URL = LOGINSTR
			+ "/addDeviceinformation.action?method=AddDeviceInfo";
	/** 删除文件 */
	public static String DELETE_FILE_URL = LOGINSTR
			+ "/deleteFileInfo.action?method=deleteFiles";
	/** 是否存在手机串码 */
	public static String QUERY_PHONE_ISMI_URL = LOGINSTR
			+ "/exitVipInfo.action?method=exitVipNo&vip_ismi_no=";
	/** APK下载地址 */
	public static String APK_DOWNLOAD = "http://" + IP_POST + LOGINSTR
			+ "/apk/customPost.apk";
	/** 获取评论 */
	public static String GET_COMMENT_URL = LOGINSTR
			+ "/searchAllComments.action?method=searchAllCommentInfo";
	/** 查询评论数量 */
	public static String GET_COMMENT_NUMBER_URL = LOGINSTR
			+ "/searchCommentNumInfo.action?method=searchCommentNum";
	/** 更改文件收费标准 */
	public static String SHARE_FREE_FILE_URL = LOGINSTR
			+ "/updateFreeTypeInfo.action?method=updateFreeType";
	/** 根据后缀名查询文件 */
	public static String SEARCH_FILE_END_NAME_URL = LOGINSTR
			+ "/searchFileEndNameInfo.action?method=searchFileEndName";
	/** 更改文件名 */
	public static String UPDATE_FILE_NAME_URL = LOGINSTR
			+ "/updateFileNameInfo.action?method=updateFileName";
	/** 打开图片文件 */
	public static String OPEN_FILE_IMAGE_URL = LOGINSTR
			+ "/openFileImage.action?method=getFileImage";
	/** 打开图片文件 */
	public static String OPEN_FILE_MEDIA_URL = LOGINSTR
			+ "/openFileMedia.action?method=getFileMedia";
	/** 查询所有点赞 */
	public static String SEARCH_ALL_STAR_URL = LOGINSTR
			+ "/searchAllStars.action?method=searchAllStar";
	/** 删除设备 */
	public static String DELETE_DEVICE_URL = LOGINSTR
			+ "/deleteDeviceinformation.action?method=deleteDevices";
	/** 更改设备名称 */
	public static String UPDATE_DEVICE_NAME_URL = LOGINSTR
			+ "/updateDeviceNameInformation.action?method=updateDeviceNameInfo";
	/** 根据VIP_ID查询文件 */
	public static String SEARCH_FILE_NAME_BY_VIPID_URL = LOGINSTR
			+ "/searchFileByVipIDInfo.action?method=searchFileByVipID";
	/** 查询APK版本号 */
	public static String QUERY_APK_VERSION_URL = LOGINSTR
			+ "/queryApkVersionInfo.action?method=queryApkVersion&id=";

	/*** 获取验证码 */
	public static final String SEND_VERIFICATION_CODE_URL = IP_POST
			+ LOGINSTR
			+ "/sendSMSInformation.action?method=sendSMSInformation&tel_number=";

}
