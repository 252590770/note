package com.hnty.driver.entity;

/**
 * Created by L on 2018/1/11.
 */

public class CodeParam {
    public String method;
    public String driver_tell;

    public CodeParam() {
    }

    public CodeParam(String method, String driver_tell) {
        this.method = method;
        this.driver_tell = driver_tell;
    }


}
