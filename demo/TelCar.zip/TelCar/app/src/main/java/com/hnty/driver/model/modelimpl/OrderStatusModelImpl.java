package com.hnty.driver.model.modelimpl;

import android.util.Log;
import android.view.LayoutInflater;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.GetOrderEntity;
import com.hnty.driver.entity.OrderStatusParam;
import com.hnty.driver.inter.OnDriverVoiceListener;
import com.hnty.driver.model.modelinter.OrderStatusModel;
import com.hnty.driver.util.NetworkUtil;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by L on 2018/1/12.
 */

public class OrderStatusModelImpl implements OrderStatusModel {


    @Override
    public void sendOrderStatus(OrderStatusParam param, final OnDriverVoiceListener listener) {

        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
//            Toast.makeText(App.getContext(), "没有网络O", Toast.LENGTH_SHORT).show();
            listener.onError( "没有网络o");
            return;
        }

        MyApplication.getAPI().sendOrderStatus(param.method,param.voice_state,param.driver_id,param.voice_order,
                                                param.getLatitude,param.getLongitude  )
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<GetOrderEntity>() {
                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull GetOrderEntity bean) {

                        Log.i("GetOrderEntity","----->"+bean.toString());

                        try {
                            if(bean.code==1){
                                listener.onSuccess(bean.msg);
                            }else if(bean.code==0){
                                listener.onError(bean.msg);
                            }

                        }catch (Exception e){
                            listener.onError(  "数据错误") ;
                        }
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        //listener.onError(new Exception("数据错误"));
                        Log.i("ccccccc","onError="+e.toString());
                    }

                    @Override
                    public void onComplete() {
                    }
                });







    }


}
