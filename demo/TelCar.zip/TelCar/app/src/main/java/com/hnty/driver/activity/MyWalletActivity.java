package com.hnty.driver.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;

import com.hnty.driver.R;
import com.hnty.driver.base.BaseActivity;

/**
 * Created by Administrator on 2017/4/27.
 */

public class MyWalletActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_wallet);
        setTitle("我的钱包");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//来保持屏幕高亮
        showContentView();
    }
    public static void start(Context mContext) {
        Intent intent = new Intent(mContext, MyWalletActivity.class);
        mContext.startActivity(intent);
    }
}
