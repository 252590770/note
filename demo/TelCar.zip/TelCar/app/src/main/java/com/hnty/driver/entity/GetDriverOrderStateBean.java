package com.hnty.driver.entity;


public class GetDriverOrderStateBean {


   

    public int code;
    public String msg;
    public BodyBean body;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public BodyBean getBody() {
        return body;
    }

    public void setBody(BodyBean body) {
        this.body = body;
    }



    public  class BodyBean {



        public String out_state;
        public String driver_rank;//排名
        public String count;//接单次数
        public String complaint_count;//接单次数
        public String voice_tell;
        public String voice_file;
        public String voice_order;
        public String voice_name;
        public String oper_date;
        public String voice_state;
        public String driver_id;
        public String lostorder_count;

        public String getOut_state() {
            return out_state;
        }

        public void setOut_state(String out_state) {
            this.out_state = out_state;
        }

        public String getVoice_tell() {
            return voice_tell;
        }

        public void setVoice_tell(String voice_tell) {
            this.voice_tell = voice_tell;
        }

        public String getVoice_file() {
            return voice_file;
        }

        public void setVoice_file(String voice_file) {
            this.voice_file = voice_file;
        }

        public String getVoice_order() {
            return voice_order;
        }

        public void setVoice_order(String voice_order) {
            this.voice_order = voice_order;
        }

        public String getVoice_name() {
            return voice_name;
        }

        public void setVoice_name(String voice_name) {
            this.voice_name = voice_name;
        }

        public String getOper_date() {
            return oper_date;
        }

        public void setOper_date(String oper_date) {
            this.oper_date = oper_date;
        }

        public String getVoice_state() {
            return voice_state;
        }

        public void setVoice_state(String voice_state) {
            this.voice_state = voice_state;
        }

        public String getDriver_id() {
            return driver_id;
        }

        public void setDriver_id(String driver_id) {
            this.driver_id = driver_id;
        }
    }
}
