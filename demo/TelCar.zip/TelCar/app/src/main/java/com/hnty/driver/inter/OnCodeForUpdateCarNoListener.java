package com.hnty.driver.inter;


import com.hnty.driver.entity.GetCodeForUpdateCarNoBean;

/**
 * Created by L on 2018/1/12.
 */

public interface OnCodeForUpdateCarNoListener {

    void onCodeSuccess(GetCodeForUpdateCarNoBean bean);
    void onCodeError(String errStr);

}
