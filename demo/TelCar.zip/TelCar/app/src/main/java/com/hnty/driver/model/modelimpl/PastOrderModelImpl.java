package com.hnty.driver.model.modelimpl;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.CodeParam;
import com.hnty.driver.entity.PastOrderListBean;
import com.hnty.driver.inter.OnCodeListener;
import com.hnty.driver.inter.OnPastOrderListener;
import com.hnty.driver.model.modelinter.CodeModel;
import com.hnty.driver.model.modelinter.PastOrderModel;
import com.hnty.driver.util.NetworkUtil;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by L on 2018/1/12.
 */

public class PastOrderModelImpl implements PastOrderModel {


    @Override
    public void getPastOrder( final OnPastOrderListener listener,String page) {

        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            listener.onPastOrderError("没有网络o");
            return;
        }

        MyApplication.getAPI().getPastOrder("getVoiceOrder",page)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<PastOrderListBean>(){

                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull PastOrderListBean bean) {

                        try {
                            if(bean.code==1){
                                listener.onPastOrderSuccess(bean);
                            }else {
                                listener.onPastOrderError(bean.msg);
                            }
                        }catch (Exception e){
                            listener.onPastOrderError("数据错误");
                        }
                    }

                    @Override
                    public void onError(Throwable throwable) {
                        listener.onPastOrderError("数据错误");
                    }
                    @Override
                    public void onComplete() {
                    }
                });


    }



}
