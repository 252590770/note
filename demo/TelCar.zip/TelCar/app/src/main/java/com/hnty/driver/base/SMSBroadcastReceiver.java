package com.hnty.driver.base;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsMessage;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SMSBroadcastReceiver extends BroadcastReceiver {

    private static OnReceivedMessageListener mOnReceivedMessageListener;
    public static final String SMS_RECEIVED_ACTION = "android.provider.Telephony.SMS_RECEIVED";

    public SMSBroadcastReceiver(){
        super();
    }

    @Override
    public void onReceive(Context context, Intent intent){
        if (intent.getAction().equals(SMS_RECEIVED_ACTION)) {
            Object[] pdus = (Object[]) intent.getExtras().get("pdus");
            for(Object pdu:pdus) {
                SmsMessage smsMessage = SmsMessage.createFromPdu((byte [])pdu);
                String sender = smsMessage.getDisplayOriginatingAddress();
                String content = smsMessage.getDisplayMessageBody();
                //过滤不需要读取的短信的发送号码
                if ("10690529155575".equals(sender)) {
                    mOnReceivedMessageListener.onReceived(content);
                    abortBroadcast();
                }
            }
        }
    }

    public interface OnReceivedMessageListener{
        void onReceived(String message);
    }

    public void setOnReceivedMessageListener(OnReceivedMessageListener onReceivedMessageListener){
        this.mOnReceivedMessageListener = onReceivedMessageListener;
    }

    /**
     * 从字符串中截取连续6位数字组合 ([0-9]{" + 6 + "})截取六位数字 进行前后断言不能出现数字 用于从短信中获取动态密码
     * @param str 短信内容
     * @return 截取得到的6位动态密码
     */
    public String getDynamicPassword(String str){
        // 6是验证码的位数,一般为六位
        Pattern continuousNumberPattern = Pattern.compile("(?<![0-9])([0-9]{" + 6 + "})(?![0-9])");
        Matcher m = continuousNumberPattern.matcher(str);
        String dynamicPassword = "";
        while (m.find()) {
            dynamicPassword = m.group();
        }
        return dynamicPassword;
    }
}