package com.hnty.driver.model.modelinter;


import com.hnty.driver.entity.DriverCancelParam;
import com.hnty.driver.entity.DriverGetUserParam;
import com.hnty.driver.inter.OnDriverCancelListener;
import com.hnty.driver.inter.OnDriverGetUserListener;


public interface DriverGetUserModel {

    void getUser(DriverGetUserParam param, OnDriverGetUserListener listener);

}
