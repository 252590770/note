package com.hnty.driver.model.modelimpl;

import android.util.Log;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.CodeParam;
import com.hnty.driver.entity.DriverOutBean;
import com.hnty.driver.entity.DriverOutParam;
import com.hnty.driver.inter.OnCodeListener;
import com.hnty.driver.inter.OnDriverOutListener;
import com.hnty.driver.model.modelinter.CodeModel;
import com.hnty.driver.model.modelinter.DriverOutModel;
import com.hnty.driver.util.NetworkUtil;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by L on 2018/1/12.
 */

public class DriverOutModelImpl implements DriverOutModel {


    @Override
    public void driverOut(DriverOutParam param, final OnDriverOutListener listener) {


        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            listener.onDriverOutError("没有网络o");
            return;
        }

        MyApplication.getAPI().driverOut(param.method,param.driver_id)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<DriverOutBean>(){

                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull DriverOutBean bean) {

                        try {

                            if(bean.code==1){
                                listener.onDriverOutSuccess(bean);
                            }else if(bean.code==0){
                                listener.onDriverOutError(bean.msg);
                            }
                        }catch (Exception e){
                            Log.e("728","Exception == "+e.toString() );
                            listener.onDriverOutError("数据错误1" );
                        }


                    }
                    @Override
                    public void onError(@NonNull Throwable e) {
                        Log.e("728","Exception == "+e.toString() );
                        listener.onDriverOutError("数据错误");
                    }

                    @Override
                    public void onComplete() {
                    }
                });


    }



}
