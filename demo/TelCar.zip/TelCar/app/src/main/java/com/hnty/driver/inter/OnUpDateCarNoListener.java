package com.hnty.driver.inter;


/**
 * Created by L on 2018/1/12.
 */

public interface OnUpDateCarNoListener {

    void onUpDateCarNoSuccess(String newsEntity);
    void onUpDateCarNoError(String errStr);

}
