package com.hnty.driver.model.modelimpl;

import android.util.Log;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.CodeParam;
import com.hnty.driver.entity.OrderStateBean;
import com.hnty.driver.entity.OrderStatusParam;
import com.hnty.driver.entity.PushOrderBean;
import com.hnty.driver.inter.OnCodeListener;
import com.hnty.driver.inter.OnOrderStateListener;
import com.hnty.driver.model.modelinter.CodeModel;
import com.hnty.driver.model.modelinter.OrderStateModel;
import com.hnty.driver.util.NetworkUtil;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;



public class OrderStateModelImpl implements OrderStateModel {


    @Override
    public void getOrderState(OrderStatusParam param, final OnOrderStateListener listener) {

        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            listener.onOrderStateError(new Exception("没有网络o"));
            return;
        }

        MyApplication.getAPI().getOrderState(param.method,param.driver_id)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<OrderStateBean>(){

                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull OrderStateBean bean) {

                        try {
                                listener.onOrderStateSuccess(bean);
                        }catch (Exception e){
                            listener.onOrderStateError(new Exception("数据错误"));

                            Log.e("ccc",e.toString());
                        }
                    }
                    @Override
                    public void onError(@NonNull Throwable e) {
                        listener.onOrderStateError(new Exception("数据错误"));
                    }

                    @Override
                    public void onComplete() {
                        listener.onComplete();
                    }
                });


    }




}
