package com.hnty.driver.push;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;


public class ClientSocket {
	public Socket socket = null;
	DataOutputStream out = null;
	private InetSocketAddress isa = null;
	DataInputStream getMessageStream = null;

	public ClientSocket(int port) {
	}

	/**
	 * 创建连接
	 *
	 * @return
	 */
	public boolean createConnection() {
		try {
			socket = new Socket();
//			isa = new InetSocketAddress(ConnectURL.TCP_IP, ConnectURL.TCP_PORT);
//			isa = new InetSocketAddress("192.168.0.102", 9631);
			isa = new InetSocketAddress(ConnectURL.TCP_IP, ConnectURL.TCP_PORT);
			socket.connect(isa, 20000);
			//设置 socket 读取数据流的超时时间
			socket.setSoTimeout(20000);
			// 发送数据包，默认为 false，即客户端发送数据采用 Nagle 算法；
			// 但是对于实时交互性高的程序，建议其改为 true，即关闭 Nagle
			// 算法，客户端每发送一次数据，无论数据包大小都会将这些数据发送出去
			socket.setTcpNoDelay(true);
			// 设置客户端 socket 关闭时，close() 方法起作用时延迟 30 秒关闭，如果 30 秒内尽量将未发送的数据包发送出去
			// socket.setSoLinger(true, 30);
			// 设置输出流的发送缓冲区大小，默认是4KB，即4096字节
			socket.setSendBufferSize(102400);
			// 设置输入流的接收缓冲区大小，默认是4KB，即4096字节
			socket.setReceiveBufferSize(102400);
			// 作用：每隔一段时间检查服务器是否处于活动状态，如果服务器端长时间没响应，自动关闭客户端socket
			// 防止服务器端无效时，客户端长时间处于连接状态
			socket.setKeepAlive(true);
			// Log.d("Main", socket+"");
		} catch (UnknownHostException e) {
			e.printStackTrace();
			if (socket != null) {
				try {
					socket.close();

				} catch (IOException e1) {
					e1.printStackTrace();
				}
				return false;
			}
		} catch (IOException e) {
			e.printStackTrace();
			if (socket != null) {
				try {
					socket.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				return false;
			}
		} finally {
			if (socket == null) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 登录
	 *
	 * @param paramWTPacket
	 * @param sendcommand
	 * @return
	 */
	public boolean sendLogin(String paramWTPacket, int sendcommand) {

		int msglen = paramWTPacket.getBytes().length;
		byte[] sendbytes = new byte[msglen + 3];
		sendbytes[0] = 0x5a;
		sendbytes[1] = 0x06/*SocketUtil.intToByte(msglen)[3]*/;
		sendbytes[2] = SocketUtil.toByteArray(sendcommand, 1)[0];
		System.arraycopy(paramWTPacket.getBytes(), 0, sendbytes, 3, msglen);

		if (socket == null) {
			return false;
		}

		if (socket.isConnected()) {
			try {
				out = new DataOutputStream(socket.getOutputStream());
				out.write(sendbytes);
				out.flush();

				return true;
			} catch (IOException e) {
				e.printStackTrace();
				if (out != null) {
					try {
						out.close();
						socket = null;
					} catch (IOException e1) {
						e1.printStackTrace();
					}

				}
				return false;
			}
		} else {
			return false;
		}

	}

	public void sendBytebak(byte[] sendMessage, int datalen) {
		try {
			out = new DataOutputStream(socket.getOutputStream());
			byte[] sendbytes = new byte[datalen + 4];
			sendbytes[0] = 0x52;
			sendbytes[1] = SocketUtil.toByteArray(datalen, 2)[0];
			sendbytes[2] = SocketUtil.toByteArray(datalen, 2)[1];
			sendbytes[3] = 0x00;
			System.arraycopy(sendMessage, 0, sendbytes, 4, datalen);

			out.write(sendbytes);
			out.flush();

		} catch (IOException e) {
			e.printStackTrace();
			if (out != null) {
				try {
					out.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		}
	}

	public DataInputStream getMessageStream() {
		if (socket == null) {
			return null;
		}

		if (socket.isClosed()) {
			return null;
		}
		if (!socket.isConnected()) {
			return null;
		}
		try {
			getMessageStream = new DataInputStream(new BufferedInputStream(
					socket.getInputStream()));
			// return getMessageStream;
		} catch (IOException e) {
			e.printStackTrace();
			if (getMessageStream != null) {
				try {
					getMessageStream.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		}
		return getMessageStream;
	}

	/**
	 * 断开连接
	 */
	public void shutDownConnection() {
		try {
			if (out != null) {
				out.close();
			}
			if (getMessageStream != null) {
				getMessageStream.close();
			}
			if (socket != null) {
				socket.close();

			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
