package com.hnty.driver.view;//package com.hnty.driver.view;
//
//
//import android.app.AlertDialog;
//import android.app.Dialog;
//import android.app.ProgressDialog;
//import android.content.Context;
//import android.content.DialogInterface;
//import android.content.Intent;
//import android.graphics.drawable.ColorDrawable;
//import android.net.Uri;
//import android.os.Handler;
//import android.util.Log;
//import android.view.LayoutInflater;
//import android.view.MotionEvent;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.AdapterView;
//import android.widget.LinearLayout;
//import android.widget.ListView;
//import android.widget.PopupWindow;
//import android.widget.TextView;
//
//import com.hnty.driver.MainActivity;
//import com.hnty.driver.R;
//import com.hnty.driver.activity.MainTopDialog;
//import com.hnty.driver.application.MyApplication;
//import com.hnty.driver.entity.ComplaintParam;
//import com.hnty.driver.entity.FinishOrderParam;
//import com.hnty.driver.entity.OrderStatusParam;
//import com.hnty.driver.entity.PushOrderBean;
//import com.hnty.driver.entity.UserInfoBean;
//import com.hnty.driver.entity.VoiceOrderListBean;
//import com.hnty.driver.finals.Constant;
//import com.hnty.driver.inter.ComplaintOrderListener;
//import com.hnty.driver.inter.OnDriverVoiceListener;
//import com.hnty.driver.inter.OnFinishOrderListener;
//import com.hnty.driver.model.modelimpl.ComplaintOrderModelImpl;
//import com.hnty.driver.model.modelimpl.FinishOrderModelImpl;
//import com.hnty.driver.model.modelimpl.OrderStatusModelImpl;
//import com.hnty.driver.util.MsgBox;
//import com.hnty.driver.util.MyUtil;
//import com.hnty.driver.util.SPTool;
//import com.hnty.driver.util.ToastUtil;
//
//import java.util.List;
//
//public class PopShowView extends PopupWindow implements View.OnClickListener  ,OnDriverVoiceListener,OnFinishOrderListener
//        ,ComplaintOrderListener {
//    private LayoutInflater layoutInflater;
//    private View popView;
//    private List<String> infoList;
//    private Context context;
//    private LinearLayout pop_layout;
//    private Handler mHandler;
//    public PopShowView(Context context) {
//        this.layoutInflater = (LayoutInflater) context
//                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//        this.context = context;
//        init();
//    }
//
//    public PopShowView(Context context,OnDismissListener onDismissListener) {
//        this.layoutInflater = (LayoutInflater) context
//                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//        this.context = context;
//        init();
//    }
//
//    public PopShowView(Context context,Handler mHandler) {
//        this.layoutInflater = (LayoutInflater) context
//                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//        this.context = context;
//        this.mHandler = mHandler;
//        init();
//    }
//
//
//
//    private void init() {
//        popView = layoutInflater.inflate(R.layout.main_top_dialog, null);
//        pop_layout = (LinearLayout) popView.findViewById(R.id.ll);
//
//        if (infoList != null) {
//        }
//
//
//        //把View添加到PopWindow中
//        this.setContentView(popView);
//        //设置SelectPicPopupWindow弹出窗体的宽
//        this.setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
//        //设置SelectPicPopupWindow弹出窗体的高
//        this.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
//        //设置SelectPicPopupWindow弹出窗体可点击
//        this.setFocusable(true);
//        //设置SelectPicPopupWindow弹出窗体动画效果
//        this.setAnimationStyle(R.style.MyPopWindowStyle);
//
////        this.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));//实例化一个ColorDrawable颜色为透明
//
//        //实例化一个ColorDrawable颜色为半透明
//        ColorDrawable dw = new ColorDrawable(0x6f000000);
//        //设置SelectPicPopupWindow弹出窗体的背景
//        this.setBackgroundDrawable(dw);
//        popView.setOnTouchListener(new View.OnTouchListener() {//设置背景区域外为点击消失popwindow
//            public boolean onTouch(View v, MotionEvent event) {
//
//                int height = popView.findViewById(R.id.ll).getTop();
//                int y = (int) event.getY();
//                if (event.getAction() == MotionEvent.ACTION_UP) {
//                    if (y < height) {
//                        dismiss();
//                    }
//                }
//                return true;
//            }
//        });
//
//
//        initView(popView);
//
//
//    }
//    VoiceOrderListBean.BodyBean bean;
//    public void setContent( VoiceOrderListBean.BodyBean bean ){
//
//        this.bean = bean;
//
//        tvTel.setText(MyUtil.TelNoToStarts(bean.voice_tell.trim()));
//        tvTime.setText(bean.oper_date.trim());
//        tvStart.setText(bean.voice_file.trim());
//        tvEnd.setText(bean.voice_end.trim());
//    }
//
//
//    private LinearLayout llBottom;
//    private LinearLayout btnListen;
//    private LinearLayout btnGet;
//    private LinearLayout btnComplain;
//    private LinearLayout btnFinish;
//    private TextView tvTel;
//    private TextView tvTime;
//    private TextView tvStart;
//    private TextView tvEnd;
//    private TextView tvMainBottomMid;
//    private LinearLayout ll;
//    private void initView(View popView  ) {
//
//        llBottom = popView.findViewById(R.id.llBottom);
//        tvTel = popView.findViewById(R.id.tvTel);
//        tvTime = popView.findViewById(R.id.tvTime);
//        tvStart = popView.findViewById(R.id.tvStart);
//        tvEnd = popView.findViewById(R.id.tvEnd);
//        btnGet = popView.findViewById(R.id.btnGet);
//        btnComplain = popView.findViewById(R.id.btnComplain);
//        btnFinish = popView.findViewById(R.id.btnFinish);
//        btnListen = popView.findViewById(R.id.btnListen);
//        tvMainBottomMid = popView.findViewById(R.id.tvMainBottomMid);
//        ll = popView.findViewById(R.id.ll);
//
//        tvTel.setOnClickListener(this);
//        btnFinish.setOnClickListener(this);
//        btnComplain.setOnClickListener(this);
//        llBottom.setOnClickListener(this);
//        btnGet.setOnClickListener(this);
//        btnListen.setOnClickListener(this);
//    }
//
//
//
//    @Override
//    public void onClick(View v) {
//
//        switch (v.getId()){
//
//            case R.id.llBottom:
//                break;
//
//            case R.id.tvTel:
//
//                if(bean.voice_state.equals("1")){
//
//                    if(bean.driver_id.equals(SPTool.getUserInfo(context).body.driver_id)){
//                        showTellDialog(2, "提示", "打电话给乘客?");
//                    }else {
//                        ToastUtil.show(context,"此订单已被接!");
//                    }
//
//                }else if (bean.voice_state.equals("0")){
//                    ToastUtil.show(context,"接单后可打电话!");
//                }else if (bean.voice_state.equals("2")|bean.voice_state.equals("3")|bean.voice_state.equals("4")){
//                    ToastUtil.show(context,"此订单已完成!");
//                }else if (bean.voice_state.equals("5")){
//                    ToastUtil.show(context,"此订单已取消!");
//                }
//
//                break;
//
//            case R.id.btnListen:
//                PushOrderBean pushOrderBean;
//                pushOrderBean = new PushOrderBean();
//                pushOrderBean.body = new PushOrderBean.BodyBean();
//                pushOrderBean.body.voice_name = bean.voice_name;
//                pushOrderBean.body.end_name = bean.end_name;
//
////                if(pushOrderBean.body.voice_name.trim().equals("")|pushOrderBean.body.end_name.trim().equals("")){
////                    break;
////                }
//
//                MyApplication.playMedia(pushOrderBean);
//                break;
//
//            case R.id.btnGet:
//                jiedan("1");
//                break;
//
//            case R.id.btnFinish:
//                finishorder("2");
//                break;
//
//            case R.id.btnComplain:
//                showSinpleChioceDialog();
//                break;
//        }
//
//    }
//
//
//
//    ////////////////////////接单////////////////////////
//    OrderStatusModelImpl orderStatusModel = null;
//    void jiedan(String statue) {
//        if (orderStatusModel == null) {
//            orderStatusModel = new OrderStatusModelImpl();
//        }
//
//
//        if(SPTool.getUserInfo(context)==null){
//            ToastUtil.show(context,"请登录!");
//            return;
//        }
//        UserInfoBean userInfoBean = SPTool.getUserInfo(context);
//        showProgressDialog("请稍等...");
//        OrderStatusParam param = new OrderStatusParam("getDrivervocie", statue,
//                userInfoBean.body.driver_id,
//                bean.voice_order,
//                SPTool.getString(context, "Driver_Lat"),
//                SPTool.getString(context, "Driver_Lon")
//        );
//        orderStatusModel.sendOrderStatus(param, PopShowView.this);
//    }
//    @Override
//    public void onSuccess(String str) {
//        Log.i("cccccc", "接单 Success==" + str);
////		showGPSDialog(2, "提示", "接单成功，导航至乘客位置");
//        ToastUtil.show(context,"接单成功");
//        dissmissProgressDialog();
//        bean.voice_state = "1";
//        bean.driver_id = SPTool.getUserInfo(context).body.driver_id;
//    }
//    @Override
//    public void onError(String err) {
//        Log.i("cccccc", "接单 Error==" + err);
//
//        ToastUtil.show(context, err);
//        dissmissProgressDialog();
//    }
//    ////////////////////////接单////////////////////////
//
//
//
//
//
//    ////////////////////////完成订单////////////////////////
//    FinishOrderModelImpl finishOrderModel = null;
//    void finishorder(String statue) {
//        if (finishOrderModel == null) {
//            finishOrderModel = new FinishOrderModelImpl();
//        }
//
//
//        UserInfoBean userInfoBean = SPTool.getUserInfo(context);
//
//        if (userInfoBean == null) {
//            ToastUtil.show(context, "请登录");
//            return;
//        }
//
//        if (bean == null) {
//            ToastUtil.show(context, "未接订单");
//            return;
//        }
//
//
//        showProgressDialog("请稍等...");
//        FinishOrderParam param = new FinishOrderParam("getDriverendVoicer", statue,
//                userInfoBean.body.driver_id,
//                bean.voice_order,
//                SPTool.getString(context, "Driver_Lat"),
//                SPTool.getString(context, "Driver_Lon")
//        );
//
//        finishOrderModel.sendFinishOrder(param, this);
//
//    }
//
//    @Override
//    public void OnFinishOrderSuccess(String str) {
//
//        Log.i("cccccc", "完成订单 OnFinishOrderSuccess==" + str);
//        SPTool.putString(context, Constant.MyPushOrderBean, "");
//        SPTool.putString(context, Constant.PushOrderBean, "");
//        ToastUtil.show( context, str);
//        dissmissProgressDialog();
//        dismiss();
//
//        mHandler.sendEmptyMessage(MsgBox.MSG_ON_FINISH_ORDER);
//
//    }
//
//    @Override
//    public void OnFinishOrderError(String err) {
//        Log.i("cccccc", "完成订单 Error==" + err);
//        ToastUtil.show( context, err.toString());
//        dissmissProgressDialog();
//
//    }
//    ////////////////////////完成订单////////////////////////
//
//
//
//    //////////////////进度框进度框进度框///////////////////
//    //显示进度框
//    private ProgressDialog progDialog = null;//
//    private void showProgressDialog(String str) {
//        if (progDialog == null)
//            progDialog = new ProgressDialog(context);
//        progDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
//        progDialog.setIndeterminate(false);
//        progDialog.setCancelable(true);
//        progDialog.setMessage(str);
//        progDialog.show();
//    }
//    //隐藏进度框
//    private void dissmissProgressDialog() {
//        if (progDialog != null) {
//            progDialog.dismiss();
//        }
//    }
//    //////////////////进度框进度框进度框///////////////////
//
//
//
//
//
//    //////////////////司机投诉///////////////////
//    //投诉显示单选对话框
//    int mWhich;
//    public void showSinpleChioceDialog() {
//        AlertDialog.Builder builder = new AlertDialog.Builder(context);
//        builder.setTitle("选择投诉:");
////		builder.setIcon(R.drawable.driver_icon);
//        final String[] items = new String[]{"远距离接单", "黑车",};
//        builder.setSingleChoiceItems(items, 0, new DialogInterface.OnClickListener() {/*设置单选条件的点击事件*/
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                mWhich = which;
//            }
//        });
//        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                touSu(mWhich);
//            }
//        });
//        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//            }
//        });
//        builder.setCancelable(false);
//        builder.show();
//    }
//
//    private ComplaintOrderModelImpl complaintOrderModel;//comlain
//
//    void touSu(int which) {
//        if (complaintOrderModel == null) {
//            complaintOrderModel = new ComplaintOrderModelImpl();
//        }
//        try {
//
//
//
//            ComplaintParam param;
//            param = new ComplaintParam("getDrivercomplaint", which + "",
//                    SPTool.getUserInfo(context).body.driver_id,
//                    bean.voice_order,
//                    Constant.Driver_Lon + "", Constant.Driver_Lat + "");
//            complaintOrderModel.sendComplaint(param, PopShowView.this);
//        } catch (Exception e) {
//        }
//    }
//
//    @Override
//    public void onComplaintSuccess(String str) {
//        ToastUtil.show(context,str);
//        dismiss();
//    }
//
//    @Override
//    public void onComplaintError(String errStr) {
//        ToastUtil.show(context,errStr);
//        dismiss();
//    }
//    //////////////////司机投诉///////////////////
//
//
//
//    //////////////////打电话///////////////////
//    //提示对话框
//    public Dialog dialog;
//    public TextView btn_one;
//    public TextView btn_right;
//    public interface ClickSureListener {
//        public void click();
//    }
//    private MainActivity.ClickSureListener clickSureListener;
//    public void showTellDialog(int type, String titleStr, String contentStr) {
//        if (dialog == null) {
//            dialog = new AlertDialog.Builder(context).create();
//        }
//        LayoutInflater inflater = LayoutInflater.from(context);
//        View view = (View) inflater.inflate(R.layout.dialog_base, null);
//        TextView title = (TextView) view.findViewById(R.id.title);
//        TextView content = (TextView) view.findViewById(R.id.content);
//        btn_one = (TextView) view.findViewById(R.id.btn_one);
//        LinearLayout layout = (LinearLayout) view
//                .findViewById(R.id.bottom_layout);
//        btn_right = (TextView) view.findViewById(R.id.btn_right);
//        if (type == 1) {
//            btn_one.setVisibility(View.VISIBLE);
//            layout.setVisibility(View.GONE);
//        } else if (type == 2) {
//            btn_one.setVisibility(View.GONE);
//            layout.setVisibility(View.VISIBLE);
//        }
//        btn_one.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                // TODO Auto-generated method stub
//                // sure();
//                clickSureListener.click();
//            }
//        });
//
//        btn_right.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                // TODO Auto-generated method stub
//                // sure();
//                clickSureListener.click();
//            }
//        });
//        title.setText(titleStr);
//        content.setText(contentStr);
//
//        view.findViewById(R.id.btn_left).setOnClickListener(
//                new View.OnClickListener() {
//
//                    @Override
//                    public void onClick(View v) {
//                        dialog.dismiss();
//                    }
//                });
//
//        view.findViewById(R.id.btn_right).setOnClickListener(
//                new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        getTel();
//                        dialog.dismiss();
//                    }
//                });
//
//        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
//        dialog.show();
//        dialog.getWindow().setContentView(view);
//    }
//    //提示对话框
//
//    void getTel() {
//        try {
//            String tel = bean.voice_tell;
//            Log.i("bbbbbb", "tel==" + tel);
//            Intent call = new Intent(Intent.ACTION_DIAL);
//            Uri data = Uri.parse("tel:" + tel);
//            call.setData(data);
//            context.startActivity(call);
//        } catch (Exception e) {
//        }
//    }
//    //////////////////打电话///////////////////
//
//
//}