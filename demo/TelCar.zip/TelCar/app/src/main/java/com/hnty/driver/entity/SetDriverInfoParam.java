package com.hnty.driver.entity;

/**
 * Created by L on 2018/1/11.
 */

public class SetDriverInfoParam {
    public String method;
    public String driver_name;
    public String driver_tell;
    public String driver_pass;

    public SetDriverInfoParam() {
    }

    public SetDriverInfoParam(String method, String driver_name, String driver_tell, String driver_pass) {
        this.method = method;
        this.driver_name = driver_name;
        this.driver_tell = driver_tell;
        this.driver_pass = driver_pass;
    }
}
