package com.hnty.driver.model.modelinter;

import com.hnty.driver.entity.UpdateDriverVerParam;
import com.hnty.driver.inter.OnUpdateDriverVerListener;

/**
 * Created by Think-pc on 2018/5/27.
 */

public interface UpadateDriverVerModel {

    void onUpdateDriverver(UpdateDriverVerParam param, OnUpdateDriverVerListener listener);
}
