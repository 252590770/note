package com.hnty.driver.entity;


public class UpDateUserImg {

    public int code;
    public MsgBean msg;

    public static class MsgBean {

        public String driver_img;

    }
}
