package com.hnty.driver.model.modelinter;


import com.hnty.driver.entity.CodeParam;
import com.hnty.driver.inter.OnCodeListener;
import com.hnty.driver.inter.OnVoiceOrderListListener;

/**
 * Created by L on 2018/1/12.
 */

public interface VoiceOrderListModel {

    void getOrderList(OnVoiceOrderListListener listener, String page);

}
