package com.hnty.driver.inter;


import com.hnty.driver.entity.BaseBean;

/**
 * Created by L on 2018/1/12.
 */

public interface OnUpdateIsmiListener {

    void onUpdateSuccess(BaseBean bean);
    void onUpdateError(String errStr);

}
