package com.hnty.driver.activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.hnty.driver.R;
import com.hnty.driver.application.MyApplication;
import com.hnty.driver.base.BaseActivity;
import com.hnty.driver.entity.OrderStatusParam;
import com.hnty.driver.entity.PastOrderListBean;
import com.hnty.driver.entity.PushOrderBean;
import com.hnty.driver.entity.UserInfoBean;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.inter.OnDriverVoiceListener;
import com.hnty.driver.inter.OnPastOrderListener;
import com.hnty.driver.model.modelimpl.OrderStatusModelImpl;
import com.hnty.driver.model.modelimpl.PastOrderModelImpl;
import com.hnty.driver.util.SPTool;
import com.hnty.driver.util.ToastUtil;

/**
 * Created by Administrator on 2017/4/27.
 */

public class PastOrderActivity extends BaseActivity implements OnPastOrderListener,OnDriverVoiceListener {

    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_past_order);
        setTitle("未接订单");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//来保持屏幕高亮
        showContentView();
        listView = (ListView) findViewById(R.id.listView);
        getPastOrderList();
        listViewSetOnClick();
    }

    //获取未接订单列表
    PastOrderModelImpl pastOrderModel;
    int page = 1;
    void getPastOrderList(){
        if(pastOrderModel == null ){
            pastOrderModel = new PastOrderModelImpl();
        }
        showProgressDialog("请稍等...");
        pastOrderModel.getPastOrder(this,page+"");
    }

    PastOrderListBean outPastOrder;
    @Override
    public void onPastOrderSuccess(final PastOrderListBean PastOrder) {
        dissmissProgressDialog();
        outPastOrder = PastOrder;
        listView.setAdapter(new BaseAdapter() {
            @Override
            public int getCount() {
                return PastOrder.body.size();
            }

            @Override
            public Object getItem(int position) {
                return PastOrder.body.get(position);
            }

            @Override
            public long getItemId(int position) {
                return position;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                ViewHolder holder = new ViewHolder();
                if(convertView == null ){
                    convertView = LayoutInflater.from(MyApplication.getContext()).inflate(R.layout.past_order_item,null);
                    holder.tvTel = (TextView) convertView.findViewById(R.id.tvTel);
                    holder.tvTime = (TextView) convertView.findViewById(R.id.tvTime);
                    holder.tvStart = (TextView) convertView.findViewById(R.id.tvStart);
                    holder.tvEnd = (TextView) convertView.findViewById(R.id.tvEnd);
                    convertView.setTag(holder);
                }else {
                    holder = (ViewHolder) convertView.getTag();
                }

                holder.tvTel.setText("电话："+PastOrder.body.get(position).voice_tell);
                holder.tvTime.setText("时间："+"");
                holder.tvTime.setVisibility(View.GONE);
                holder.tvStart.setText("出发地："+PastOrder.body.get(position).voice_file);
                holder.tvEnd.setText("目的地："+PastOrder.body.get(position).voice_end);
                return convertView;
            }

            class ViewHolder {
                TextView tvTel,tvTime,tvStart,tvEnd;
            }

        });

    }
    @Override
    public void onPastOrderError(String errStr) {
        dissmissProgressDialog();
        ToastUtil.show(this,errStr);

    }
    //获取未接订单列表


    //显示进度框
    private ProgressDialog progDialog = null;//
    private void showProgressDialog(String str) {
        if (progDialog == null)
            progDialog = new ProgressDialog(this);
        progDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progDialog.setIndeterminate(false);
        progDialog.setCancelable(true);
        progDialog.setMessage(str);
        progDialog.show();
    }
    //隐藏进度框
    private void dissmissProgressDialog() {
        if (progDialog != null) {
            progDialog.dismiss();
        }
    }


    //travel/voiceOrderlist.action?method=getVoiceOrder
    public static void start(Context mContext) {
        Intent intent = new Intent(mContext, PastOrderActivity.class);
        mContext.startActivity(intent);
    }


    int myPosotion=-1;
    void listViewSetOnClick(){

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                myPosotion = position;
                showTipDialog(2,"提示","选择你想要的操作？",outPastOrder.body.get(position).voice_tell,outPastOrder.body.get(position).voice_order);
            }
        });

    }

    //提示对话框
    public Dialog dialog;
    public TextView btn_one;
    public TextView btn_right;

    public interface ClickSureListener {
        public void click();
    }
    private ClickSureListener clickSureListener;
    public void showTipDialog(int type, String titleStr, String contentStr, final String tel,final String voice_order) {
        if (dialog == null) {
            dialog = new AlertDialog.Builder(PastOrderActivity.this).create();
        }

        LayoutInflater inflater = LayoutInflater.from(PastOrderActivity.this);
        View view = (View) inflater.inflate(R.layout.dialog_base, null);
        TextView title = (TextView) view.findViewById(R.id.title);
        TextView content = (TextView) view.findViewById(R.id.content);
        btn_one = (TextView) view.findViewById(R.id.btn_one);
        LinearLayout layout = (LinearLayout) view
                .findViewById(R.id.bottom_layout);
        btn_right = (TextView) view.findViewById(R.id.btn_right);
        if (type == 1) {
            btn_one.setVisibility(View.VISIBLE);
            layout.setVisibility(View.GONE);
        } else if (type == 2) {
            btn_one.setVisibility(View.GONE);
            layout.setVisibility(View.VISIBLE);
        }
        btn_one.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });

        btn_right.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });
        title.setText(titleStr);
        content.setText(contentStr);
        ((TextView)view.findViewById(R.id.btn_left)).setText("接单");
        ((TextView)view.findViewById(R.id.btn_right)).setText("打电话");
        view.findViewById(R.id.btn_left).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        jiedan("1",voice_order);
                        dialog.dismiss();
                    }
                });

        view.findViewById(R.id.btn_right).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //"http://ps.tupppai.com/wefun_v1.0.1.apk"
                        getTel(tel);
                        dialog.dismiss();
                    }
                });

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.show();
        dialog.getWindow().setContentView(view);
    }

    //打电话
    void getTel(String tel) {
        try {
            Log.i("bbbbbb", "tel==" + tel);
            Intent call = new Intent(Intent.ACTION_DIAL);
            Uri data = Uri.parse("tel:" + tel);
            call.setData(data);
            startActivity(call);
        } catch (Exception e) {
        }
    }
    //打电话




    //接单
    OrderStatusModelImpl orderStatusModel = null;
    void jiedan(String statue,String voice_order) {
        if (orderStatusModel == null) {
            orderStatusModel = new OrderStatusModelImpl();
        }

        UserInfoBean userInfoBean = SPTool.getUserInfo(PastOrderActivity.this);

        if (userInfoBean == null) {
            ToastUtil.show(PastOrderActivity.this, "请登录");
            return;
        }

        showProgressDialog("请稍等...");
        OrderStatusParam param = new OrderStatusParam("getDrivervocie", statue,
                userInfoBean.body.driver_id,
                voice_order,
                SPTool.getString(PastOrderActivity.this, "Driver_Lat"),
                SPTool.getString(PastOrderActivity.this, "Driver_Lon")
        );


        Log.i("cccccc", "接单   Driver_Lat=" + Constant.Driver_Lat + "");
        Log.i("cccccc", "接单   Driver_Lon=" + Constant.Driver_Lon + "");

        Log.i("cccccc", "接单 getString  Driver_Lon=" + SPTool.getString(PastOrderActivity.this, "Driver_Lat") + "");
        Log.i("cccccc", "接单 getString  Driver_Lon=" + SPTool.getString(PastOrderActivity.this, "Driver_Lon") + "");

        orderStatusModel.sendOrderStatus(param, PastOrderActivity.this);

    }
    @Override
    public void onSuccess(String str) {
        Log.i("cccccc","接单 Success=="+str);

        ToastUtil.show(PastOrderActivity.this, "接单成功！");
        PushOrderBean  bean= new PushOrderBean();
        bean.body = new PushOrderBean.BodyBean();
        bean.code=1;
        bean.msg="历史订单";
        bean.body.voice_order = outPastOrder.body.get(myPosotion).voice_order;
        bean.body.voice_name = outPastOrder.body.get(myPosotion).voice_name;
        bean.body.end_name = outPastOrder.body.get(myPosotion).end_name;
        bean.body.voice_file = outPastOrder.body.get(myPosotion).voice_file;
        bean.body.voice_end = outPastOrder.body.get(myPosotion).voice_end;
        bean.body.voice_tell = outPastOrder.body.get(myPosotion).voice_tell;
        SPTool.putString(MyApplication.getContext(),Constant.MyPushOrderBean,bean.toString());

        SPTool.putBoolean(PastOrderActivity.this,Constant.OrderState,true);
        Log.i("cccccc","历史订单=="+bean.toString());
        showGPSDialog(2,"提示","接单成功，导航至乘客位置");
        dissmissProgressDialog();

    }
    @Override
    public void onError(String errStr) {
        Log.i("cccccc","接单 Error=="+errStr);

        ToastUtil.show(PastOrderActivity.this,errStr);
        dissmissProgressDialog();
    }
    //接单






    public void showGPSDialog(int type, String titleStr, String contentStr) {
        if (dialog == null) {
            dialog = new AlertDialog.Builder(PastOrderActivity.this).create();
        }

        LayoutInflater inflater = LayoutInflater.from(PastOrderActivity.this);
        View view = (View) inflater.inflate(R.layout.dialog_base, null);
        TextView title = (TextView) view.findViewById(R.id.title);
        TextView content = (TextView) view.findViewById(R.id.content);
        btn_one = (TextView) view.findViewById(R.id.btn_one);
        LinearLayout layout = (LinearLayout) view
                .findViewById(R.id.bottom_layout);
        btn_right = (TextView) view.findViewById(R.id.btn_right);
        if (type == 1) {
            btn_one.setVisibility(View.VISIBLE);
            layout.setVisibility(View.GONE);
        } else if (type == 2) {
            btn_one.setVisibility(View.GONE);
            layout.setVisibility(View.VISIBLE);
        }
        btn_one.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });

        btn_right.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });
        title.setText(titleStr);
        content.setText(contentStr);

        view.findViewById(R.id.btn_left).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                        finish();
                    }
                });

        view.findViewById(R.id.btn_right).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //"开始导航
                    }
                });

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.show();
        dialog.getWindow().setContentView(view);
    }
    
}
