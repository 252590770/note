package com.hnty.driver.inter;


import com.hnty.driver.entity.VoiceOrderListBean;

/**
 * Created by L on 2018/1/12.
 */

public interface OnVoiceOrderListListener {

    void onVoiceOrderListSuccess(VoiceOrderListBean voiceOrderList);
    void onVoiceOrderListError(String errStr);
    void onComplete();

}
