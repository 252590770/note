package com.hnty.driver.inter;


/**
 * Created by L on 2018/1/12.
 */

public interface OnDriverVoiceListener {

    void onSuccess(String str);
    void onError(String err);

}
