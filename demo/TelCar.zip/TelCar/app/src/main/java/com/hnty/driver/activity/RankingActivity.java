package com.hnty.driver.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.hnty.driver.R;
import com.hnty.driver.base.BaseActivity;
import com.hnty.driver.databinding.ActivityRankingBinding;
import com.hnty.driver.entity.DriverRankBean;
import com.hnty.driver.inter.OnDriverRankListener;
import com.hnty.driver.model.modelimpl.DriverRankModelImpl;
import com.hnty.driver.util.SPTool;
import com.hnty.driver.util.ToastUtil;

import java.util.ArrayList;

/**
 * Created by Administrator on 2017/4/26.
 */

public class RankingActivity extends BaseActivity<ActivityRankingBinding>implements OnDriverRankListener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ranking);
        setTitle("司机排名");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//来保持屏幕高亮
        bindingView.tvRanking.setText("我的排名："+SPTool.getUserInfo(this).body.driver_rank);

        getDriverRank();
    }


    DriverRankModelImpl rankModel;
    void getDriverRank (){
        if(rankModel == null ){
            rankModel = new DriverRankModelImpl();
        }
        rankModel.getDriverRank(this);
    }

    @Override
    public void onDriverRankSuccess(final ArrayList<DriverRankBean> list) {
        bindingView.listView.setAdapter(new BaseAdapter() {
            @Override
            public int getCount() {
                return list.size();
            }

            @Override
            public Object getItem(int position) {
                return list.get(position);
            }

            @Override
            public long getItemId(int position) {
                return position;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                ViewHolder holder;
                if(convertView == null){
                    convertView = LayoutInflater.from(RankingActivity.this).inflate(R.layout.item_activity_ranking,null);
                    holder = new ViewHolder();
                    holder.name = (TextView) convertView.findViewById(R.id.tvName);
                    holder.ranking = (TextView) convertView.findViewById(R.id.tvRanking);
                    convertView.setTag(holder);
                }
                holder = (ViewHolder) convertView.getTag();
                holder.name.setText(list.get(position).driver_name);
                holder.ranking.setText("第"+(position+1)+"名");
                return convertView;
            }


            class  ViewHolder {

                TextView name;
                TextView ranking;

            }

        });
    }

    @Override
    public void onDriverRankError(String errStr) {
        ToastUtil.show(RankingActivity.this,"排名出错！");
    }






    public static void start(Context mContext) {
        Intent intent = new Intent(mContext, RankingActivity.class);
        mContext.startActivity(intent);
    }


}