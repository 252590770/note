package com.hnty.driver;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.AlarmManager;
import android.app.KeyguardManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.os.RemoteException;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.google.gson.Gson;
import com.hnty.driver.activity.MainTopDialog;
import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.ComplaintOrderBean;
import com.hnty.driver.entity.EventBean;
import com.hnty.driver.entity.PushCode;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.push.ClientSocket;
import com.hnty.driver.push.ConnectURL;
import com.hnty.driver.util.MsgBox;
import com.hnty.driver.util.SPTool;
import com.hnty.driver.util.ToastUtil;
import com.hnty.driver.util.VoiceUtils;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.DataInputStream;
import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;

import static java.lang.Thread.sleep;


public class LocalService extends Service  {
    Context context;
    public static LocalService myService;
    private boolean isReceiving;
    public static DoBackgroundTask taskProgress;
    public static DoBackgroundheartTask taskProgressheart;
    public boolean flagsocket;
    private static int mNewScreenSaver = 1 ;
    private PowerManager.WakeLock wakeLock = null;

    MyBinder binder;
    MyConn conn;
    private MediaPlayer mMediaPlayer;
    public static final int NOTICE_ID = 10009;
    protected static final int HASH_CODE = 1;
    //////////////////////////////6.20
    private long hearttime;

    private ClientSocket mSocket;
    private boolean bindflag=false;
    private Calendar mCalendar ;
    private AlarmManager alarmManager;
    private static final int PUSH_NOTIFICATION_ID = (0x001);
    private static final String PUSH_CHANNEL_ID = "PUSH_NOTIFY_ID";
    private static final String PUSH_CHANNEL_NAME = "PUSH_NOTIFY_NAME";
    private Notification notification;
    @Override
    public void onCreate() {
        super.onCreate();
        myService = this;
        context = this;
        binder = new MyBinder();
        conn = new MyConn();
        isReceiving=false;
        flagsocket=false;
        bindflag=false;
        mMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.service);
        mMediaPlayer.setLooping(true);
        if (checkNotificationPermission(this))
        {

        }else
        {
            goNLPermission(this);
        }




        if(SPTool.getInt(context,"DriverState")==1) {
            Log.i("ccccccccccc","aaa");

            stopForeground(true);



        }else {
            Log.i("ccccccccccc","bbb");
        }


        if (taskProgress != null && taskProgress.getStatus() == AsyncTask.Status.RUNNING)
        {
            taskProgress.cancel(true); // 如果Task还在运行，则先取消它，然后执行关闭activity代码
            taskProgress = null;
        }

        taskProgress = new DoBackgroundTask();




        new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        notification = new NotificationCompat.Builder(context)
                                .setContentTitle(getResources().getString(R.string.app_name))
                                .setTicker(getResources().getString(R.string.app_name))
                                .setContentText("运行中")
                                .setSmallIcon(R.drawable.logo1)
                                .build();
                        startForeground(HASH_CODE, notification);

                        if(SPTool.getInt(context,"DriverState")==0) {
                            stopForeground(true);
                        }
                    }
                }

        ).start();


        if(SPTool.getInt(context,"DriverState")==1) {
            if (MainActivity.mainActivity == null) {
                Intent intent2 = new Intent(context, MainActivity.class);
                intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                context.startActivity(intent2);
            }
        }


    }

    /**
     * 检查通知使用权
     */
    public static boolean checkNotificationPermission(Context context) {
        String pkg = context.getPackageName();
        String flat = Settings.Secure.getString(context.getContentResolver(), "enabled_notification_listeners");
        boolean enabled = flat != null && flat.contains(pkg);
        return enabled;
    }

    public static void goNLPermission(Context context) {
//        try {
//            Intent intent = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
//            context.startActivity(intent);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

        try {
            Intent intent = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);

        } catch(ActivityNotFoundException e) {
            try {
                Intent intent = new Intent();
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ComponentName cn = new ComponentName("com.android.settings","com.android.settings.Settings$NotificationAccessSettingsActivity");
                intent.setComponent(cn);
                intent.putExtra(":settings:show_fragment", "NotificationAccessSettings");
                context.startActivity(intent);

            } catch(Exception ex) {
                ex.printStackTrace();
            }

        }
    }



    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    public class MyListenerService extends NotificationListenerService {
        @Override
        public void onNotificationPosted(StatusBarNotification sbn) {

        }
        @Override
        public void onNotificationRemoved(StatusBarNotification sbn) {

        }
    }

    public static class InnerService extends Service{

        @Nullable
        @Override
        public IBinder onBind(Intent intent) {
            return null;
        }

        @Override
        public void onCreate() {
            super.onCreate();
            startForeground(HASH_CODE,new Notification());
            stopSelf();
        }
    }


    private void startPlayMusic(){
        if (isReceiving) {
            if (mMediaPlayer != null) {
                mMediaPlayer.start();
            }else
            {
                mMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.service);
                mMediaPlayer.setLooping(true);
                mMediaPlayer.start();
            }
        }
    }
    private void stopPlayMusic(){
        if(mMediaPlayer != null){
            mMediaPlayer.stop();
        }
    }
    @Override
    public IBinder onBind(Intent intent) {

        return binder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.i("unbind", "解绑成功");
        if (bindflag)
        {
            if (Build.VERSION.SDK_INT >=20)
            {
                if (conn!=null)
                {
                    unbindService(conn);
                }

            }
            conn = null;
            binder = null;

        }

        return super.onUnbind(intent);
    }





    //Handler
    @SuppressLint("HandlerLeak")
    public Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {

            Log.i("423", "msg.what   " + msg.what);
            Log.i("423", "msg.toString   " + msg.toString());

            switch (msg.what) {
                case MsgBox.MSG_CONTENT: {//收到通知内容   播报第一条订单

                    if(MainTopDialog.mainTopDialog==null|| MainTopDialog.mainTopDialog.isDestroyed()){
                        //已关闭
                        if( !SPTool.getBoolean(context, Constant.AutoOpen)){


                            if(  SPTool.getBoolean(context,"VoiceOrderListActivityAlive")){
                                break;
                            }

                            if(  SPTool.getBoolean(context,"UnanswerOrderDialogAlive")){
                                break;
                            }

                            if(  SPTool.getBoolean(context,"QRCodeActivityAlive")){
                                break;
                            }



                            //解锁系统锁屏
                            // 获取电源管理器对象
                            PowerManager pm = (PowerManager) MyApplication.getContext()
                                    .getSystemService(Context.POWER_SERVICE);
                            boolean screenOn = pm.isScreenOn();
                            if (!screenOn) {
                                // 获取PowerManager.WakeLock对象,后面的参数|表示同时传入两个值,最后的是LogCat里用的Tag
                                PowerManager.WakeLock wl = pm.newWakeLock(
                                        PowerManager.ACQUIRE_CAUSES_WAKEUP |
                                                PowerManager.SCREEN_BRIGHT_WAKE_LOCK, "bright");
                                wl.acquire(10000); // 点亮屏幕
                                wl.release(); // 释放
                            }
                            // 屏幕解锁
                            KeyguardManager keyguardManager = (KeyguardManager) MyApplication.getContext()
                                    .getSystemService(KEYGUARD_SERVICE);
                            KeyguardManager.KeyguardLock keyguardLock = keyguardManager.newKeyguardLock("unLock");
                            // 屏幕锁定
                            keyguardLock.reenableKeyguard();
                            keyguardLock.disableKeyguard(); // 解锁


                            Log.i("622","loacl    AutoOpen");
                            Intent intent2 = new Intent(context, MainActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                            startActivity(intent2);
                        }

                        postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if(!SPTool.getBoolean(context,"InBackground")){
                                    //在前台
                                    Log.i("524","222222222222   在前台");
                                    //收到通知内容   播报第一条订单
                                    EventBus.getDefault().post(new EventBean(2));
                                }
                            }
                        }, 3000);
                    }
                }
                break;

                case MsgBox.MSG_ON_CONTINUE_PLAY_ORDER: //续播订单


                    EventBus.getDefault().post(new EventBean(3));

                    break;
                case MsgBox.MSG_ON_FINISH_ORDER: {//完成订单

                }
                break;

                case MsgBox.MSG_SHUTDOWN_FAILED: {//连接服务器失败  重新连接
                    // ToastUtil.show(context, "网络异常 自动重连!");
                    Log.i("重新连接", " 断开 重新连接");


                }
                break;
                case MsgBox.MSG_ON_CONNECT: {
                    hearttime=System.currentTimeMillis();
                    isReceiving=true;
                    flagsocket=false;
                }
                break;
                case MsgBox.MSG_CLOSE_CONNECT:
                {
//                        Intent location = new Intent(context,LocationService.class);
//                        location.putExtra("CMD",2);
//                        stopService(location);
//
//
//                        Intent RomoteServiceun = new Intent(context,RomoteService.class);
//                        RomoteServiceun.putExtra("CMD",3);
//                        startService(RomoteServiceun);
//
//                        android.os.Process.killProcess(android.os.Process.myPid());

                }
                break;


                case MsgBox.MSG_BEAT: {//连接服务器失败  重新连接
                    hearttime=System.currentTimeMillis();
                }
                break;
                case MsgBox.MSG_SHUTDOWN_SUCCESS: {
                    // /登录成功
                    if (taskProgressheart != null && taskProgressheart.getStatus() == AsyncTask.Status.RUNNING)
                    {
                        taskProgressheart.cancel(true); // 如果Task还在运行，则先取消它，然后执行关闭activity代码
                        taskProgressheart = null;
                    }
                    taskProgressheart = new DoBackgroundheartTask();

                    if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.HONEYCOMB_MR1)
                    {
                        taskProgressheart.execute(0);
                    } else {
                        taskProgressheart.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);//
                    }



                }
                break;
                case MsgBox.MSG_CONNECT_SUCCESS:
                {




                }
                break;

                case MsgBox.MSG_ON_CAR_NO_SAME: {//有别的司机用此车牌登录
                    stopPlayMusic();
                    SPTool.putInt(context, Constant.DriverState,0);
                    // 这个方法只能用于自杀操作
                    com.hnty.driver.application.MyApplication.getInstance().driverOutLine();
                    postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            // 获取当前进程的id
                            int pid = android.os.Process.myPid();
                            // 这个方法只能用于自杀操作
                            android.os.Process.killProcess(pid);
                        }
                    }, 6000);


                }
                break;


                case MsgBox.MSG_ON_OTHER_ORDER: {//别人接单

                    Log.i("425", "  main 接收到的消息  1003  content  == ");

                    ComplaintOrderBean bean = new Gson().fromJson(((String)msg.obj),ComplaintOrderBean.class);
                    com.hnty.driver.application.MyApplication.removeBean(-1,bean.body.voice_order);
                    if(!SPTool.getBoolean(context,"InBackground")){
                        //在前台
                        Log.i("524","222222222222   在前台");
                        //收到通知内容   播报第一条订单
                        EventBus.getDefault().post(new EventBean(4,(String)msg.obj));
                    }

                    //myWindowManager.updatetview("2");
                    break;
                }

                case MsgBox.MSG_ON_NOTICE:

                    //系统公告
                    SPTool.putString(context, Constant.Notice, (String) msg.obj);
                    EventBus.getDefault().post(new EventBean(1,(String) msg.obj));

                    break;

                case MsgBox.MSG_ON_PLAY_COMPLETE://续播声音

                    postDelayed(new Runnable() {
                        @Override
                        public void run() {

                            //续播声音
                            try { EventBus.getDefault().post(new EventBean(5)); }catch (Exception e){}
                            try {
                                if(com.hnty.driver.application.MyApplication.getOrderList().size()>0){
                                    Message msg = new Message();
                                    msg.what = MsgBox.MSG_ON_CONTINUE_PLAY_ORDER;
                                    mHandler.sendMessage(msg);
                                }
                            }catch (Exception e){ }
                        }
                    }, 5000);

                    break;
                default:
                    break;
            }
        };
    };


    @Override
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);


    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(EventBean event) {
        switch (event.code){

            case 101://续播订单

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        try { EventBus.getDefault().post(new EventBean(5)); }catch (Exception e){}

                        try {
                            if(MyApplication.getOrderList().size()>0){
                                Message msg = new Message();
                                msg.what = MsgBox.MSG_ON_CONTINUE_PLAY_ORDER;
                                mHandler.sendMessage(msg);
                            }

                        }catch (Exception e){

                        }
                    }
                }, 5000);

                break;
        }
    };

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @SuppressLint("WrongConstant")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        myService = this;
        flags=START_STICKY;
        startPlayMusic();
        if (intent == null) {
            hearttime=System.currentTimeMillis();
            if (conn!=null) {
                this.bindService(new Intent(this, RomoteService.class), conn, Context.BIND_IMPORTANT);
            }

            if(MainActivity.mainActivity==null){
                Intent intent2 = new Intent(context, MainActivity.class);
                intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                context.startActivity(intent2);
            }



            if(SPTool.getInt(context,"DriverState")==1) {
                if (notification!=null)
                {
                    new Thread(
                            new Runnable() {
                                @Override
                                public void run() {
                                    startForeground(HASH_CODE, notification);
                                }
                            }

                    ).start();
                }

                isReceiving = true;
                hearttime=System.currentTimeMillis();
                if (taskProgress != null && taskProgress.getStatus() == AsyncTask.Status.RUNNING )
                {
                    Log.e("taskProgress", "run1111");
                }else
                {
                    taskProgress = new DoBackgroundTask();

                    if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.HONEYCOMB_MR1)
                    {
                        taskProgress.execute(0);
                    } else {
                        taskProgress.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);//
                    }
                }
                mCalendar = Calendar.getInstance();
                mCalendar.setTimeInMillis(System.currentTimeMillis());
                mCalendar.add(Calendar.SECOND, 60);
                //通过AlarmManager定时启动广播
                alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
                Intent timeTaskIntent = new Intent(this, AlarmReceiver.class);
                PendingIntent pIntent = PendingIntent.getBroadcast(this, 0, timeTaskIntent, PendingIntent.FLAG_CANCEL_CURRENT);
                int apiLevel = getApiLevel();
                if (apiLevel < Build.VERSION_CODES.KITKAT) {
                    Log.d("api<19", "setExactAlarmCompat ");
                    alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, mCalendar.getTimeInMillis(), 60, pIntent);
                } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                        alarmManager.setExact(AlarmManager.RTC_WAKEUP, mCalendar.getTimeInMillis(), pIntent);
                    }
                    Log.d("19<api<23", "setExactAlarmCompat ");
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, mCalendar.getTimeInMillis(), pIntent);
                    //alarmManager.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, mCalendar.getTimeInMillis(), pIntent);
                    Log.d("api>23", "setExactAlarmCompat ");
                }
            }
//            long current = System.currentTimeMillis();
//            String time = new SimpleDateFormat("yyyyMMddHHmmss")
//                    .format(new Date(current));
//            // 以当前时间创建log文件
//            File file = new File(Constant.LOG_PATH + "etime.txt");
//
//            try (
//                    PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)))) {
//                // 导出发生异常的时间
//                pw.println(time);
//                pw.close();
//            }catch (Exception e) {
//                Log.e("ad", "dump crash info failed");
//            }



        }else {
            Log.i("515","MyService == "+this.toString());
            Log.i("onStartCommandloca","onStartCommand == "+intent.getIntExtra("CMD",0));
            switch (intent.getIntExtra("CMD",0)) {

                case 0:
                    break;
                case 1:


                    isReceiving = true;
                    Log.i("api", "setExactAlarmCompat "+Build.VERSION.SDK_INT);
                    if(SPTool.getInt(context,"DriverState")==1) {

                        if (notification!=null)
                        {
                            new Thread(
                                    new Runnable() {
                                        @Override
                                        public void run() {
                                            startForeground(HASH_CODE, notification);
                                        }
                                    }

                            ).start();
                        }

                        if(MainActivity.mainActivity==null){
                            Intent intent2 = new Intent(context, MainActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                            context.startActivity(intent2);
                        }

                        mCalendar = Calendar.getInstance();
                        mCalendar.setTimeInMillis(System.currentTimeMillis());
                        mCalendar.add(Calendar.SECOND, 60);
                        //通过AlarmManager定时启动广播
                        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
                        Intent timeTaskIntent = new Intent(this, AlarmReceiver.class);
                        PendingIntent pIntent = PendingIntent.getBroadcast(this, 0, timeTaskIntent, PendingIntent.FLAG_CANCEL_CURRENT);
                        int apiLevel = getApiLevel();

                        if (apiLevel < Build.VERSION_CODES.KITKAT) {
                            Log.d("api<19", "setExactAlarmCompat ");
                            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, mCalendar.getTimeInMillis(), 60, pIntent);
                        } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                                alarmManager.setExact(AlarmManager.RTC_WAKEUP, mCalendar.getTimeInMillis(), pIntent);
                            }
                            Log.d("19<api<23", "setExactAlarmCompat ");
                        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, mCalendar.getTimeInMillis(), pIntent);
                            //  alarmManager.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, mCalendar.getTimeInMillis(), pIntent);
                            Log.d("api>23", "setExactAlarmCompat ");
                        }
                    }
                    if (conn!=null) {
                        this.bindService(new Intent(this, LocalService.class), conn, Context.BIND_IMPORTANT);
                    }


                    hearttime=System.currentTimeMillis();
                    if (taskProgress != null && taskProgress.getStatus() == AsyncTask.Status.RUNNING )
                    {
                        Log.e("taskProgress", "run1");
                    }else
                    {
                        taskProgress = new DoBackgroundTask();
                        Log.e("taskProgress", "run2");
                        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.HONEYCOMB_MR1)
                        {
                            taskProgress.execute();
                        } else {
                            taskProgress.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);//
                        }
                    }


                    break;
                case 2:
                {
                    if (alarmManager!=null)
                    {
                        Intent timeTaskIntent = new Intent(this, AlarmReceiver.class);
                        PendingIntent sender = PendingIntent.getBroadcast(context, 0, timeTaskIntent,0);
                        alarmManager.cancel(sender);

                    }

                    Log.i("stoploc", "MyService == " + this.toString());
                    stopPlayMusic();
                    isReceiving = false;

                    if (taskProgress != null && taskProgress.getStatus() == AsyncTask.Status.RUNNING) {
                        taskProgress.cancel(true); // 如果Task还在运行，则先取消它，然后执行关闭activity代码
                        taskProgress = null;
                    }
                    if (taskProgressheart != null && taskProgressheart.getStatus() == AsyncTask.Status.RUNNING) {
                        taskProgressheart.cancel(true); // 如果Task还在运行，则先取消它，然后执行关闭activity代码
                        taskProgressheart = null;
                    }


                    MyApplication.getInstance().driveroffLine();

                    stopForeground(true);


                    return 0;
                }
                //  android.os.Process.killProcess(android.os.Process.myPid());
                //  break;
                case 3:

                    break;
                case 4:

                    break;
                case 5:
                    break;
            }
        }


        return START_STICKY;
        // return super.onStartCommand(intent, flags, startId);
    }


    public static int getApiLevel() {
        try {
            Field f = Build.VERSION.class.getField("SDK_INT");
            f.setAccessible(true);
            return f.getInt(null);
        } catch (Throwable e) {
            return 3;
        }
    }




    class MyBinder extends IMyAidlInterface.Stub {
        @Override
        public String getServiceName() throws RemoteException {

            return LocalService.class.getSimpleName();
        }
    }


    public LocalService() {
    }



    class MyConn implements ServiceConnection {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.i("xiaoqi", "绑定上了远程服务");
            bindflag=true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.i("xiaoqi", "远程服务被干掉了");
            bindflag=false;
            // Toast.makeText(LocalService.this, "远程服务挂了", Toast.LENGTH_SHORT).show();
            //开启远程服务
            if (isReceiving) {

                if (conn!=null) {
                    LocalService.this.startService(new Intent(LocalService.this, RomoteService.class));
                    //绑定远程服务
                    LocalService.this.bindService(new Intent(LocalService.this, RomoteService.class), conn, Context.BIND_IMPORTANT);
                }
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (wakeLock != null)
        {
            wakeLock.release();
            wakeLock = null;
        }
        //开启远程服务
        if (isReceiving) {
            if (conn!=null)
            {
                LocalService.this.startService(new Intent(LocalService.this, RomoteService.class));
                //绑定远程服务
                LocalService.this.bindService(new Intent(LocalService.this, RomoteService.class), conn, Context.BIND_IMPORTANT);

            }
        }

    }




    private void creatSocket() {


        Log.i("creatSocket","value =1 ");


    }

    private class DoBackgroundTask extends AsyncTask<Integer, Integer, Integer> {
        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @Override
        protected Integer doInBackground(Integer... integers) {
            Log.i("isReceiving", "socketconnsu()"+isReceiving );
            while(isReceiving)
            {
                hearttime=System.currentTimeMillis();
                while (SPTool.getUserInfo(LocalService.this) == null) {
                    try {
                        sleep(5000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                Log.i("socketconnsu", "socketconnsu()" );
                String msgByte=SPTool.getUserInfo(LocalService.this).body.driver_id;
                byte[] readbuff = new byte[1024 * 50];
                String driver_id = msgByte;
                String driverParam = "";
                Log.i("socketmain", "driver_id == " + driver_id);

                if (driver_id.length() == 1) {
                    driverParam = "     " + driver_id;
                } else if (driver_id.length() == 2) {
                    driverParam = "    " + driver_id;
                } else if (driver_id.length() == 3) {
                    driverParam = "   " + driver_id;
                } else if (driver_id.length() == 4) {
                    driverParam = "  " + driver_id;
                } else if (driver_id.length() == 5) {
                    driverParam = " " + driver_id;
                } else if (driver_id.length() == 6) {
                    driverParam = "" + driver_id;
                } else if (driver_id.length() > 6) {
                    ToastUtil.show(MyApplication.getContext(), "用户数量超过限制,请联系技术人员!");
                }

                String carNo =  SPTool.getString(LocalService.this,Constant.CarNo);

                Log.i("419","carNo.length = "+carNo.length());

                String carNoFormat = String.format("%1$-10s",carNo);

                Log.i("419","carNoFormat = "+carNoFormat);
                driverParam+=carNoFormat;
                Log.i("sendlogina","value = "+driverParam);
                if (mSocket==null)
                {
                    mSocket = new ClientSocket(ConnectURL.TCP_PORT);
                    while (!mSocket.createConnection())
                    {
                        try {
                            sleep(5000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }

                    flagsocket=true;
                }else
                {
                    mSocket.shutDownConnection();;
                    mSocket = new ClientSocket(ConnectURL.TCP_PORT);
                    while (!mSocket.createConnection())
                    {
                        try {
                            sleep(5000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    flagsocket=true;
                }

                boolean flagrec=mSocket.sendLogin(driverParam, 0x01);

                while (!flagrec)
                {


                    try {
                        sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    if (mSocket!=null)
                    {
                        mSocket.shutDownConnection();
                    }
                    mSocket = new ClientSocket(ConnectURL.TCP_PORT);
                    while (!mSocket.createConnection())
                    {
                        try {
                            sleep(5000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    flagrec=mSocket.sendLogin(driverParam, 0x01);
                }

                Log.i("sendlogin","etn = "+flagrec);

                ;
                int ilen = 0;
                while (true) {

                    try {
                        if (!flagsocket)
                        {
                            Log.e("flagsocket",  "error");
                            break;
                        }

                        if (!isReceiving)
                        {
                            break;
                        }
                        if (mSocket==null)
                        {
                            Log.i("mainsocketnull","value =1 ");
                            break;
                        }
                        if (mSocket.socket == null) {
                            Log.i("mainsocketsocketnull","value =2");
                            break;
                        }

                        if (mSocket.socket.isClosed()) {
                            Log.i("mainssocketisClosed()","value =3");
                            break;
                        }
                        if (!mSocket.socket.isConnected()) {
                            Log.i("mainssConnected()","value =3");
                            break;
                        }
                        Log.i("hearttime","value =3"+hearttime);
                        if (System.currentTimeMillis() - hearttime >= 30000)
                        {
                            Log.i("hearttime()","value =3"+hearttime);
                            break;
                        }
                        Arrays.fill(readbuff, (byte) 0);//清空数组
                        Log.e("mainsocketrecv", "run()" + "    1");

                        DataInputStream inputstream = mSocket.getMessageStream();
                        if (inputstream!=null)
                        {
                            ilen = inputstream.read(readbuff);
                        }else
                        {
                            Log.e("mainsocketrecverr", "run()" + "    2");
                            break;
                        }
                        Log.e("mainsocketrecv", "run()" + "    2");

                        if (ilen > 0) {
                            hearttime=System.currentTimeMillis();
                        }
                        if (readbuff[0] == 0x5a && readbuff[2] == 0x04 && ilen==4) {

                            mHandler.sendEmptyMessage(MsgBox.MSG_BEAT);

                        }else  if (readbuff[0] == 0x5a && readbuff[2] == 0x04 && ilen > 6 && readbuff[4] ==0x5a && readbuff[6] ==0x03 ) 
						{// 和心跳 粘包

                            String content = new String(readbuff, 13, ilen).trim();

                            Message msg = new Message();
                            msg.what = MsgBox.MSG_CONTENT;
                            msg.obj = content;

                            Log.e("cccccc", "接收到的消息  0x03  content  == " + content);
                            PushCode bean = new Gson().fromJson(content, PushCode.class);
                            if( bean.code == 1003){ //别人接单  推送的消息

                                msg.what = MsgBox.MSG_ON_OTHER_ORDER;
                                msg.obj = content;
                                mHandler.sendMessage(msg);

                            }else if( bean.code == 1008){

                                EventBus.getDefault().post(new EventBean(1008,(String)msg.obj));
                                Log.e("cccccc", "接收到的消息  完成订单  1008  content  == " + content);


                            }else if( bean.code == 1009){//跑腿

                                Log.e("7181","4");

//                            if(SPTool.getBoolean(context,Constant.ReceiveRun)){
                                SPTool.putString(MyApplication.getContext(), Constant.PushOrderBean, content);
                                MyApplication.getOrderList().add(SPTool.getPushOrderInfo(context));
                                Log.i("dd   订单", "接收到新订单   存储到集合 1");
                                msg.what = MsgBox.MSG_CONTENT;
                                mHandler.sendMessage(msg);

                                if(!VoiceUtils.with(context).IsPlaying){
                                    EventBus.getDefault().post(new EventBean(1020,(String)msg.obj));
                                }



                            }else if( bean.code == 1010){//代驾


                                Log.e("7181","5");


//                            if(SPTool.getBoolean(context,Constant.ReceiveDrive)){
                                SPTool.putString(MyApplication.getContext(), Constant.PushOrderBean, content);
                                MyApplication.getOrderList().add(SPTool.getPushOrderInfo(context));
                                Log.i("dd   订单", "接收到新订单   存储到集合2");
                                msg.what = MsgBox.MSG_CONTENT;
                                mHandler.sendMessage(msg);
                                MyApplication.getInstance().playDriveOrder();
//                            }



                            }else {

                                if (content.indexOf("}}")>0)
                                {
                                    try {
                                        content=content.substring(0, content.indexOf("}}") + 2);
                                    }catch (Exception e)
                                    {

                                    }

                                }
 								if(MyApplication.getOrderList().size()>10){
                                    break;
                                }
                                SPTool.putString(MyApplication.getContext(), Constant.PushOrderBean, content);
                                MyApplication.getOrderList().add(SPTool.getPushOrderInfo(LocalService.this));
                                Log.i("dd   订单", "接收到新订单   存储到集合");

                                if(!VoiceUtils.with(context).IsPlaying){
                                 
//                                    MyApplication.getInstance().playNewOrder();
                                    EventBus.getDefault().post(new EventBean(1020));

                                }


                                msg.what = MsgBox.MSG_CONTENT;
                                mHandler.sendMessage(msg);


                            }

                           

//						break;
                        } else if (readbuff[0] == 0x5a && readbuff[2] == 0x01 && ilen==4) {
                            Message msg = new Message();
                            msg.what = MsgBox.MSG_SHUTDOWN_SUCCESS;
                            msg.obj = mSocket;
                            mHandler.sendMessage(msg);
                            Log.e("cccccc", "mHandler   0x01");
//						break;
                        } else if (readbuff[0] == 0x5a && readbuff[2] == 0x03 && ilen>4 && readbuff[ilen -4] != 0x5a && readbuff[ilen -2] !=0x04 ) 
						{//新订单推送   // 订单之间 粘包

                            String content = new String(readbuff, 9, ilen).trim();
                            Log.e("0x03no0x04", "接收到的消息  0x03  content  == " + content);
                            String tempcontent=content;
                            Message msg = new Message();
                            while (tempcontent.indexOf("}}")>0)
                            {
                                content=tempcontent.substring(tempcontent.indexOf("{"), tempcontent.indexOf("}}") + 2);


                                Log.e("0x03no0x04pro", "" + content);


                                msg.what = MsgBox.MSG_CONTENT;
                                msg.obj = content;
                                PushCode bean = new Gson().fromJson(content, PushCode.class);
                                if( bean.code == 1003){ //别人接单  推送的消息

                                    msg.what = MsgBox.MSG_ON_OTHER_ORDER;
                                    msg.obj = content;
                                    //mHandler.sendMessage(msg);

                                }else if( bean.code == 1008){

                                    EventBus.getDefault().post(new EventBean(1008,(String)msg.obj));
                                    Log.e("cccccc", "接收到的消息  完成订单  1008  content  == " + content);


                                }else if( bean.code == 1009){//跑腿

                                    Log.e("7181","4");

//                            if(SPTool.getBoolean(context,Constant.ReceiveRun)){
                                    SPTool.putString(MyApplication.getContext(), Constant.PushOrderBean, content);
                                    MyApplication.getOrderList().add(SPTool.getPushOrderInfo(context));
                                    Log.i("0x03no0x04订单", "接收到新订单   存储到集合 1");
                                    msg.what = MsgBox.MSG_CONTENT;
                                    // mHandler.sendMessage(msg);
                                    MyApplication.getInstance().playRunOrder();
//                            }


                                }else if( bean.code == 1010){//代驾


                                    Log.e("7181","5");


//                            if(SPTool.getBoolean(context,Constant.ReceiveDrive)){
                                    SPTool.putString(MyApplication.getContext(), Constant.PushOrderBean, content);
                                    MyApplication.getOrderList().add(SPTool.getPushOrderInfo(context));
                                    Log.i("dd   订单", "接收到新订单   存储到集合2");
                                    msg.what = MsgBox.MSG_CONTENT;
                                    //mHandler.sendMessage(msg);
                                    MyApplication.getInstance().playDriveOrder();
//                            }


//

                                }else {

                                    SPTool.putString(MyApplication.getContext(), Constant.PushOrderBean, content);
 									if(MyApplication.getOrderList().size()>10){
                                        break;
                                    }
                                    MyApplication.getOrderList().add(SPTool.getPushOrderInfo(LocalService.this));
                                    Log.i("0x03no0x04订单", "接收到新订单   存储到集合");
                                    EventBus.getDefault().post(new EventBean(1020));//有新订单的提示
                                    msg.what = MsgBox.MSG_CONTENT;
                                }

                                if (tempcontent.indexOf("}}") + 2>=tempcontent.length())
                                {
                                    break;
                                }
                                tempcontent=tempcontent.substring(tempcontent.indexOf("}}") + 2,tempcontent.length());
                                Log.e("0x03no0x04pro1", "" + tempcontent);
                                //回复收到确认
                                mSocket.sendLogin(bean.body.voice_order+SPTool.getUserInfo(context).body.driver_id, 0x08);

                                sleep(100);
                            }

                            mHandler.sendMessage(msg);

                        }else if (readbuff[0] == 0x5a && readbuff[2] == 0x03 && ilen>4 && readbuff[ilen -4] == 0x5a && readbuff[ilen -2] ==0x04 ) 
						{//新订单推送    // 订单 在前  心跳在后  粘包
                            String content = new String(readbuff, 9, ilen -4).trim();

                            Message msg = new Message();
                            msg.what = MsgBox.MSG_CONTENT;
                            msg.obj = content;

                            Log.e("0x03and0x04", "接收到的消息  0x03  content  == " + content);
                            PushCode bean = new Gson().fromJson(content, PushCode.class);
                            if( bean.code == 1003){ //别人接单  推送的消息

                                msg.what = MsgBox.MSG_ON_OTHER_ORDER;
                                msg.obj = content;
                                mHandler.sendMessage(msg);

                            }else if( bean.code == 1008){

                                EventBus.getDefault().post(new EventBean(1008,(String)msg.obj));
                                Log.e("cccccc", "接收到的消息  完成订单  1008  content  == " + content);


                            }else if( bean.code == 1009){//跑腿

                                Log.e("7181","4");

//                            if(SPTool.getBoolean(context,Constant.ReceiveRun)){
                                SPTool.putString(MyApplication.getContext(), Constant.PushOrderBean, content);
                                MyApplication.getOrderList().add(SPTool.getPushOrderInfo(context));
                                Log.i("dd   订单", "接收到新订单   存储到集合 1");
                                msg.what = MsgBox.MSG_CONTENT;
                                mHandler.sendMessage(msg);
                                MyApplication.getInstance().playRunOrder();
//                            }


                            }else if( bean.code == 1010){//代驾


                                Log.e("7181","5");


//                            if(SPTool.getBoolean(context,Constant.ReceiveDrive)){
                                SPTool.putString(MyApplication.getContext(), Constant.PushOrderBean, content);
                                MyApplication.getOrderList().add(SPTool.getPushOrderInfo(context));
                                Log.i("dd   订单", "接收到新订单   存储到集合2");
                                msg.what = MsgBox.MSG_CONTENT;
                                mHandler.sendMessage(msg);
                                MyApplication.getInstance().playDriveOrder();
//                            }



                            }else {

                                if (content.indexOf("}}")>0)
                                {
                                    try {
                                        content=content.substring(0, content.indexOf("}}") + 2);
                                    }catch (Exception e)
                                    {

                                    }

                                }
                                SPTool.putString(MyApplication.getContext(), Constant.PushOrderBean, content);
								
								if(MyApplication.getOrderList().size()>10){
                                    break;
                                }
                                MyApplication.getOrderList().add(SPTool.getPushOrderInfo(LocalService.this));
                                Log.i("0x03and0x04订单", "接收到新订单   存储到集合");
                                EventBus.getDefault().post(new EventBean(1020));//有新订单的提示
                                msg.what = MsgBox.MSG_CONTENT;
                                mHandler.sendMessage(msg);



                            }



                            //  Log.i("cccccc", "接收到的消息  PushOrderBean  == " + bean.toString());

                            //回复收到确认
                            mSocket.sendLogin(bean.body.voice_order+SPTool.getUserInfo(context).body.driver_id, 0x08);

//

                        }else if (readbuff[0] == 0x5a && readbuff[2] == 0x05 && ilen==13) {//踢下线


                            String content = new String(readbuff, 3, ilen).trim();
                            Log.e("out", "接收到的消息  0x05  content  == " + content);
                            Message msg = new Message();
                            msg.what = MsgBox.MSG_ON_CAR_NO_SAME;
                            msg.obj = content;

                            if(content.trim().equals( SPTool.getString(LocalService.this,Constant.CarNo))){

                                mHandler.sendMessage(msg);

                            }
                        }else if (readbuff[0] == 0x5a && readbuff[2] == 0x06) {

                            String content = new String(readbuff, 3, ilen).trim();
                            Log.e("out", "接收到的消息  content  == " + content);


                            Message msg = new Message();
                            msg.what = MsgBox.MSG_ON_NOTICE;
                            msg.obj = content;
                            mHandler.sendMessage(msg);
                        } else if (readbuff[0] == 0x5a && readbuff[2] == 0x07) {


                            String content = new String(readbuff, 3, ilen).trim();
                            EventBus.getDefault().post(new EventBean(1011,content));



                        }

                        sleep(500);
                    }catch (Exception ex) {
                        ex.printStackTrace();
                        Log.e("export", "接收到的消息  content  == "+ex.toString());
                        //mHandler.sendEmptyMessage(MsgBox.MSG_SHUTDOWN_FAILED);
                        if (!isReceiving)
                        {
                            break;
                        }
                    }

                }

                try {
                    sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            Log.i("Service","Downloading file: "+String.valueOf(values[0] + "% downloaded"));
        }

        @Override
        protected void onPostExecute(Integer aLong) {
            super.onPostExecute(aLong);
            Log.i("Service","Downloading file: "+ aLong + "bytes");
            stopSelf();
            //android.os.Process.killProcess(android.os.Process.myPid());
        }
    }
    private class DoBackgroundheartTask extends AsyncTask<Integer, Integer, Integer> {

        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @Override
        protected Integer doInBackground(Integer... integers) {

            int runi=0;
            while (isReceiving)
            {
                runi=0;
                String carNo = SPTool.getString(LocalService.this, Constant.CarNo);
                String carNoFormat = String.format("%1$-10s", carNo);
                //车牌同时在线

                if (mSocket!=null)
                {


                    Log.e("heartst",  "1");
                    String driver_id = SPTool.getUserInfo(LocalService.this).body.driver_id;
                    if (driver_id.length() == 1) {
                        driver_id = "     " + driver_id;
                    } else if (driver_id.length() == 2) {
                        driver_id = "    " + driver_id;
                    } else if (driver_id.length() == 3) {
                        driver_id = "   " + driver_id;
                    } else if (driver_id.length() == 4) {
                        driver_id = "  " + driver_id;
                    } else if (driver_id.length() == 5) {
                        driver_id = " " + driver_id;
                    } else if (driver_id.length() == 6) {
                        driver_id = "" + driver_id;
                    } else if (driver_id.length() > 6) {
                        ToastUtil.show(LocalService.this, "用户数量超过限制,请联系技术人员!");
                    }
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    int errorcount=0;
                    while (true) {

                        if (mSocket==null)
                        {
                            Log.e("heartstmSocket",  "null");
                            Message msg = new Message();
                            msg.what = MsgBox.MSG_ON_CONNECT;
                            mHandler.sendMessage(msg);
                            break;
                        }
                        if (runi==0) {
                            boolean isSendCarNo = mSocket.sendLogin(carNoFormat, 0x05);
                            if (!isSendCarNo) {
                                Log.e("heartisSendCarNo",  "error");
                                Message msg = new Message();
                                msg.what = MsgBox.MSG_ON_CONNECT;
                                mHandler.sendMessage(msg);
                                break;
                            }
                        }
                        runi++;
                        Log.e("hearttime", "超时1"+hearttime);
                        Log.e("hearttime", "超时2"+System.currentTimeMillis());
                        if (System.currentTimeMillis() - hearttime >= 40000)
                        {
                            //主通讯不工作了
                            Log.e("hearttime", "超时");
                            //isReceiving = false;
                            Message msg = new Message();
                            msg.what = MsgBox.MSG_ON_CONNECT;
                            mHandler.sendMessage(msg);
                            break;
                        }
                        if (!isReceiving) {
                            break;
                        }



                        if (mSocket != null) {
                            boolean isHeard = mSocket.sendLogin(driver_id, 0x04);
                            if (!isHeard)
                            {
                                errorcount++;
                            }else
                            {
                                errorcount=0;
                            }
                            if (errorcount>3)
                            {
                                errorcount=0;
                                Message msg = new Message();
                                msg.what = MsgBox.MSG_ON_CONNECT;
                                mHandler.sendMessage(msg);
                                break;
                            }
                            Log.e("heartsend", isHeard + "");

                        }


                        try {
                            sleep(10000);//心跳时间
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                    }

                }
                try {
                    sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            Log.i("Service","Downloading file: "+String.valueOf(values[0] + "% downloaded"));
        }

        @Override
        protected void onPostExecute(Integer aLong) {
            super.onPostExecute(aLong);
            Log.i("Service","Downloading file: "+ aLong + "bytes");
            stopSelf();
            //android.os.Process.killProcess(android.os.Process.myPid());
        }
    }


//    public boolean isForeground( ) {
//        // Get the Activity Manager
//        String PackageName = context.getPackageName();
//        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
//        List<ActivityManager.RunningTaskInfo> list = am.getRunningTasks(1);
//        if (list != null && list.size() > 0) {
//            ComponentName cpn = list.get(0).baseActivity;
//            // System.out.println(cpn.getClassName());
//            if (PackageName.equals(cpn.getClassName())) {
//                return true;
//            }
//        }
//        return false;
//    }



//    public boolean isAppOnForeground() {
//
//        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
//        String packageName = context.getPackageName();
//
//        List<ActivityManager.RunningAppProcessInfo> appProcesses = activityManager
//                .getRunningAppProcesses();
//        if (appProcesses == null)
//            return false;
//
//        for (ActivityManager.RunningAppProcessInfo appProcess : appProcesses) {
//            // The name of the process that this object is associated with.
//            if (appProcess.processName.equals(packageName)
//                    && appProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
//                return true;
//            }
//        }
//        return false;
//    }





}
