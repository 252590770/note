package com.hnty.driver.activity;


import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.databinding.DataBindingUtil;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.hnty.driver.LocalService;
import com.hnty.driver.R;
import com.hnty.driver.application.MyApplication;
import com.hnty.driver.databinding.MainTopDialogBinding;
import com.hnty.driver.entity.ComplaintParam;
import com.hnty.driver.entity.EventBean;
import com.hnty.driver.entity.OrderStatusParam;
import com.hnty.driver.entity.PushOrderBean;
import com.hnty.driver.entity.UserInfoBean;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.impl.PermissionResultListener;
import com.hnty.driver.inter.ComplaintOrderListener;
import com.hnty.driver.inter.OnDriverVoiceListener;
import com.hnty.driver.model.modelimpl.ComplaintOrderModelImpl;
import com.hnty.driver.model.modelimpl.OrderStatusModelImpl;
import com.hnty.driver.tts.MiniTTS;
import com.hnty.driver.util.JsonParser;
import com.hnty.driver.util.MyUtil;
import com.hnty.driver.util.SPTool;
import com.hnty.driver.util.ToastUtil;
import com.hnty.driver.util.VoiceUtils;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.Date;

public class MainTopDialog extends Activity implements OnClickListener, OnDriverVoiceListener, ComplaintOrderListener {


    Context context;
    public MainTopDialogBinding binding;

    public static MainTopDialog mainTopDialog;
    private LinearLayout llBottom;
    private LinearLayout btnListen;
    private LinearLayout btnGet;
    private LinearLayout btnComplain;
    private LinearLayout btnFinish;
    public TextView tvTel;
    public TextView tvTime;
    public TextView tvStart;
    public TextView tvEnd;
    public TextView tvMainBottomMid;
    PushOrderBean orderBean;

    int mp3Long;
    float t = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mainTopDialog = this;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//保持屏幕高亮
        binding = DataBindingUtil.setContentView(this, R.layout.main_top_dialog);
        binding.btnGetOrder.setBackground(getResources().getDrawable(R.drawable.circle_bg_gray));
        binding.btnGetOrder.setOnClickListener(MainTopDialog.this);
        binding.btnGetOrder.setClickable(false);

        getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);//需要添加的语句
        context = this;
        orderBean = (PushOrderBean) getIntent().getSerializableExtra("PushOrderBean");

        init();

        SPTool.putBoolean(context,Constant.IsPlay,false);
        EventBus.getDefault().register(this);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {




                mp3Long =   MyApplication.playMedia(orderBean, LocalService.myService.mHandler);




                binding.progressView.setPercentage(100,mp3Long+250);

//                new Handler().postDelayed(new Runnable() {
//                    @Override
//                    public void run() {
//                        yuYin();
//                    }
//                }, mp3Long);


                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        binding.btnGetOrder.setOnClickListener(MainTopDialog.this);
                        binding.btnGetOrder.setBackground(getResources().getDrawable(R.drawable.circle_bg_red));
                        binding.ivSound.setClickable(true);
                    }
                }, (mp3Long+250));



            }
        }, 1000);





        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                try
                {
                    binding.btnGetOrder.setClickable(true);

                    binding.btnGetOrder.setBackground(getResources().getDrawable(R.drawable.circle_bg_red));
                }catch (Exception e)
                {

                }
            }
        }, 12000);


        finishHandler. postDelayed( finishRunnable , 17000);

    }




    Handler  finishHandler = new Handler();

    Runnable finishRunnable = new Runnable() {
        @Override
        public void run() {
            finish();
        }
    };




    @Override
    protected void onDestroy() {


        VoiceUtils.with(context).SetIsPlay(false);
        try {
            VoiceUtils.with(context).player.release();
        }catch (Exception e){

        }

        EventBus.getDefault().unregister(this);
        finishHandler.removeCallbacks(finishRunnable);

        super.onDestroy();

    }




//    //////////////////////语音识别//////////////////////
//    // 语音听写对象
//    private SpeechRecognizer mIat;
//    /**
//     * 初始化监听器。
//     */
//    private InitListener mInitListener = new InitListener() {
//
//        @Override
//        public void onInit(int code) {
//            Log.d("caijiao", "SpeechRecognizer init() code = " + code);
//            if (code != ErrorCode.SUCCESS) {
//                Toast.makeText(context, ("初始化失败，错误码：" + code), Toast.LENGTH_SHORT).show();
//            }
//        }
//    };
//    RecognizerListener mRecogListener = new RecognizerListener() {
//        @Override
//        public void onVolumeChanged(int i, byte[] bytes) {
//
//        }
//
//        @Override
//        public void onBeginOfSpeech() {
//
//        }
//
//        @Override
//        public void onEndOfSpeech() {
//
//        }
//
//        @Override
//        public void onResult(RecognizerResult recognizerResult, boolean b) {
//            if(!b){
//                String text = JsonParser.parseIatResult(recognizerResult.getResultString());
//                ToastUtil.show(context,text);
//
//                if(text.contains("接单")|text.contains("抢单")){
//                    jiedan("1");
//                }
//
//            }
//        }
//
//        @Override
//        public void onError(SpeechError speechError) {
//
//        }
//
//        @Override
//        public void onEvent(int i, int i1, int i2, Bundle bundle) {
//
//        }
//    };
//
//    void yuYin() {
//
//        //使用SpeechRecognizer对象，可根据回调消息自定义界面；
//
//        if(mIat == null ){
//            mIat = SpeechRecognizer.createRecognizer(context, mInitListener);
//        }
//
//
//        //设置语法ID和 SUBJECT 为空，以免因之前有语法调用而设置了此参数；或直接清空所有参数，具体可参考 DEMO 的示例。
//        mIat.setParameter(SpeechConstant.CLOUD_GRAMMAR, null);
//        mIat.setParameter(SpeechConstant.SUBJECT, null);
//        //设置返回结果格式，目前支持json,xml以及plain 三种格式，其中plain为纯听写文本内容
//        mIat.setParameter(SpeechConstant.RESULT_TYPE, "json");
//        //此处engineType为“cloud”
//        mIat.setParameter(SpeechConstant.ENGINE_TYPE, "cloud");
//        //设置语音输入语言，zh_cn为简体中文
//        mIat.setParameter(SpeechConstant.LANGUAGE, "zh_cn");
//        //设置结果返回语言
//        mIat.setParameter(SpeechConstant.ACCENT, "zh_cn");
//        // 设置语音前端点:静音超时时间，单位ms，即用户多长时间不说话则当做超时处理
//        //取值范围{1000～10000}
//        mIat.setParameter(SpeechConstant.VAD_BOS, "4000");
//        //设置语音后端点:后端点静音检测时间，单位ms，即用户停止说话多长时间内即认为不再输入，
//        //自动停止录音，范围{0~10000}
//        mIat.setParameter(SpeechConstant.VAD_EOS, "1000");
//        //设置标点符号,设置为"0"返回结果无标点,设置为"1"返回结果有标点
//        mIat.setParameter(SpeechConstant.ASR_PTT, "1");
//
//        //开始识别，并设置监听器
//        mIat.startListening(mRecogListener);
//
//
//    }
    //////////////////////语音识别//////////////////////




    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(EventBean event) {
        switch (event.code) {
            case 11:
//                binding.btnGetOrder.setOnClickListener(this);
//                binding.btnGetOrder.setBackground(getResources().getDrawable(R.drawable.circle_bg_red));
                break;

            case Constant.NeedPlay:
                try {
                    MyApplication.playMedia(orderBean, LocalService.myService.mHandler);
                } catch (Exception e) {
                }
                break;
        }
    };


    private void init() {
        binding.tvTel.setOnClickListener(this);
        binding.ivSound.setOnClickListener(this);
        binding.back.setOnClickListener(this);
        binding.ivSound.setClickable(false);

        try {
            binding.llFromTo.setVisibility(View.VISIBLE);
            binding.tvCong.setVisibility(View.GONE);
            binding.tvDao.setVisibility(View.GONE);
            binding.tvFrom.setText(orderBean.body.voice_file+" ");
        }catch (Exception e){}

        try {
            binding.tvTel.setText("乘客电话：" + MyUtil.TelNoToStarts(orderBean.body.voice_tell.trim()));
            binding.tvCount.setText("叫车次数：" + orderBean.body.count);

            if (orderBean.code == 1004 | orderBean.code == 1006) {
                binding.llFromTo.setVisibility(View.VISIBLE);
                binding.tvCong.setVisibility(View.VISIBLE);
                binding.tvDao.setVisibility(View.VISIBLE);
                binding.tvFrom.setText(orderBean.body.voice_file+" ");
                binding.tvTo.setText(orderBean.body.voice_end);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
//		finish();
        return true;
    }


    @Override
    public void onBackPressed() {

        if(VoiceUtils.with(context).IsPlaying){
            return   ;
        }
        try {   MyApplication.removeBean(0,null); } catch (Exception e){}

        super.onBackPressed();
    }



    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if(VoiceUtils.with(context).IsPlaying){

            return  false ;
        }

        return super.onKeyDown(keyCode, event);
    }








    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.back:

                try {   MyApplication.removeBean(0,null); } catch (Exception e){}
                finish();

                break;

            case R.id.btnGetOrder:

                Log.i("1213cai", "点击接单 btnGetOrder" );


                if (binding.btnGetOrder.getText().toString().equals("抢单")) {
                    binding.btnGetOrder.setClickable(false);
                    jiedan("1");
                } else {
                    //showSinpleChioceDialog();
                }

                break;

            case R.id.tvTel:

//                showTellDialog(2,"提示","打电话联系乘客？",orderBean.body.voice_tell);

                break;
            case R.id.ivSound:

                MyApplication.playMedia(SPTool.getPushOrderInfo(this), null);
//                binding.ivSound.setClickable(false);

                break;
        }

    }


    ////////////////////////接单////////////////////////
    OrderStatusModelImpl orderStatusModel = null;

    void jiedan(String statue) {

//        mIat.cancel();

        if (SPTool.getUserInfo(this) == null) {
            return;
        }

        if (orderStatusModel == null) {
            orderStatusModel = new OrderStatusModelImpl();
        }
        UserInfoBean userInfoBean = SPTool.getUserInfo(context);

        String lat = "";
        String lon = "";



        lat = SPTool.getString(context, "Driver_Lat").trim();
        lon = SPTool.getString(context, "Driver_Lon").trim();

//        if(lat.endsWith("")){
//
//        }
        if (lat=="" || lon=="")
        {
            lat = "0.0" ;
            lon = "0.0" ;
        }

        //showProgressDialog("请稍等...");
        OrderStatusParam param = new OrderStatusParam("getDrivervocie", statue,
                userInfoBean.body.driver_id,
                orderBean.body.voice_order,
                lat,
                lon
        );

        orderStatusModel.sendOrderStatus(param, MainTopDialog.this);
    }

    @Override
    public void onSuccess(String str) {
        Log.i("cccccc", "接单 Success==" + str);
//		showGPSDialog(2, "提示", "接单成功，导航至乘客位置");
        ToastUtil.show(context, "接单成功");
        MyApplication.getInstance().jieDan();

        Date date = new Date();
        int sec = (int) (date.getTime() / 1000); // 60*60*1000
        SPTool.putString(context, Constant.GetOrderTime, sec + "");

        dissmissProgressDialog();

        startActivity(new Intent(context, OrderDetailsActivity.class));

        SPTool.putString(this, Constant.MyPushOrderBean, orderBean.toString());

        MyApplication.getOrderList().clear();

        finish();

    }

    @Override
    public void onError(String err) {
        Log.i("cccccc", "接单 Error==" + err);


        if(err.contains("已被接")){
            yuYin(err);


        }

        binding.btnGetOrder.setClickable(true);
        ToastUtil.show(this, err);
        if (err.equals("账户余额为零请充值")) {
            yuYin(err);

        }

        SPTool.putString(MainTopDialog.this, Constant.PushOrderBean, "");
        dissmissProgressDialog();
    }
    ////////////////////////接单////////////////////////


    //////////////////进度框进度框进度框///////////////////
    //显示进度框
    private ProgressDialog progDialog = null;//

    private void showProgressDialog(String str) {
        if (progDialog == null)
            progDialog = new ProgressDialog(this);
        progDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progDialog.setIndeterminate(false);
        progDialog.setCancelable(true);
        progDialog.setMessage(str);
        progDialog.show();
    }

    //隐藏进度框
    private void dissmissProgressDialog() {
        if (progDialog != null) {
            progDialog.dismiss();
        }
    }
    //////////////////进度框进度框进度框///////////////////


    //////////////////打电话///////////////////
    //提示对话框
    public Dialog dialog;
    public TextView btn_one;
    public TextView btn_right;

    public interface ClickSureListener {
        public void click();
    }

    private ClickSureListener clickSureListener;

    public void showTellDialog(int type, String titleStr, String contentStr, final String tel) {
        if (dialog == null) {
            dialog = new AlertDialog.Builder(context).create();
        }
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = (View) inflater.inflate(R.layout.dialog_base, null);
        TextView title = (TextView) view.findViewById(R.id.title);
        TextView content = (TextView) view.findViewById(R.id.content);
        btn_one = (TextView) view.findViewById(R.id.btn_one);
        LinearLayout layout = (LinearLayout) view
                .findViewById(R.id.bottom_layout);
        btn_right = (TextView) view.findViewById(R.id.btn_right);
        if (type == 1) {
            btn_one.setVisibility(View.VISIBLE);
            layout.setVisibility(View.GONE);
        } else if (type == 2) {
            btn_one.setVisibility(View.GONE);
            layout.setVisibility(View.VISIBLE);
        }
        btn_one.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });

        btn_right.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });
        title.setText(titleStr);
        content.setText(contentStr);

        view.findViewById(R.id.btn_left).setOnClickListener(
                new OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

        view.findViewById(R.id.btn_right).setOnClickListener(
                new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        getTel(tel);
                        dialog.dismiss();
                    }
                });

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.show();
        dialog.getWindow().setContentView(view);
    }
    //提示对话框

    void getTel(String tel) {
        try {
            Intent call = new Intent(Intent.ACTION_DIAL);
            Uri data = Uri.parse("tel:" + tel);
            call.setData(data);
            startActivity(call);
        } catch (Exception e) {
        }
    }
    //////////////////打电话///////////////////


    //////////////////司机投诉///////////////////


    private ComplaintOrderModelImpl complaintOrderModel;//comlain

    void touSu(int which) {
        if (complaintOrderModel == null) {
            complaintOrderModel = new ComplaintOrderModelImpl();
        }
        try {

            ComplaintParam param;
            param = new ComplaintParam("getDrivercomplaint", which + "",
                    SPTool.getUserInfo(context).body.driver_id,
                    orderBean.body.voice_order,
                    SPTool.getMyPushOrderInfo(this).body.voice_tell);
            complaintOrderModel.sendComplaint(param, this);
        } catch (Exception e) {
        }
    }

    @Override
    public void onComplaintSuccess(String str) {
        ToastUtil.show(context, str);
    }

    @Override
    public void onComplaintError(String errStr) {
        ToastUtil.show(context, errStr);
    }
    //////////////////司机投诉///////////////////






    MiniTTS tts;//语音播报
    void  yuYin (final String str){


        performRequestPermissions(getString(R.string.permission_imei),
                new String[]{
                        Manifest.permission.MODIFY_AUDIO_SETTINGS
                }
                , PER_REQUEST_CODE,
                new PermissionResultListener() {
                    @Override
                    public void onPermissionDenied() {

                    }

                    @Override
                    public void onPermissionGranted() {

                        try {

                            tts = new MiniTTS(context);
                            tts.initPermission().initTTs();
                            tts.speak(str);
//                                    tts.speak("测试2");

                        }catch (Exception E)
                        {
                            E.printStackTrace();
                        }

                    }
                });
    }



    final protected int PER_REQUEST_CODE =0;
    //请求码
    private int mRequestCode;
    //运行时权限接口
    private PermissionResultListener mListener;
    protected void performRequestPermissions(String desc, String[] permissions,
                                             int requestCode,
                                             PermissionResultListener listener) {
        if (permissions == null || permissions.length == 0) {
            return;
        }
        mRequestCode = requestCode;
        mListener = listener;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkEachSelfPermission(permissions)) {// 检查是否声明了权限
                requestEachPermissions(desc, permissions, requestCode);
            } else {// 已经申请权限
                if (mListener != null) {
                    mListener.onPermissionGranted();
                }
            }
        } else {
            if (mListener != null) {
                mListener.onPermissionGranted();
            }
        }
    }



    /**
     * 检察每个权限是否申请
     *
     * @param permissions
     * @return true 需要申请权限,false 已申请权限
     */
    private boolean checkEachSelfPermission(String[] permissions) {
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) !=
                    PackageManager.PERMISSION_GRANTED) {
                return true;
            }
        }
        return false;
    }

    private void requestEachPermissions(String desc, String[] permissions, int requestCode) {
        if (shouldShowRequestPermissionRationale(permissions)) {// 需要再次声明
            showRationaleDialog(desc, permissions, requestCode);
        } else {
            ActivityCompat.requestPermissions(MainTopDialog.this, permissions, requestCode);
        }
    }


    /**
     * 再次申请权限时，是否需要声明
     *
     * @param permissions
     * @return
     */
    private boolean shouldShowRequestPermissionRationale(String[] permissions) {
        for (String permission : permissions) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 弹出声明的 Dialog
     *
     * @param desc
     * @param permissions
     * @param requestCode
     */
    private void showRationaleDialog(String desc, final String[] permissions,
                                     final int requestCode) {
        final android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.tips))
                .setMessage(desc)
                .setPositiveButton(getResources().getString(R.string.sure),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                ActivityCompat.requestPermissions(MainTopDialog.this,
                                        permissions, requestCode);
                            }
                        })
                .setNegativeButton(getResources().getString(R.string.cancel),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        })
                .setCancelable(false)
                .show();
    }




}
