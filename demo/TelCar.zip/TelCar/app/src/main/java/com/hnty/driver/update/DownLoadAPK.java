package com.hnty.driver.update;



public interface DownLoadAPK {

    void downLoad(FileDownLoadSubscriber subscriber, String url);

}
