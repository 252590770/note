package com.hnty.driver.model.modelimpl;

import android.util.Log;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.CodeParam;
import com.hnty.driver.entity.LoginParam;
import com.hnty.driver.entity.UserInfoBean;
import com.hnty.driver.inter.OnCodeListener;
import com.hnty.driver.inter.OnLoginListener;
import com.hnty.driver.model.modelinter.CodeModel;
import com.hnty.driver.model.modelinter.LoginModel;
import com.hnty.driver.util.NetworkUtil;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by L on 2018/1/12.
 */

public class CodeModelImpl implements CodeModel {

    @Override
    public void getCode(CodeParam param, final OnCodeListener listener) {

        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            listener.onCodeError("没有网络o");
            return;
        }

        MyApplication.getAPI().getCode(param.method,param.driver_tell)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<String>(){

                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull String s) {

                        try {
                            listener.onCodeSuccess(s);
                        }catch (Exception e){
                            listener.onCodeError("数据错误");
                        }
                    }
                    @Override
                    public void onError(@NonNull Throwable e) {
                        listener.onCodeError("数据错误");
                    }

                    @Override
                    public void onComplete() {
                    }
                });


    }



}
