package com.hnty.driver.model.modelinter;


import com.hnty.driver.entity.CodeParam;
import com.hnty.driver.entity.OrderStatusParam;
import com.hnty.driver.inter.OnCodeListener;
import com.hnty.driver.inter.OnOrderStateListener;

/**
 * Created by L on 2018/1/12.
 */

public interface OrderStateModel {

    void getOrderState(OrderStatusParam param, OnOrderStateListener listener);

}
