package com.hnty.driver.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.google.gson.Gson;
import com.hnty.driver.entity.ComplaintOrderBean;
import com.hnty.driver.entity.PushOrderBean;
import com.hnty.driver.entity.UserInfoBean;
import com.hnty.driver.finals.Constant;

import java.io.File;


public class SPTool {
    private static final String JSON_CACHE = "JSON_CACHE";

    public SPTool() {
    }

    public static void putContent(Context context, String tag, String content) {
        putString(context, tag, content);
    }

    public static String getContent(Context context, String tag) {
        return getString(context, tag);
    }



    //LoginCodeBean 获取用户信息
    public static UserInfoBean getUserInfo(Context context) {

        if(SPTool.getString(context, Constant.UserInfoBean).equals("")){

            Log.i("cccccc","getUserInfo == null");
            return null;
        }else {
            return new Gson().fromJson(SPTool.getString(context, Constant.UserInfoBean),UserInfoBean.class);
        }

    }

    //LoginCodeBean 获取用户信息
    public static UserInfoBean getPSW(Context context) {

        if(SPTool.getString(context, Constant.PSWBean).equals("")){

            Log.i("cccccc","getUserInfo == null");
            return null;
        }else {
            return new Gson().fromJson(SPTool.getString(context, Constant.PSWBean),UserInfoBean.class);
        }

    }



    //PushOrderInfo
    public static PushOrderBean getPushOrderInfo(Context context) {

        if(SPTool.getString(context, Constant.PushOrderBean).equals("")){
            Log.i("cccccc","getPushOrderInfo == null");
            return null;
        }else {
            return new Gson().fromJson(SPTool.getString(context, Constant.PushOrderBean),PushOrderBean.class);
        }
    }

    public static PushOrderBean getMyPushOrderInfo(Context context) {

        if(SPTool.getString(context, Constant.MyPushOrderBean).equals("")){
            Log.i("cccccc","getPushOrderInfo == null");
            return null;
        }else {
            return new Gson().fromJson(SPTool.getString(context, Constant.MyPushOrderBean),PushOrderBean.class);
        }
    }



    public static ComplaintOrderBean getComplaintOrderBean(Context context) {

        if(SPTool.getString(context, Constant.ComplaintOrderBean).equals("")){
            Log.i("cccccc","ComplaintOrderBean == null");
            return null;
        }else {
            return new Gson().fromJson(SPTool.getString(context, Constant.ComplaintOrderBean),ComplaintOrderBean.class);
        }
    }

    public static void putCrashLog(Context context, File file) {
        String value = file.getName();
        String key = Constant.CrashLog;
        SharedPreferences sp = context.getSharedPreferences(key, 0);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString(key, value);
        editor.commit();
    }


    public static void putString(Context context, String key, String value) {
        SharedPreferences sp = context.getSharedPreferences(key, 0);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString(key, value);
        editor.commit();
    }

    public static String getString(Context context, String key) {
        SharedPreferences sp = context.getSharedPreferences(key, 0);
        String value = sp.getString(key, "");
        return value;
    }

    public static void putInt(Context context, String key, int value) {
        SharedPreferences sp = context.getSharedPreferences(key, 0);
        SharedPreferences.Editor editor = sp.edit();
        editor.putInt(key, value);
        editor.commit();
    }

    public static int getInt(Context context, String key) {
        SharedPreferences sp = context.getSharedPreferences(key, 0);
        int value = sp.getInt(key, -1);
        return value;
    }

    public static void putLong(Context context, String key, long value) {
        SharedPreferences sp = context.getSharedPreferences(key, 0);
        SharedPreferences.Editor editor = sp.edit();
        editor.putLong(key, value);
         editor.commit();
    }

    public static long getLong(Context context, String key) {
        SharedPreferences sp = context.getSharedPreferences(key, 0);
        long value = sp.getLong(key, -1L);
        return value;
    }

    public static void putFloat(Context context, String key, float value) {
        SharedPreferences sp = context.getSharedPreferences(key, 0);
        SharedPreferences.Editor editor = sp.edit();
        editor.putFloat(key, value);
         editor.commit();
    }

    public static float getFloat(Context context, String key) {
        SharedPreferences sp = context.getSharedPreferences(key, 0);
        float value = sp.getFloat(key, -1.0F);
        return value;
    }

    public static void putBoolean(Context context, String key, boolean value) {
        SharedPreferences sp = context.getSharedPreferences(key, 0);
        SharedPreferences.Editor editor = sp.edit();
        editor.putBoolean(key, value);
         editor.commit();
    }

    public static boolean getBoolean(Context context, String key) {
        SharedPreferences sp = context.getSharedPreferences(key, 0);
        boolean value = sp.getBoolean(key, false);
        return value;
    }

    public static void remove(Context context, String key) {
        SharedPreferences sp = context.getSharedPreferences(key, 0);
        sp.edit().remove(key).apply();
    }

    public static void putJSONCache(Context context, String key, String content) {
        SharedPreferences sp = context.getSharedPreferences("JSON_CACHE", 0);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString(key, content);
         editor.commit();
    }

    public static String readJSONCache(Context context, String key) {
        SharedPreferences sp = context.getSharedPreferences("JSON_CACHE", 0);
        String jsoncache = sp.getString(key, (String)null);
        return jsoncache;
    }

    public static void clearPreference(Context context, String name, String key) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(name, 0);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        if(key != null) {
            editor.remove(key);
        } else {
            editor.clear();
        }

         editor.commit();
    }
}
