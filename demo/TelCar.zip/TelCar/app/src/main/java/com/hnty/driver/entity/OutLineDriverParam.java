package com.hnty.driver.entity;

/**
 * Created by L on 2018/1/11.
 */

public class OutLineDriverParam {
    public String method;
    public String driver_id;

    public OutLineDriverParam() {
    }

    public OutLineDriverParam(String method, String driver_id) {
        this.method = method;
        this.driver_id = driver_id;
    }
}
