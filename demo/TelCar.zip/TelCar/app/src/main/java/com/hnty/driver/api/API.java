package com.hnty.driver.api;


import com.hnty.driver.entity.BaseBean;
import com.hnty.driver.entity.ComplaintBean;
import com.hnty.driver.entity.DriverCancelBean;
import com.hnty.driver.entity.DriverDetailBean;
import com.hnty.driver.entity.DriverGetUserBean;
import com.hnty.driver.entity.DriverOutBean;
import com.hnty.driver.entity.DriverRankBean;
import com.hnty.driver.entity.FinishOrderBean;
import com.hnty.driver.entity.GetCodeForUpdateCarNoBean;
import com.hnty.driver.entity.GetDriverOrderStateBean;
import com.hnty.driver.entity.GetListResult;
import com.hnty.driver.entity.GetOrderEntity;
import com.hnty.driver.entity.NewsEntity;
import com.hnty.driver.entity.NewsParam;
import com.hnty.driver.entity.OrderLocationBean;
import com.hnty.driver.entity.OrderRepeatBean;
import com.hnty.driver.entity.OrderStateBean;
import com.hnty.driver.entity.OutLineDriverBean;
import com.hnty.driver.entity.PastOrderListBean;
import com.hnty.driver.entity.PushOrderBean;
import com.hnty.driver.entity.RegisterBean;
import com.hnty.driver.entity.UpdateBean;
import com.hnty.driver.entity.UpdateDriverBean;
import com.hnty.driver.entity.UserInfoBean;
import com.hnty.driver.entity.VoiceOrderByIdBean;
import com.hnty.driver.entity.VoiceOrderListBean;
import com.hnty.driver.finals.Constant;

import java.util.ArrayList;

import io.reactivex.Flowable;
import io.reactivex.Observable;
import okhttp3.ResponseBody;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Streaming;
import retrofit2.http.Url;

/**
 * Created by L on 2018/1/12.
 */

public interface API {

    @POST("nc/article/headline/T1348647909107/5-20.html")
    Observable<NewsEntity> getNews(@Body NewsParam param);

    @FormUrlEncoded
    @POST(Constant.travel+"/drivingOrdertoApp.action?")
    Observable<ArrayList<GetListResult>> getListWithRx(@Field("method") String method, @Field("page") String page);

    //接单travel/driverVocieOrder.action?method=getDrivervocie&voice_state=&driver_id=&voice_order=&get_latitude=0.0&get_longitude=0.0
    @FormUrlEncoded
    @POST(Constant.travel+"/driverVocieOrder.action?")
    Observable<GetOrderEntity> sendOrderStatus(@Field("method") String method,
                                               @Field("voice_state") String voice_state,
                                               @Field("driver_id") String driver_id,
                                               @Field("voice_order") String voice_order,
                                               @Field("get_latitude") String get_latitude,
                                               @Field("get_longitude") String get_longitude
    );

    //完成订单
    @FormUrlEncoded
    @POST(Constant.travel+"/driverendvoice.action?")
    Observable<FinishOrderBean> sendFinishOrder(@Field("method") String method,
                                                @Field("voice_state") String voice_state,
                                                @Field("driver_id") String driver_id,
                                                @Field("voice_order") String voice_order,
                                                @Field("driver_longitude") String get_latitude,
                                                @Field("driver_latitude") String get_longitude
    );




    //登录
    @FormUrlEncoded
    @POST(Constant.travel+"/driverlogininfo.action?")
    Observable<UserInfoBean> sendLogin(@Field("method") String method,
                                       @Field("driver_tell") String driver_tell,
                                       @Field("carno") String carno,
                                       @Field("driver_pass") String driver_pass,
                                       @Field("driver_ismi") String driver_ismi);

    //投诉
    @FormUrlEncoded
    @POST(Constant.travel+"/drivercomplaint.action?")
    Observable<ComplaintBean> sendTouSu(@Field("method") String method,
                                        @Field("complaint_desc") String complaint_desc,
                                        @Field("driver_id") String driver_id,
                                        @Field("order_id") String order_id,
                                        @Field("voice_tell") String voice_tell);



    //获取验证码
    @FormUrlEncoded
    @POST(Constant.travel+"/driverMessage.action?")
    Observable<String> getCode(@Field("method") String method,
                               @Field("driver_tell") String driver_tell);



    //注册
    @FormUrlEncoded
    @POST(Constant.travel+"/driverreg.action?")
    Observable<RegisterBean> sendRegister(@Field("method") String method,
                                          @Field("carno") String carno,
                                          @Field("driver_name") String driver_name,
                                          @Field("driver_tell") String driver_tell,
                                          @Field("driver_pass") String driver_pass,
                                          @Field("driver_ismi") String driver_ismi);

    //获取验证码
    @FormUrlEncoded
    @POST(Constant.travel+"/versionInfo.action?")
    Observable<UpdateBean> checkUpdate(@Field("method") String method);

    //http://192.168.0.253:8080/travel/versionInfo.action?method=getVersion

    //实时位置
    @FormUrlEncoded
    @POST(Constant.travel+"/driverPosi.action?")
    Observable<String> sendDriverPosition(@Field("method") String method,
                                          @Field("driver_latitude") String driver_latitude,
                                          @Field("driver_longitude") String driver_longitude,
                                          @Field("driver_id") String driver_id
    );


    //获取历史订单   /voiceorderbyid.action?method=getVoiceOrderbyid&driver_id
    @FormUrlEncoded
    @POST(Constant.travel+"/voiceorderbyid.action?")
    Observable<VoiceOrderByIdBean> voiceOrderById(@Field("method") String method,
                                                  @Field("driver_id") String driver_id,
                                                  @Field("page") String page
    );


    //获取订单状态   /travel/voiceOrderstate.action?method=getOrderstate&driver_id=19
    //travel/voiceOrderstate.action?method=getOrderstate  20180328
    @FormUrlEncoded
    @POST(Constant.travel+"/voiceOrderstate.action?")
    Observable<OrderStateBean> getOrderState(@Field("method") String method,
                                             @Field("driver_id") String driver_id

    );


    //未接订单(一小时内)   travel/voiceOrderlist.action?method=getVoiceOrder
    @FormUrlEncoded
    @POST(Constant.travel+"/voiceOrderlist.action?")
    Observable<PastOrderListBean> getPastOrder(@Field("method") String method,
                                               @Field("page") String page
    );




    //获取订单列表   travel/voiceOrderlistdesc.action?method=getVoiceOrderdesc
    @FormUrlEncoded
    @POST(Constant.travel+"/voiceOrderlistdesc.action?")
    Observable<VoiceOrderListBean> getOrderList(@Field("method") String method,
                                                @Field("page") String page
    );


    //上班   http://192.168.0.253:8080/travel/driverOutInfo.action?method=driverout&driver_id=19
    @FormUrlEncoded
    @POST(Constant.travel+"/driverOutInfo.action?")
    Observable<DriverOutBean> driverOut(@Field("method") String method,
                                        @Field("driver_id") String driver_id
    );

    //取消订单   driverCanceInfo.action?method=driverCancel
    @FormUrlEncoded
    @POST(Constant.travel+"/driverCanceInfo.action?")
    Observable<DriverCancelBean> driverCancel(@Field("method") String method,
                                              @Field("driver_id") String driver_id,
                                              @Field("voice_order") String voice_order
    );

    //订单重发   orderRepeatInfo.action?method=orderRepeat
    @FormUrlEncoded
    @POST(Constant.travel+"/orderRepeatInfo.action?")
    Observable<OrderRepeatBean> orderRepeat(@Field("method") String method,
                                            @Field("driver_id") String driver_id,
                                            @Field("voice_order") String voice_order
    );

    //下线司机   driverOutlineInfo.action?method=outlinedriver
    @FormUrlEncoded
    @POST(Constant.travel+"/driverOutlineInfo.action?")
    Observable<OutLineDriverBean> outLineDriver(@Field("method") String method,
                                                @Field("driver_id") String driver_id
    );


    //司机版本   driverVerinfoaction?method=updatedriverver
    @FormUrlEncoded
    @POST(Constant.travel+"/updatedriververInfo.action?")
    Observable<UpdateDriverBean> updateDriverver(@Field("method") String method,
                                                 @Field("driver_id") String driver_id,
                                                 @Field("driver_ver") String driver_ver
    );


    //接到乘客   travel/drivergetuserInfo.action?method=drivergetuser
    @FormUrlEncoded
    @POST(Constant.travel+"/drivergetuserInfo.action?")
    Observable<DriverGetUserBean> driverGetUser(@Field("method") String method,
                                                @Field("driver_id") String driver_id,
                                                @Field("voice_order") String voice_order
    );



    //接到乘客   v3/geocode/regeo?
    // output=JSON&
    // location=116.481488,39.990464&
    // key=d6a0cb18838da2ebb137e2a800e478db&
    // radius=0&
    // extensions=base
    @FormUrlEncoded
    @POST("v3/geocode/regeo?")
    Observable<OrderLocationBean> getOrderLocation(@Field("output") String output,
                                                   @Field("location") String location,
                                                   @Field("key") String key,
                                                   @Field("radius") String radius,
                                                   @Field("extensions") String extensions
    );



    //   travel/driverDetail.action?method=getDriverdetail&driver_ismi=
    @FormUrlEncoded
    @POST(Constant.travel+"/driverDetail.action?")
    Observable<DriverDetailBean> getDriverDetail(@Field("method") String method,
                                                 @Field("driver_ismi") String driver_ismi
    );


    //   http://111.26.200.85:8088/travel/driverRank.action?method=getDriverrank
    @FormUrlEncoded
    @POST(Constant.travel+"/driverRank.action?")
    Observable<ArrayList<DriverRankBean>> getDriverRank(@Field("method") String method
    );








    @Streaming
    @GET
    Flowable<ResponseBody> downLoad(@Url String url);





    //   outvoiceOrderstate.action?method=getdriverOrderstate  driver_id=3199
    @FormUrlEncoded
    @POST(Constant.travel+"/outvoiceOrderstate.action?")
    Observable<GetDriverOrderStateBean> getDriverOrderState(@Field("method") String method,
                                                            @Field("driver_id") String driver_id
    );



    //获取订单状态   /travel/setDriverinfo.action?
    @FormUrlEncoded
    @POST(Constant.travel+"/setDriverinfo.action?")
    Observable<BaseBean> setDriverinfo(@Field("method") String method,
                                       @Field("driver_name") String driver_name,
                                       @Field("driver_tell") String driver_tell,
                                       @Field("driver_pass") String driver_pass
    );


    //xin ge
    @FormUrlEncoded
    @POST(Constant.travel+"/xgtoken.action?")//xgtoken.action?method=getxgtoken
    Observable<Integer> upLoadToken(@Field("method") String method,
                                    @Field("id") String id,
                                    @Field("token") String token
    );

    //上传二维码
    @FormUrlEncoded
    @POST(Constant.travel+"/skancodeinfo.action?")//skancodeinfo.action?method=skanCode&card_num
    Observable<BaseBean> scanCodeInfo(@Field("method") String method,
                                      @Field("card_num") String card_num,
                                      @Field("driver_id") String dirver_id,
                                      @Field("voice_tell") String voice_tell,
                                      @Field("voice_order") String voice_order
    );






    //获取验证码
    @FormUrlEncoded
    @POST(Constant.travel+"/driverbycarsmsInfo.action?")//travel/driverbycarsmsInfo.action?method=driverbycarsms&driver_tell
    Observable<GetCodeForUpdateCarNoBean> getCodeForUpdateCarNo(@Field("method") String method,
                                                                @Field("car_no") String car_no
    );




    //更新车牌
    @FormUrlEncoded
    @POST(Constant.travel+"/driverOutbycarInfo.action?")//travel/driverOutbycarInfo.action?method=driveroutbycar&driver_id=3225&car_no
    Observable<BaseBean> driverOutByCarInfo(@Field("method") String method,
                                               @Field("driver_id") String driver_id,
                                               @Field("car_no") String car_no
    );

    //UpdateIsmi
    @FormUrlEncoded
    @POST(Constant.travel+"/updateIsminfo.action?")
    Observable<BaseBean> updateIsmi(@Field("method") String method,
                                    @Field("driver_tell") String driver_tell,
                                    @Field("carno") String carno,
                                    @Field("driver_ismi") String driver_ismi
    );



    //travel/toPosyinfo.action?method=toPosy&    billNo=&    totalAmount=
    @FormUrlEncoded
    @POST(Constant.travel+"/toPosyinfo.action?")
    Observable<String> toPosy(@Field("method") String method,
                                    @Field("billNo") String billNo,
                                    @Field("totalAmount") String totalAmount
    );


    //travel/toPosyinfo.action?method=toPosy&    billNo=&    totalAmount=
    //getPosyinfo.action?method=getPosy&billNo=
    @FormUrlEncoded
    @POST(Constant.travel+"/getPosyinfo.action?")
    Observable<String> getPosy(@Field("method") String method,
                              @Field("billNo") String billNo
    );

}
