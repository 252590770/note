package com.hnty.driver.inter;

import com.hnty.driver.entity.OutLineDriverBean;
import com.hnty.driver.entity.UpdateDriverBean;

/**
 * Created by Think-pc on 2018/5/27.
 */

public interface OnUpdateDriverVerListener {
    void onUpdateDriverVerSuccess(UpdateDriverBean bean);
    void onUpdateDriververError(String errStr);
}
