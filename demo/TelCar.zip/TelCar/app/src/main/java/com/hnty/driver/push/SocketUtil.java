package com.hnty.driver.push;

public class SocketUtil {
	public static int HexToDec(String strvalue) {
		try {

			int sum = 0, tmp = 0;
			char args[] = strvalue.toCharArray();
			for (int i = 0; i < args.length; i++) {

				if (args[i] >= '0' && args[i] <= '9') {
					tmp = args[i] - '0';
				} else if (args[i] >= 'A' && args[i] <= 'F') {
					tmp = args[i] - 'A' + 10;
				} else {
					// System.out.println("有非法字符");
					break;
				}
				sum = sum * 16 + tmp;
			}
			return sum;

		} catch (Exception e) {

			return 0;
		}
	}

	public static byte[] intToByte(int number) {
		int temp = number;
		byte[] b = new byte[4];
		for (int i = b.length - 1; i > -1; i--) {
			b[i] = new Integer(temp & 0xff).byteValue(); // 将最高位保存在最低位
			temp = temp >> 8; // 向右移8位
		}
		return b;
	}

	public static byte[] toByteArray(int iSource, int iArrayLen) {
		byte[] bLocalArr = new byte[iArrayLen];
		for (int i = 0; (i < 4) && (i < iArrayLen); i++) {
			bLocalArr[i] = (byte) (iSource >> 8 * i & 0xFF);
		}
		return bLocalArr;
	}

	/**
	 * long转换为byte数组
	 * 
	 * @param bb
	 * @param x
	 */
	public static void long2Byte(byte[] bb, long x) {
		bb[0] = (byte) (x >> 56);
		bb[1] = (byte) (x >> 48);
		bb[2] = (byte) (x >> 40);
		bb[3] = (byte) (x >> 32);
		bb[4] = (byte) (x >> 24);
		bb[5] = (byte) (x >> 16);
		bb[6] = (byte) (x >> 8);
		bb[7] = (byte) (x >> 0);
	}
}
