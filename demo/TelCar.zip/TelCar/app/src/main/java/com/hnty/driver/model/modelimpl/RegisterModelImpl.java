package com.hnty.driver.model.modelimpl;

import android.util.Log;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.RegisterBean;
import com.hnty.driver.entity.RegisterParam;
import com.hnty.driver.entity.RegisterParam;
import com.hnty.driver.inter.OnRegisterListener;
import com.hnty.driver.inter.OnRegisterListener;
import com.hnty.driver.model.modelinter.RegisterModel;
import com.hnty.driver.model.modelinter.RegisterModel;
import com.hnty.driver.util.NetworkUtil;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by L on 2018/1/12.
 */

public class RegisterModelImpl implements RegisterModel {

    
    
    
    @Override
    public void sendRegister(RegisterParam param, final OnRegisterListener listener) {

        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            listener.onRegisterError("没有网络o");
            return;
        }





        MyApplication.getAPI().sendRegister(param.method,
                param.carno,
                param.driver_name,
                param.driver_tell,
                param.driver_pass,
                param.driver_ismi)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<RegisterBean>(){

                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull RegisterBean bean) {

                        Log.i("cccccc","onNext =="+bean.toString());


                        try {

                            if(bean.code==1){
                                listener.onRegisterSuccess(bean.msg);
                            }else if(bean.code==0){
                                listener.onRegisterError(bean.msg);
//                                listener.onRegisterError(new Exception(bean.msg));
                            }
                        }catch (Exception e){
                            listener.onRegisterError("数据错误" );
                        }
                    }
                    @Override
                    public void onError(@NonNull Throwable e) {
                        listener.onRegisterError("数据错误");
                    }

                    @Override
                    public void onComplete() {
                    }
                });


    }


    
}
