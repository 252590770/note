package com.hnty.driver.inter;


import com.hnty.driver.entity.DriverCancelBean;
import com.hnty.driver.entity.OrderRepeatBean;

/**
 * Created by L on 2018/1/12.
 */

public interface OnOrderRepeatListener {

    void onOrderRepeatSuccess(OrderRepeatBean bean);
    void onOrderRepeatError(String errStr);

}
