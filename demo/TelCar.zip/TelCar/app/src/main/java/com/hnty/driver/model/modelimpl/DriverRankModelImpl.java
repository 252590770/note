package com.hnty.driver.model.modelimpl;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.DriverCancelBean;
import com.hnty.driver.entity.DriverCancelParam;
import com.hnty.driver.entity.DriverRankBean;
import com.hnty.driver.inter.OnDriverCancelListener;
import com.hnty.driver.inter.OnDriverRankListener;
import com.hnty.driver.model.modelinter.DriverCancelModel;
import com.hnty.driver.model.modelinter.DriverRankModel;
import com.hnty.driver.util.NetworkUtil;

import java.util.ArrayList;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by L on 2018/1/12.
 */

public class DriverRankModelImpl implements DriverRankModel {


    @Override
    public void getDriverRank(final OnDriverRankListener listener) {

        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            listener.onDriverRankError("没有网络o");
            return;
        }

        MyApplication.getAPI().getDriverRank("")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ArrayList<DriverRankBean>>(){

                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull ArrayList<DriverRankBean> list) {

                        try {
                            listener.onDriverRankSuccess(list);

                        }catch (Exception e){
                            listener.onDriverRankError("数据错误" );
                        }
                    }
                    @Override
                    public void onError(@NonNull Throwable e) {
                        listener.onDriverRankError("数据错误");
                    }

                    @Override
                    public void onComplete() {
                    }
                });


    }



}
