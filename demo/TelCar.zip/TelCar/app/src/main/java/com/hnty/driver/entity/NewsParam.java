package com.hnty.driver.entity;

/**
 * Created by L on 2018/1/12.
 */

public class NewsParam {
}
