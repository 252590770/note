package com.hnty.driver.entity;

/**
 * Created by Think-pc on 2018/5/27.
 */

public class UpdateDriverVerParam {
    public String method;
    public String driver_id;
    public String driver_ver;

    public UpdateDriverVerParam() {
    }

    public UpdateDriverVerParam(String method, String driver_id,String driver_ver) {
        this.method = method;
        this.driver_id = driver_id;
        this.driver_ver=driver_ver;
    }
}
