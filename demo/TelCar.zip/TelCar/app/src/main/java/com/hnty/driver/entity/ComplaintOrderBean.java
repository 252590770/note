package com.hnty.driver.entity;


import java.io.Serializable;

public class ComplaintOrderBean implements Serializable {

    public String code;
    public String msg;
    public BodyBean body;

    public static class BodyBean implements Serializable{

        public String voice_order;
        public String voice_tell;
        public String get_longitude;
        public String get_latitude;
        public String driver_name;
        public String oper_date;
        public String car_no;
        public String voice_name;
        public String count;
 
    }
}
