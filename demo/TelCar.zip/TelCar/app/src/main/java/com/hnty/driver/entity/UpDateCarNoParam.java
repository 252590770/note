package com.hnty.driver.entity;

/**
 * Created by L on 2018/1/11.
 */

public class UpDateCarNoParam {
    public String method;
    public String driver_id;
    public String car_no;

    public UpDateCarNoParam() {
    }

    public UpDateCarNoParam(String method, String driver_id, String car_no) {
        this.method = method;
        this.driver_id = driver_id;
        this.car_no = car_no;
    }
}
