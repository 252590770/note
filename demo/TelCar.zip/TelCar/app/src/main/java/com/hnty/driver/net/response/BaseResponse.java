package com.hnty.driver.net.response;

/**
 * 网络请求返回对象基类
 * 
 * @version 1.0.0
 */
public class BaseResponse {
	/**
	 * status:错误代码 msg:描述 data:数据
	 */
	public String status;
	/**
	 * 回执消息
	 */
	public String msg;
	/**
	 * 0表示成功和无数据
	 */
	public static final String R_OK = "0";
	public static final String R_OK2 = "2";
}
