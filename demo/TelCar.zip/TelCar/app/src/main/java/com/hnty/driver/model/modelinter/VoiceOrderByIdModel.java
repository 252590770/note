package com.hnty.driver.model.modelinter;


import com.hnty.driver.entity.UpdateParam;
import com.hnty.driver.entity.VoiceOrderStateParam;
import com.hnty.driver.inter.OnUpdateListener;
import com.hnty.driver.inter.OnVoiceOrderStateListener;
import com.hnty.driver.inter.VoiceOrderByIdListener;

/**
 * Created by L on 2018/1/12.
 */

public interface VoiceOrderByIdModel {

    void getVoiceOrderState(VoiceOrderStateParam param, VoiceOrderByIdListener listener);

}
