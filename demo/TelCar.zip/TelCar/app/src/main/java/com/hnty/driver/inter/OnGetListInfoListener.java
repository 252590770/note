package com.hnty.driver.inter;


import com.hnty.driver.entity.GetListResult;

import java.util.ArrayList;

/**
 * Created by L on 2018/1/12.
 */

public interface OnGetListInfoListener {
    void onSuccess(ArrayList<GetListResult> listResults);
    void onError(Object err);
}
