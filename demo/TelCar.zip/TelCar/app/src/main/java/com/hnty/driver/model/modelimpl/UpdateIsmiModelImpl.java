package com.hnty.driver.model.modelimpl;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.BaseBean;
import com.hnty.driver.inter.OnUpdateIsmiListener;
import com.hnty.driver.util.NetworkUtil;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by L on 2018/1/12.
 */

public class UpdateIsmiModelImpl {

    public void updateIsmi(String driver_tell,String carno,String driver_ismi, final OnUpdateIsmiListener listener) {

        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            listener.onUpdateError("没有网络o");
            return;
        }

        MyApplication.getAPI().updateIsmi("updateIsmi",""+driver_tell,""+carno,""+driver_ismi)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<BaseBean>(){

                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull BaseBean b) {

                        try {
                            if(b.code==1){
                                listener.onUpdateSuccess(b );
                            }else {
                                listener.onUpdateError(b.msg);
                            }
                        }catch (Exception e){
                            listener.onUpdateError("数据错误");
                        }
                    }
                    @Override
                    public void onError(@NonNull Throwable e) {
                        listener.onUpdateError("数据错误");
                    }

                    @Override
                    public void onComplete() {
                    }
                });


    }



}
