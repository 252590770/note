package com.hnty.driver.activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.hnty.driver.BuildConfig;
import com.hnty.driver.MainActivity;
import com.hnty.driver.R;
import com.hnty.driver.base.BaseActivity;
import com.hnty.driver.databinding.ActivityUpdateBinding;
import com.hnty.driver.entity.UpdateBean;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.inter.OnUpdateListener;
import com.hnty.driver.model.modelimpl.UpdateModelImpl;
import com.hnty.driver.util.SPTool;
import com.hnty.driver.util.ToastUtil;

/**
 * Created by Administrator on 2017/4/27.
 */

public class UpDateActivity extends BaseActivity<ActivityUpdateBinding> implements OnUpdateListener {


    UpdateModelImpl updateModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        setTitle("检查更新");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//来保持屏幕高亮
        showContentView();

        bindingView.tvVersion.setText("v "+getASVersionName());

        updateModel = new UpdateModelImpl();
        SPTool.putBoolean(UpDateActivity.this, Constant.UserGetUpDate, true);
        showProgressDialog("请稍等");
        updateModel.checkUpdate(null, this);
    }



    //return 当前应用的VersionName

    public String getASVersionName(){
        return BuildConfig.VERSION_NAME;
    }


    //return 当前应用的版本号
    public int getVersion() {
        int versionCode = 1;
        try {
            PackageManager manager = getPackageManager();
            PackageInfo info = manager.getPackageInfo(this.getPackageName(), 0);
            versionCode = info.versionCode;

            if (versionCode < 1) {
                return 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("versionCode", "Exception", e);
        }
        return versionCode;
    }

    //显示进度框
    private ProgressDialog progDialog = null;//

    private void showProgressDialog(String str) {
        if (progDialog == null)
            progDialog = new ProgressDialog(this);
        progDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progDialog.setIndeterminate(false);
        progDialog.setCancelable(true);
        progDialog.setMessage(str);
        progDialog.show();
    }

    //隐藏进度框
    private void dissmissProgressDialog() {
        if (progDialog != null) {
            progDialog.dismiss();
        }
    }




    @Override
    public void onUpdateSuccess(UpdateBean bean) {

        try {
            int version_num_yun = Integer.parseInt(bean.body.version_num.trim());

            Log.i("cccccc", "getVersion==" + getVersion());

            if (version_num_yun > getVersion()) {
//                new UpdateManager(this).checkUpdate(false,version_num_yun);
                showTipDialog(2, "提示", "APP有重大更新!请升级", bean.body.version_url);
            } else {
                if (SPTool.getBoolean(UpDateActivity.this, Constant.UserGetUpDate)) {
                    ToastUtil.show(this, "当前已是最新版本");
                }
                SPTool.putBoolean(UpDateActivity.this, Constant.UserGetUpDate, false);
            }
        } catch (Exception e) {
            ToastUtil.show(this, "当前已是最新版本!");
            Log.i("cccccc", "e==" + e);
        }
        dissmissProgressDialog();


    }

    @Override
    public void onUpdateError(Object err) {
        dissmissProgressDialog();
    }




    //提示对话框
    public Dialog dialog;
    public TextView btn_one;
    public TextView btn_right;


    public interface ClickSureListener {
        public void click();
    }

    private ClickSureListener clickSureListener;

    public void showTipDialog(int type, String titleStr, String contentStr, final String version_url) {
        if (dialog == null) {
            dialog = new AlertDialog.Builder(UpDateActivity.this).create();
        }

        LayoutInflater inflater = LayoutInflater.from(UpDateActivity.this);
        View view = (View) inflater.inflate(R.layout.dialog_base, null);
        TextView title = (TextView) view.findViewById(R.id.title);
        TextView content = (TextView) view.findViewById(R.id.content);
        btn_one = (TextView) view.findViewById(R.id.btn_one);
        LinearLayout layout = (LinearLayout) view
                .findViewById(R.id.bottom_layout);
        btn_right = (TextView) view.findViewById(R.id.btn_right);
        if (type == 1) {
            btn_one.setVisibility(View.VISIBLE);
            layout.setVisibility(View.GONE);
        } else if (type == 2) {
            btn_one.setVisibility(View.GONE);
            layout.setVisibility(View.VISIBLE);
        }
        btn_one.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });

        btn_right.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });
        title.setText(titleStr);
        content.setText(contentStr);

        view.findViewById(R.id.btn_left).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

        view.findViewById(R.id.btn_right).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //"http://ps.tupppai.com/wefun_v1.0.1.apk"
                        Uri uri = Uri.parse("http://" + version_url.trim());
                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent);
                        dialog.dismiss();
                    }
                });

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.show();
        dialog.getWindow().setContentView(view);
    }

    public static void start(Context mContext) {
        Intent intent = new Intent(mContext, UpDateActivity.class);
        mContext.startActivity(intent);
    }

}