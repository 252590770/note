package com.hnty.driver.autolist;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.hnty.driver.R;
import com.hnty.driver.activity.MyMessageActivity;
import com.hnty.driver.entity.PastOrderListBean;
import com.hnty.driver.entity.VoiceOrderByIdBean;
import com.hnty.driver.util.MyUtil;

import java.util.ArrayList;
import java.util.List;

public class MyMessageAdapter extends BaseAdapter implements View.OnClickListener {

    Context context;
    ArrayList<VoiceOrderByIdBean.BodyBean> list;
    Callback callback;

    //1  电话订单  2  手工建单  3  微信订单  4 微信跑腿订单  5微信代驾

    String [] types = {"电话订单","手工建单","微信订单","微信跑腿订单","5微信代驾"};
    String type = "";
    public MyMessageAdapter(Context context, ArrayList<VoiceOrderByIdBean.BodyBean> list,Callback  callback) {
        this.context = context;
        this.list = list;
        this.callback = callback;
    }

    public void refreshAdapter(ArrayList<VoiceOrderByIdBean.BodyBean> list){

        this.list.clear();
        this.list = list;
        notifyDataSetChanged();

    }

    public void addInfo(ArrayList<VoiceOrderByIdBean.BodyBean> list){

        this.list.addAll(list);
        notifyDataSetChanged();
    }


    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder = new ViewHolder();
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.my_message_adapter_item, null);
            holder.tvTel = (TextView) convertView.findViewById(R.id.tvTel);
            holder.tvTime = (TextView) convertView.findViewById(R.id.tvTime);
            holder.tvType = (TextView) convertView.findViewById(R.id.tvType);
            holder.tvPrice = (TextView) convertView.findViewById(R.id.tvPrice);
            holder.tvPosition = (TextView) convertView.findViewById(R.id.tvPosition);
            holder.scan = (ImageView) convertView.findViewById(R.id.iv_title_scan);
            holder.code = (ImageView) convertView.findViewById(R.id.iv_title_code);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }





        switch (list.get(position).order_type){

            case "1":
                type = types[0];
                break;
            case "2":
                type = types[1];
                break;
            case "3":
                type = types[2];
                break;
            case "4":
                type = types[3];
                break;
            case "5":
                type = types[4];
                break;
            default:
                type = "默认类型";
                break;
        }

        holder.tvType.setText("" + type );



        holder.tvTel.setText("乘客电话：" + list.get(position).voice_tell);
        holder.tvPosition.setText("乘客位置：" + list.get(position).voice_end);

        holder.tvTime.setText( MyUtil.dateFormat(list.get(position).oper_date, 1));

        holder.tvTel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                getTel(list.get(position).voice_tell);
                showTipDialog(2,"提示","打电话联系乘客？",list.get(position).voice_tell);

            }
        });
        holder.scan.setOnClickListener(this);
        holder.scan.setTag(position);
        holder.code.setOnClickListener(this);

        if( list.get(position).order_price.equals("")  ){
            holder.code.setBackgroundResource(R.drawable.iv_cede);
            holder.code.setClickable(true);
        }else {
            holder.code.setClickable(false);
            holder.code.setBackgroundResource(R.drawable.iv_cede_0);
            holder.tvPrice.setText("￥" + list.get(position).order_price );

        }
        holder.code.setTag(position);

        return convertView;
    }

    @Override
    public void onClick(View v) {
        callback.click(v);
    }

    class ViewHolder {
        TextView tvTel, tvTime,tvType,tvPrice,tvPosition;
        ImageView scan,code;
    }


    //////////////////打电话///////////////////
    void getTel( String tel ) {
        try {
            Intent call = new Intent(Intent.ACTION_DIAL);
            Uri data = Uri.parse("tel:" + tel);
            call.setData(data);
            context.startActivity(call);
        } catch (Exception e) {
        }
    }
    //////////////////打电话///////////////////


    public interface Callback {

        public void click(View v);

    }


    //提示对话框
    public Dialog dialog;
    public TextView btn_one;
    public TextView btn_right;



    public interface ClickSureListener {
        public void click();
    }

    private MyMessageActivity.ClickSureListener clickSureListener;

    public void showTipDialog(int type, String titleStr, String contentStr ,final String tell) {
        if (dialog == null) {
            dialog = new AlertDialog.Builder(context).create();
        }

        LayoutInflater inflater = LayoutInflater.from(context);
        View view = (View) inflater.inflate(R.layout.dialog_base, null);
        TextView title = (TextView) view.findViewById(R.id.title);
        TextView content = (TextView) view.findViewById(R.id.content);
        btn_one = (TextView) view.findViewById(R.id.btn_one);
        LinearLayout layout = (LinearLayout) view
                .findViewById(R.id.bottom_layout);
        btn_right = (TextView) view.findViewById(R.id.btn_right);
        if (type == 1) {
            btn_one.setVisibility(View.VISIBLE);
            layout.setVisibility(View.GONE);
        } else if (type == 2) {
            btn_one.setVisibility(View.GONE);
            layout.setVisibility(View.VISIBLE);
        }
        btn_one.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });

        btn_right.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });
        title.setText(titleStr);
        content.setText(contentStr);

        view.findViewById(R.id.btn_left).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

        view.findViewById(R.id.btn_right).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        getTel( tell);
                        dialog.dismiss();
                    }
                });

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.show();
        dialog.getWindow().setContentView(view);
    }



}
