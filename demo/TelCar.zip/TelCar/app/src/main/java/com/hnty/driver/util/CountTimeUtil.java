package com.hnty.driver.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CountTimeUtil {

    /*
    Date date = null;
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MMdd HH:mm:ss");
        try {
        date = format.parse("2017-1030 18:12:00");
    } catch (ParseException e) {
    }

    String  dataStr = CountDateUtil.getTimestampString(date);
    */


    //传入Date  返回明天今天昨天字符串
    public static Boolean getTimestamp(Date date) {

        String formatStr = null;
        Date now = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");//可以方便地修改日期格式
        SimpleDateFormat dateFormat2 = new SimpleDateFormat("HH");//可以方便地修改日期格式

        String nowStr = dateFormat.format(now);
        String dateStr = dateFormat.format(date);

        String dateHour = dateFormat2.format(date);
        int hour = Integer.parseInt(dateHour);

        Date now1 = null;
        Date date1 = null;
        try {
            now1 =  dateFormat.parse(nowStr);
            date1 = dateFormat.parse(dateStr);
        }catch (Exception e){


        }

        int sec1 = (int) (now1.getTime() / 1000); // 60*1000
        int sec2 = (int) (date1.getTime() / 1000);// 60*1000



        if(sec2-sec1<=1){//明天

            return true;
        }else  {
            return false;
        }

    }






}
