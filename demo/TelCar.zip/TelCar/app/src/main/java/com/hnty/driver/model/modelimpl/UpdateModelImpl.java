package com.hnty.driver.model.modelimpl;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.CodeParam;
import com.hnty.driver.entity.UpdateBean;
import com.hnty.driver.entity.UpdateParam;
import com.hnty.driver.inter.OnCodeListener;
import com.hnty.driver.inter.OnUpdateListener;
import com.hnty.driver.model.modelinter.CodeModel;
import com.hnty.driver.model.modelinter.UpdateModel;
import com.hnty.driver.util.NetworkUtil;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by L on 2018/1/12.
 */

public class UpdateModelImpl implements UpdateModel {

    @Override
    public void checkUpdate(UpdateParam param, final OnUpdateListener listener) {


        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            listener.onUpdateError(new Exception("没有网络o"));
            return;
        }

        MyApplication.getAPI().checkUpdate("getVersion")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<UpdateBean>(){
                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull UpdateBean updateBean) {
                        try {
                            listener.onUpdateSuccess(updateBean);
                        }catch (Exception e){
                            listener.onUpdateError(new Exception("数据错误"));
                        }
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        listener.onUpdateError(new Exception("数据错误"));
                    }

                    @Override
                    public void onComplete() {

                    }


                });


    }



}
