package com.hnty.driver.util;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.FragmentActivity;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;

import com.hnty.driver.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 
 * <p>
 * Title: Tools.java
 * </p>
 * <p>
 * Description: 工具类集
 * </p>
 * <p>
 * Copyright: Copyright (c) 2011
 * </p>
 * 
 * @version V1.0
 * @since JDK1.6
 * @CheckItem 自己填写
 */
public class Tools {
	/**
	 * String 工具类
	 * 
	 * @ClassName: StrTools
	 * @Description: TODO
	 * @date 2015年2月9日 下午1:40:16
	 * 
	 */
	public static class T_String {

		private final static Pattern emailer = Pattern
				.compile("^([a-z0-9A-Z]+[-|\\._]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$");

		/**
		 * String 是否为null
		 * 
		 * @Title: isNull
		 * @Description: TODO
		 * @param @param str
		 * @param @return
		 * @return boolean true==为空 false==不为空
		 * @throws
		 */
		public static boolean isNull(String string) {
			if (null == string || "".equals(string) || "null".equals(string)
					|| "NULL".equals(string) || "Null".equals(string)) {
				return true;
			} else {
				return false;
			}
		}

		/***
		 * 验证密码(6-20)
		 * 
		 * @Title: verifyPwd
		 * @Description: TODO
		 * @param @param pwd
		 * @param @return
		 * @return boolean
		 * @throws
		 */
		public static boolean verifyPwd(String pwd) {
			if (null == pwd || "".equals(pwd) || pwd.length() < 6
					|| pwd.length() > 20) {
				return true;
			} else {
				return false;
			}
		}

		/***
		 * 验证密码(6-16)
		 * 
		 * @Title: verifyPwd
		 * @Description: TODO
		 * @param @param pwd
		 * @param @return
		 * @return boolean
		 * @throws
		 */
		public static boolean verifyPwd16(String pwd) {
			if (null == pwd || "".equals(pwd) || pwd.length() < 6
					|| pwd.length() > 16) {
				return true;
			} else {
				return false;
			}
		}

		/***
		 * 验证密码(6-8)
		 * 
		 * @Title: verifyPwd
		 * @Description: TODO
		 * @param @param pwd
		 * @param @return
		 * @return boolean
		 * @throws
		 */
		public static boolean verifyPwd6_8(String pwd) {
			if (null == pwd || "".equals(pwd) || pwd.length() < 6
					|| pwd.length() > 8) {
				return true;
			} else {
				return false;
			}
		}

		/***
		 * 确认 验证密码(6-20)
		 * 
		 * @Title: verifyPwd
		 * @Description: TODO
		 * @param @param pwd
		 * @param @return
		 * @return boolean
		 * @throws
		 */
		public static boolean verifyPwd(String pwd, String confirmPwd) {
			if (null == confirmPwd || "".equals(confirmPwd)
					|| confirmPwd.length() < 6 || confirmPwd.length() > 20
					|| !confirmPwd.equals(pwd)) {
				return true;
			} else {
				return false;
			}
		}

		/***
		 * 确认 验证密码(6-20)
		 * 
		 * @Title: verifyPwd
		 * @Description: TODO
		 * @param @param pwd
		 * @param @return
		 * @return boolean
		 * @throws
		 */
		public static boolean verifyPwd6_8(String pwd, String confirmPwd) {
			if (null == confirmPwd || "".equals(confirmPwd)
					|| confirmPwd.length() < 6 || confirmPwd.length() > 8
					|| !confirmPwd.equals(pwd)) {
				return true;
			} else {
				return false;
			}
		}

		/**
		 * 手机号
		 * 
		 * @Title: IsHandset
		 * @Description: TODO
		 * @param @param str
		 * @param @return
		 * @return boolean
		 * @throws
		 */
		public static boolean isPhoneNum(String str) {
			if (TextUtils.isEmpty(str)) {
				return false;
			} else {
				String regex = "^(13|15|18|14|17)[0-9]\\d{8}$";
				return match(regex, str);
			}
		}

		public static boolean isPersonID(String str) {
			if (TextUtils.isEmpty(str)) {
				return false;
			} else {
				String regex = "^[1-9]\\d{5}[1-9]\\d{3}((0\\d)|(1[0-2]))(([0|1|2]\\d)|3[0-1])\\d{3}([0-9]|X|x)$";
				return match(regex, str);
			}
		}

		/**
		 * @param str
		 * @return验证是否是邮箱
		 */
		public static boolean isEmailNum(String str) {
			if (TextUtils.isEmpty(str)) {
				return false;
			} else {
				String regex = "(?=^[\\w.@]{6,50}$)\\w+@\\w+(?:\\.[\\w]{2,3}){1,2}";
				return match(regex, str);
			}
		}

		/**
		 * 
		 * Description: 校验字符串只能是数字,英文字母和中文
		 * 
		 * @param s
		 * @return
		 */
		public static boolean isValidString(String s) {
			Pattern p = Pattern.compile("^[\u4E00-\u9FA50-9a-zA-Z_-]{0,}$");
			Matcher m = p.matcher(s);
			return m.matches();
		}

		/**
		 * 数字或字母
		 * 
		 * @Title: IsNumOrLetter
		 * @Description: TODO
		 * @param @param str
		 * @param @return
		 * @return boolean
		 * @throws
		 */
		public static boolean isNumOrLetter(String str) {
			if (TextUtils.isEmpty(str)) {
				return false;
			} else {
				String regex = "^[A-Za-z0-9]{6}$";
				return match(regex, str);
			}
		}

		/**
		 * 判断是不是一个合法的电子邮件地址
		 * 
		 * @param email
		 * @return
		 */
		public static boolean isEmail(String email) {
			if (email == null || email.trim().length() == 0)
				return false;
			return emailer.matcher(email).matches();
		}

		/**
		 * 全数字
		 * 
		 * @Title: IsAllNum
		 * @Description: TODO
		 * @param @param username
		 * @param @return
		 * @return boolean
		 * @throws
		 */
		public static boolean IsAllNum(String str) {
			String regex = "\\d*";
			return match(regex, str);
		}

		/**
		 * 
		 * @Title: match
		 * @Description: TODO
		 * @param @param regex
		 * @param @param str
		 * @param @return
		 * @return boolean
		 * @throws
		 */
		private static boolean match(String regex, String str) {
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(str);
			return matcher.matches();
		}

		/**
		 * 转换为内存容量
		 * 
		 * @Title: prettyBytes
		 * @Description: TODO 如：21MB
		 * @param @param value
		 * @param @return
		 * @return String
		 * @throws
		 */
		public static String prettyBytes(long value) {
			String args[] = { "B", "KB", "MB", "GB", "TB" };
			StringBuilder sb = new StringBuilder();
			int i;
			if (value < 1024L) {
				sb.append(String.valueOf(value));
				i = 0;
			} else if (value < 1048576L) {
				sb.append(String.format("%.1f", value / 1024.0));
				i = 1;
			} else if (value < 1073741824L) {
				sb.append(String.format("%.2f", value / 1048576.0));
				i = 2;
			} else if (value < 1099511627776L) {
				sb.append(String.format("%.3f", value / 1073741824.0));
				i = 3;
			} else {
				sb.append(String.format("%.4f", value / 1099511627776.0));
				i = 4;
			}
			sb.append(' ');
			sb.append(args[i]);
			return sb.toString();
		}

		/**
		 * 字符转换为ISO-8859-1
		 * 
		 * @Title: Str2UTF8
		 * @Description: TODO
		 * @param @param str
		 * @param @return
		 * @return String
		 * @throws
		 */
		public static String Str2ISO(String str) {
			if (!isNull(str) && str.getBytes().length != str.length()) {
				try {
					return new String(str.getBytes(), "ISO-8859-1");
				} catch (UnsupportedEncodingException e) {
					throw new RuntimeException(
							"UnsupportedEncodingException occurred. ", e);
				}
			}
			return str;
		}

		/**
		 * 
		 * @Title: Str2ISO-8859-1
		 * @Description: TODO 如果失败 则返回默认值defultReturn
		 * @param @param str
		 * @param @param defultReturn
		 * @param @return
		 * @return String
		 * @throws
		 */
		public static String Str2ISO(String str, String defultReturn) {
			if (!isNull(str) && str.getBytes().length != str.length()) {
				try {
					return new String(str.getBytes(), "ISO-8859-1");
				} catch (UnsupportedEncodingException e) {
					throw new RuntimeException(
							"UnsupportedEncodingException occurred. ", e);
				}
			}
			return str;
		}

		/**
		 * 字符转换为GBK
		 * 
		 * @Title: Str2UTF8
		 * @Description: TODO
		 * @param @param str
		 * @param @return
		 * @return String
		 * @throws
		 */
		public static String Str2GBK(String str) {
			if (!isNull(str) && str.getBytes().length != str.length()) {
				try {
					return new String(str.getBytes(), "GBK");
				} catch (UnsupportedEncodingException e) {
					throw new RuntimeException(
							"UnsupportedEncodingException occurred. ", e);
				}
			}
			return str;
		}

		/**
		 * 
		 * @Title: Str2GBK
		 * @Description: TODO 如果失败 则返回默认值defultReturn
		 * @param @param str
		 * @param @param defultReturn
		 * @param @return
		 * @return String
		 * @throws
		 */
		public static String Str2GBK(String str, String defultReturn) {
			if (!isNull(str) && str.getBytes().length != str.length()) {
				try {
					return new String(str.getBytes(), "GBK");
				} catch (UnsupportedEncodingException e) {
					return defultReturn;
				}
			}
			return str;
		}

		/**
		 * 字符转换为UTF-8
		 * 
		 * @Title: Str2UTF8
		 * @Description: TODO
		 * @param @param str
		 * @param @return
		 * @return String
		 * @throws
		 */
		public static String Str2UTF8(String str) {
			if (!isNull(str) && str.getBytes().length != str.length()) {
				try {
					return new String(str.getBytes(), "UTF-8");
				} catch (UnsupportedEncodingException e) {
					throw new RuntimeException(
							"UnsupportedEncodingException occurred. ", e);
				}
			}
			return str;
		}

		/**
		 * 
		 * @Title: Str2UTF8
		 * @Description: TODO 如果失败 则返回默认值defultReturn
		 * @param @param str
		 * @param @param defultReturn
		 * @param @return
		 * @return String
		 * @throws
		 */
		public static String Str2UTF8(String str, String defultReturn) {
			if (!isNull(str) && str.getBytes().length != str.length()) {
				try {
					return new String(str.getBytes(), "UTF-8");
				} catch (UnsupportedEncodingException e) {
					return defultReturn;
				}
			}
			return str;
		}

		/**
		 * 判断给定字符串是否空白串。 空白串是指由空格、制表符、回车符、换行符组成的字符串 若输入字符串为null或空字符串，返回true
		 * 
		 * @param input
		 * @return boolean
		 */
		public static boolean isEmpty(String input) {
			if (input == null || "".equals(input))
				return true;

			for (int i = 0; i < input.length(); i++) {
				char c = input.charAt(i);
				if (c != ' ' && c != '\t' && c != '\r' && c != '\n') {
					return false;
				}
			}
			return true;
		}

		/**
		 * 计算并格式化doubles数值，保留两位有效数字
		 * 
		 * @param doubles
		 * @return 返回当前路程
		 */
		public static String formatDouble(Double doubles) {
			DecimalFormat format = new DecimalFormat("####.##");
			String distanceStr = format.format(doubles);
			return distanceStr.equals("0") ? "0.0" : distanceStr;
		}

	}

	/**
	 * 网络工具类
	 * 
	 * @ClassName: T_Network
	 * @Description: TODO
	 * @author lig
	 * @date 2015年2月9日 下午2:09:58
	 * 
	 */
	public static class T_Network {
		/**
		 * 检测手机是否开启GPRS网络,需要调用ConnectivityManager,TelephonyManager 服务.
		 * 
		 * @Title: checkGprsNetwork
		 * @Description: TODO
		 * @param @param context
		 * @param @return
		 * @return boolean
		 * @throws
		 */
		public static boolean checkGprsNetwork(Context context) {
			boolean has = false;
			ConnectivityManager connectivity = (ConnectivityManager) context
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			TelephonyManager mTelephony = (TelephonyManager) context
					.getSystemService(Context.TELEPHONY_SERVICE);
			NetworkInfo info = connectivity.getActiveNetworkInfo();
			int netType = info.getType();
			int netSubtype = info.getSubtype();
			if (netType == ConnectivityManager.TYPE_MOBILE
					&& netSubtype == TelephonyManager.NETWORK_TYPE_UMTS
					&& !mTelephony.isNetworkRoaming()) {
				has = info.isConnected();
			}
			return has;

		}

		/**
		 * 检测手机是否开启WIFI网络,需要调用ConnectivityManager服务.
		 * 
		 * @Title: checkWifiNetwork
		 * @Description: TODO
		 * @param @param context
		 * @param @return
		 * @return boolean
		 * @throws
		 */
		public static boolean checkWifiNetwork(Context context) {
			boolean has = false;
			ConnectivityManager connectivity = (ConnectivityManager) context
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			NetworkInfo info = connectivity.getActiveNetworkInfo();
			int netType = info.getType();
			int netSubtype = info.getSubtype();
			if (netType == ConnectivityManager.TYPE_WIFI) {
				has = info.isConnected();
			}
			return has;
		}

		/**
		 * 检测当前手机是否联网
		 * 
		 * @Title: isNetworkAvailable
		 * @Description: TODO
		 * @param @param context
		 * @param @return
		 * @return boolean
		 * @throws
		 */
		public static boolean isNetworkAvailable(Context context) {
			ConnectivityManager connectivity = (ConnectivityManager) context
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			if (connectivity == null) {
				return false;
			} else {
				NetworkInfo[] info = connectivity.getAllNetworkInfo();
				if (info != null) {
					for (int i = 0; i < info.length; i++) {
						if (info[i].getState() == NetworkInfo.State.CONNECTED) {
							return true;
						}
					}
				}
			}
			return false;
		}

		/**
		 * 手机是否处在漫游
		 * 
		 * @Title: isNetworkRoaming
		 * @Description: TODO
		 * @param @param mCm
		 * @param @return
		 * @return boolean
		 * @throws
		 */
		public static boolean isNetworkRoaming(Context c) {
			ConnectivityManager connectivity = (ConnectivityManager) c
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			if (connectivity == null) {
				return false;
			}
			NetworkInfo info = connectivity.getActiveNetworkInfo();
			boolean isMobile = (info != null && info.getType() == ConnectivityManager.TYPE_MOBILE);
			TelephonyManager mTm = (TelephonyManager) c
					.getSystemService(Context.TELEPHONY_SERVICE);
			boolean isRoaming = isMobile && mTm.isNetworkRoaming();
			return isRoaming;
		}

		/**
		 * 
		 * Description: 检测网络状态并友好提示
		 * 
		 * @param pContext
		 * @return
		 */
		public static boolean showNetworkState(Context pContext) {
			if (!isNetworkAvailable(pContext)) {
				ToastUtil.show(pContext, pContext.getString(R.string.net_no));
				return false;
			}
			return true;
		}
	}

	/**
	 * Json工具类
	 * 
	 * @ClassName: T_Json
	 * @Description: TODO 可用于解析Json
	 * @author lig
	 * @date 2015年2月9日 下午2:28:04
	 * 
	 */
	public static class T_Json {

		private static Map<Class<?>, ArrayList<fieldEntity>> method_map = new HashMap<Class<?>, ArrayList<fieldEntity>>();

		/**
		 * json字符串转换为bean
		 * 
		 * @Title: JsonToBean
		 * @Description: TODO
		 * @param @param clazz
		 * @param @param json
		 * @param @return
		 * @return T
		 * @throws
		 */
		@SuppressWarnings("unchecked")
		public static <T> T Json2Bean(Class<?> clazz, String json) {
			getMethod(clazz);
			T object = null;
			try {
				object = (T) Json2Bean(json, clazz.newInstance());
			} catch (Exception e) {
			}
			return object;
		}

		/**
		 * Json字符串转化为集合
		 * 
		 * @Title: JsonToCollection
		 * @Description: TODO
		 * @param @param str
		 * @param @return
		 * @return T
		 * @throws
		 */
		@SuppressWarnings("unchecked")
		public static <T> T JsonToCollection(String str) {
			T object = null;
			try {
				object = (T) Json2HashMap(str);
			} catch (Exception e) {
			}
			return object;
		}

		/**
		 * Json字符串转化为集合
		 * 
		 * @Title: Json2HashMap
		 * @Description: TODO
		 * @param @param str
		 * @param @return
		 * @return Object
		 * @throws
		 */
		private static Object Json2HashMap(String str) {
			LinkedHashMap<String, Object> json = new LinkedHashMap<String, Object>();
			try {
				Object object = new JSONTokener(str).nextValue();
				if (object instanceof JSONArray) {
					JSONArray root = new JSONArray(str);
					ArrayList<Object> list = new ArrayList<Object>();
					if (root.length() > 0) {
						for (int i = 0; i < root.length(); i++) {
							list.add(JsonToCollection(root.getString(i)));
						}
						return list;
					}
					return list.add(str);
				} else if (object instanceof JSONObject) {
					JSONObject root = new JSONObject(str);
					if (root.length() > 0) {
						@SuppressWarnings("unchecked")
                        Iterator<String> rootName = root.keys();
						String name;
						while (rootName.hasNext()) {
							name = rootName.next();
							json.put(name,
									JsonToCollection(root.getString(name)));
						}
					}
					return json;
				} else {
					return str;
				}
			} catch (JSONException e) {
				T_Log.d("错误字符串：" + str);
				return str;
			}
		}

		/**
		 * Json转为对象
		 * 
		 * @Title: Json2Bean
		 * @Description: TODO
		 * @param @param str
		 * @param @param entity
		 * @param @return
		 * @return Object
		 * @throws
		 */
		@SuppressWarnings({ "unchecked", "rawtypes" })
		private static Object Json2Bean(String str, Object entity) {
			try {
				Object object = new JSONTokener(str).nextValue();
				if (object instanceof JSONArray) {
					JSONArray root = new JSONArray(str);
					if (root.length() > 0) {
						ArrayList<Object> list = new ArrayList<Object>();
						for (int i = 0; i < root.length(); i++) {
							Object value = new JSONTokener(root.getString(i))
									.nextValue();
							if (classes.contains(value.getClass())) {
								list.add(root.getString(i));
							} else {
								list.add(Json2Bean(root.getString(i), entity
										.getClass().newInstance()));
							}
						}
						return list;
					}
					T_Log.e("数组" + entity + "解析出错");
					return null;
				} else if (object instanceof JSONObject) {
					JSONObject root = new JSONObject(str);
					if (root.length() > 0) {
						Iterator<String> rootName = root.keys();
						String name;
						while (rootName.hasNext()) {
							name = rootName.next();
							boolean isHas = false;
							Class template = entity.getClass();
							while (template != null
									&& !classes.contains(template)) {
								ArrayList<fieldEntity> arrayList = method_map
										.get(template);
								for (fieldEntity fieldEntity : arrayList) {
									fieldEntity.field.setAccessible(true);
									Object obj = null;
									if (name.equals(fieldEntity.field.getName())) {
										isHas = true;
										if (fieldEntity.clazz == null) {
											Class clazz = fieldEntity.field
													.getType();
											if (clazz == String.class) {
												obj = root.getString(name);
											}
											if (clazz == int.class) {
												obj = root.getInt(name);
											}
											if (clazz == boolean.class) {
												obj = root.getBoolean(name);
											}
										} else {
											Object obj2 = new JSONTokener(
													root.getString(name))
													.nextValue();
											Class value_class = fieldEntity.field
													.getType();
											if (classes.contains(value_class)) {
												JSONArray array = (JSONArray) obj2;
												ArrayList<Object> list = new ArrayList<Object>();
												for (int i = 0; i < array
														.length(); i++) {
													if (fieldEntity.clazz == String.class) {
														obj = array.get(i)
																.toString();
													}
													if (fieldEntity.clazz == int.class) {
														obj = Integer
																.valueOf(array
																		.get(i)
																		.toString());
													}
													if (fieldEntity.clazz == boolean.class) {
														obj = Boolean
																.valueOf(array
																		.get(i)
																		.toString());
													}
													list.add(obj);
												}
												obj = list;
											} else {
												try {
													obj = Json2Bean(
															root.getString(name),
															fieldEntity.clazz
																	.newInstance());
												} catch (Exception e) {
													e.printStackTrace();
												}
											}
										}
										try {
											fieldEntity.field.set(entity, obj);
										} catch (Exception e) {
											e.printStackTrace();
										}
									}
								}
								template = template.getSuperclass();
							}

							if (!isHas) {
								T_Log.e("字段" + name + "在实体类" + entity + "不存在");
							}
						}
					} else {
						T_Log.e("数据长度不对 解析出错");
					}
					return entity;
				} else {
					return entity;
				}
			} catch (Exception e) {
				T_Log.d("错误字符串：" + str);
				return entity;
			}
		}

		@SuppressWarnings({ "rawtypes", "serial" })
		static HashSet<Class> classes = new HashSet<Class>() {
			{
				add(Object.class);
				add(Double.class);
				add(Float.class);
				add(Integer.class);
				add(Long.class);
				add(String.class);
				add(int.class);
				add(boolean.class);
			}
		};

		private static void getMethod(Class<?> clazz) {

			Class<?> template = clazz;
			while (template != null && template != Object.class) {
				if (method_map.get(template) != null
						&& method_map.get(template).size() > 0) {
					return;
				}
				template = template.getSuperclass();
			}
			template = clazz;
			while (template != null && !classes.contains(template)) {
				// -----------------------------------解析变量------------------------------------------------
				ArrayList<fieldEntity> entities = new ArrayList<fieldEntity>();
				for (Field m : template.getDeclaredFields()) {
					Type type = m.getGenericType();
					int modifiers = m.getModifiers();
					if (Modifier.isStatic(modifiers)) {
						continue;
					}
					if (type instanceof ParameterizedType) {
						Type[] types = ((ParameterizedType) type)
								.getActualTypeArguments();
						for (Type type2 : types) {
							if (!classes.contains(m.getType())) {
								getMethod((Class<?>) type2);
								entities.add(new fieldEntity(m,
										(Class<?>) type2));
							} else {
								entities.add(new fieldEntity(m, null));
							}
							break;
						}
						continue;
					}
					if (!classes.contains(m.getType())) {
						getMethod((Class<?>) type);
						entities.add(new fieldEntity(m, (Class<?>) type));
					} else {
						entities.add(new fieldEntity(m, null));
					}
				}
				method_map.put(template, entities);
				// -----------------------------------解析完毕------------------------------------------------
				template = template.getSuperclass();
			}
		}

		/**
		 * 解析内部类
		 * 
		 * @ClassName: fieldEntity
		 * @Description: TODO
		 * @date 2015年2月9日 下午2:24:16
		 * 
		 */
		public static class fieldEntity {
			public Field field;
			public Class<?> clazz;

			public fieldEntity(Field field, Class<?> clazz) {
				this.field = field;
				this.clazz = clazz;
			}

			@Override
			public String toString() {
				return "fieldEntity [field=" + field.getName() + ", clazz="
						+ clazz + "]";
			}

		}
	}

	/**
	 * 日志工具类
	 * 
	 * @ClassName: T_Log
	 * @Description: TODO
	 * @author lig
	 * @date 2015年2月9日 下午2:21:50
	 * 
	 */
	public static class T_Log {
		public static boolean isDebug = true;// 是否需要打印bug，可以在application的onCreate函数里面初始化
		private static final String TAG = "Tools_DeBug";

		/**
		 * Log.i
		 * 
		 * @Title: i
		 * @Description: TODO
		 * @param @param msg
		 * @return void
		 * @throws
		 */
		public static void i(String msg) {
			if (isDebug)
				Log.i(TAG, msg);
		}

		/**
		 * Log.d
		 * 
		 * @Title: d
		 * @Description: TODO
		 * @param @param msg
		 * @return void
		 * @throws
		 */
		public static void d(String msg) {
			if (isDebug)
				Log.d(TAG, msg);
		}

		/**
		 * Log.e
		 * 
		 * @Title: e
		 * @Description: TODO
		 * @param @param msg
		 * @return void
		 * @throws
		 */
		public static void e(String msg) {
			if (isDebug)
				Log.e(TAG, msg);
		}

		/**
		 * Log.v
		 * 
		 * @Title: v
		 * @Description: TODO
		 * @param @param msg
		 * @return void
		 * @throws
		 */
		public static void v(String msg) {
			if (isDebug)
				Log.v(TAG, msg);
		}

		/**
		 * Log.i
		 * 
		 * @Title: i
		 * @Description: TODO
		 * @param @param tag
		 * @param @param msg
		 * @return void
		 * @throws
		 */
		public static void i(String tag, String msg) {
			if (isDebug)
				Log.i(tag, msg);
		}

		/**
		 * Log.d
		 * 
		 * @Title: d
		 * @Description: TODO
		 * @param @param tag
		 * @param @param msg
		 * @return void
		 * @throws
		 */
		public static void d(String tag, String msg) {
			if (isDebug)
				Log.d(tag, msg);
		}

		/**
		 * Log.e
		 * 
		 * @Title: e
		 * @Description: TODO
		 * @param @param tag
		 * @param @param msg
		 * @return void
		 * @throws
		 */
		public static void e(String tag, String msg) {
			if (isDebug)
				Log.e(tag, msg);
		}

		/**
		 * Log.v
		 * 
		 * @Title: v
		 * @Description: TODO
		 * @param @param tag
		 * @param @param msg
		 * @return void
		 * @throws
		 */
		public static void v(String tag, String msg) {
			if (isDebug)
				Log.v(tag, msg);
		}
	}

	/**
	 * 时间日期工具类
	 * 
	 * @ClassName: T_Date
	 * @Description: TODO
	 * @author lig
	 * @date 2015年2月10日 上午9:42:09
	 * 
	 */
	public static class T_Date {
		public final static String FORMAT_DATE = "yyyy-MM-dd";
		public final static String FORMAT_TIME = "hh:mm";
		public final static String FORMAT_DATE_TIME = "yyyy-MM-dd hh:mm";
		public final static String FORMAT_MONTH_DAY_TIME = "MM月dd日 hh:mm";
		private static SimpleDateFormat sdf = new SimpleDateFormat();
		private static final int YEAR = 365 * 24 * 60 * 60;// 年
		private static final int MONTH = 30 * 24 * 60 * 60;// 月
		private static final int DAY = 24 * 60 * 60;// 天
		private static final int HOUR = 60 * 60;// 小时
		private static final int MINUTE = 60;// 分钟
		public static final String[] zodiacArr = { "猴", "鸡", "狗", "猪", "鼠",
				"牛", "虎", "兔", "龙", "蛇", "马", "羊" };

		/**
		 * 根据日期获取生肖
		 * 
		 * @Title: date2Zodica
		 * @Description: TODO
		 * @param @param time
		 * @param @return
		 * @return String
		 * @throws
		 */
		public static String date2Zodica(Calendar time) {
			return zodiacArr[time.get(Calendar.YEAR) % 12];
		}

		/**
		 * 根据生日获取星座
		 * 
		 * @Title: getAstro
		 * @Description: TODO
		 * @param @param birth
		 * @param @return
		 * @return String
		 * @throws
		 */
		public static String getAstro(String birth) {
			if (!isDate(birth)) {
				birth = "2000" + birth;
			}
			if (!isDate(birth)) {
				return "";
			}
			int month = Integer.parseInt(birth.substring(
					birth.indexOf("-") + 1, birth.lastIndexOf("-")));
			int day = Integer
					.parseInt(birth.substring(birth.lastIndexOf("-") + 1));
			String s = "魔羯水瓶双鱼牡羊金牛双子巨蟹狮子处女天秤天蝎射手魔羯";
			int[] arr = { 20, 19, 21, 21, 21, 22, 23, 23, 23, 23, 22, 22 };
			int start = month * 2 - (day < arr[month - 1] ? 2 : 0);
			return s.substring(start, start + 2) + "座";
		}

		/**
		 * 判断日期是否有效,包括闰年的情况
		 * 
		 * @Title: isDate
		 * @Description: TODO
		 * @param @param date
		 * @param @return
		 * @return boolean
		 * @throws
		 */
		public static boolean isDate(String date) {
			StringBuffer reg = new StringBuffer(
					"^((\\d{2}(([02468][048])|([13579][26]))-?((((0?");
			reg.append("[13578])|(1[02]))-?((0?[1-9])|([1-2][0-9])|(3[01])))");
			reg.append("|(((0?[469])|(11))-?((0?[1-9])|([1-2][0-9])|(30)))|");
			reg.append("(0?2-?((0?[1-9])|([1-2][0-9])))))|(\\d{2}(([02468][12");
			reg.append("35679])|([13579][01345789]))-?((((0?[13578])|(1[02]))");
			reg.append("-?((0?[1-9])|([1-2][0-9])|(3[01])))|(((0?[469])|(11))");
			reg.append("-?((0?[1-9])|([1-2][0-9])|(30)))|(0?2-?((0?[");
			reg.append("1-9])|(1[0-9])|(2[0-8]))))))");
			Pattern p = Pattern.compile(reg.toString());
			return p.matcher(date).matches();
		}

		/**
		 * 根据时间戳获取描述性时间
		 * 
		 * @Title: getDescriptionTimeFromTimestamp
		 * @Description: TODO 如3分钟前，1天前
		 * @param @param timestamp 时间戳 单位为毫秒
		 * @param @return
		 * @return String 时间字符串
		 * @throws
		 */
		public static String getDescriptionTimeFromTimestamp(long timestamp) {
			long currentTime = System.currentTimeMillis();
			long timeGap = (currentTime - timestamp) / 1000;// 与现在时间相差秒数
			System.out.println("timeGap: " + timeGap);
			String timeStr = null;
			if (timeGap > YEAR) {
				timeStr = timeGap / YEAR + "年前";
			} else if (timeGap > MONTH) {
				timeStr = timeGap / MONTH + "个月前";
			} else if (timeGap > DAY) {// 1天以上
				timeStr = timeGap / DAY + "天前";
			} else if (timeGap > HOUR) {// 1小时-24小时
				timeStr = timeGap / HOUR + "小时前";
			} else if (timeGap > MINUTE) {// 1分钟-59分钟
				timeStr = timeGap / MINUTE + "分钟前";
			} else {// 1秒钟-59秒钟
				timeStr = "刚刚";
			}
			return timeStr;
		}

		/**
		 * 距离截止日期还有多长时间
		 * 
		 * @Title: fromDeadline
		 * @Description: TODO
		 * @param @param date 截至日期
		 * @param @return
		 * @return String
		 * @throws
		 */
		public static String fromDeadline(Date date) {
			long deadline = date.getTime() / 1000;
			long now = (new Date().getTime()) / 1000;
			long remain = deadline - now;
			if (remain <= HOUR)
				return "只剩下" + remain / MINUTE + "分钟";
			else if (remain <= DAY)
				return "只剩下" + remain / HOUR + "小时" + (remain % HOUR / MINUTE)
						+ "分钟";
			else {
				long day = remain / DAY;
				long hour = remain % DAY / HOUR;
				long minute = remain % DAY % HOUR / MINUTE;
				return "只剩下" + day + "天" + hour + "小时" + minute + "分钟";
			}

		}

		/**
		 * 根据时间戳获取指定格式的时间
		 * 
		 * @Title: getFormatTimeFromTimestamp
		 * @Description: TODO 如2011-11-30 08:40
		 * @param @param timestamp 时间戳 单位为毫秒
		 * @param @param format 指定格式 如果为null或空串则使用默认格式"yyyy-MM-dd HH:MM"
		 * @param @return
		 * @return String 时间字符串
		 * @throws
		 */
		public static String getFormatTimeFromTimestamp(long timestamp,
                                                        String format) {
			if (format == null || format.trim().equals("")) {
				sdf.applyPattern(FORMAT_DATE);
				int currentYear = Calendar.getInstance().get(Calendar.YEAR);
				int year = Integer.valueOf(sdf.format(new Date(timestamp))
						.substring(0, 4));
				System.out.println("currentYear: " + currentYear);
				System.out.println("year: " + year);
				if (currentYear == year) {// 如果为今年则不显示年份
					sdf.applyPattern(FORMAT_MONTH_DAY_TIME);
				} else {
					sdf.applyPattern(FORMAT_DATE_TIME);
				}
			} else {
				sdf.applyPattern(format);
			}
			Date date = new Date(timestamp);
			return sdf.format(date);
		}

		/**
		 * 根据时间戳获取时间字符串，并根据指定的时间分割数partionSeconds来自动判断返回描述性时间还是指定格式的时间
		 * 
		 * @Title: getMixTimeFromTimestamp
		 * @Description: TODO
		 * @param @param timestamp 时间戳 单位是毫秒
		 * @param @param partionSeconds
		 *        时间分割线，当现在时间与指定的时间戳的秒数差大于这个分割线时则返回指定格式时间，否则返回描述性时间
		 * @param @param format
		 * @param @return
		 * @return String
		 * @throws
		 */
		public static String getMixTimeFromTimestamp(long timestamp,
                                                     long partionSeconds, String format) {
			long currentTime = System.currentTimeMillis();
			long timeGap = (currentTime - timestamp) / 1000;// 与现在时间相差秒数
			if (timeGap <= partionSeconds) {
				return getDescriptionTimeFromTimestamp(timestamp);
			} else {
				return getFormatTimeFromTimestamp(timestamp, format);
			}
		}

		/**
		 * 获取当前日期的指定格式的字符串
		 * 
		 * @Title: getCurrentTime
		 * @Description: TODO
		 * @param @param format 指定的日期时间格式，若为null或""则使用指定的格式"yyyy-MM-dd HH:MM"
		 * @param @return
		 * @return String
		 * @throws
		 */
		public static String getCurrentTime(String format) {
			if (format == null || format.trim().equals("")) {
				sdf.applyPattern(FORMAT_DATE_TIME);
			} else {
				sdf.applyPattern(format);
			}
			return sdf.format(new Date());
		}

		/**
		 * 将日期字符串以指定格式转换为Date
		 * 
		 * @Title: getTimeFromString
		 * @Description: TODO
		 * @param @param timeStr 日期字符串
		 * @param @param format 指定的日期格式，若为null或""则使用指定的格式"yyyy-MM-dd HH:MM"
		 * @param @return
		 * @return Date
		 * @throws
		 */
		public static Date getTimeFromString(String timeStr, String format) {
			if (format == null || format.trim().equals("")) {
				sdf.applyPattern(FORMAT_DATE_TIME);
			} else {
				sdf.applyPattern(format);
			}
			try {
				return sdf.parse(timeStr);
			} catch (ParseException e) {
				return new Date();
			}
		}

		/**
		 * 将Date以指定格式转换为日期时间字符串
		 * 
		 * @Title: getStringFromTime
		 * @Description: TODO
		 * @param @param time 日期
		 * @param @param format 指定的日期时间格式，若为null或""则使用指定的格式"yyyy-MM-dd HH:MM"
		 * @param @return
		 * @return String
		 * @throws
		 */
		public static String getStringFromTime(Date time, String format) {
			if (format == null || format.trim().equals("")) {
				sdf.applyPattern(FORMAT_DATE_TIME);
			} else {
				sdf.applyPattern(format);
			}
			return sdf.format(time);
		}

		/**
		 * 
		 * Description: 例如：获得当前时间之后40分钟后及后面每个15分钟的所有时间（但截至到20:30）
		 * 
		 * @param endTime
		 *            当天截至时间 如"2030"
		 * @param afterTime
		 *            当前时间多少分钟后开始计算 如40表示40分钟
		 * @param spaceTime
		 *            每次计算的间隔 如： 如15表示15分钟
		 * @throws Throwable
		 */
		public static List<String> getTimeFrag(String endTime, int afterTime,
                                               int spaceTime) {

			List<String> list = new ArrayList<String>();
			// 分别获得
			try {
				Calendar c = Calendar.getInstance();
				int year = c.get(Calendar.YEAR);
				int month = c.get(Calendar.MONTH) + 1;// 从0开始计算的
				int day = c.get(Calendar.DAY_OF_MONTH);
				int hour = c.get(Calendar.HOUR_OF_DAY);
				int minute = c.get(Calendar.MINUTE);

				SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat(
						"yyyyMMddHHmm");
				String mTime = mSimpleDateFormat.format(new Date());

				Date now = mSimpleDateFormat.parse(mTime);
				String timeStr = year + "0" + month + "" + day + endTime;
				Date date = mSimpleDateFormat.parse(timeStr);
				long l = date.getTime() - now.getTime();
				long apartDay = l / (24 * 60 * 60 * 1000);
				long apartHour = (l / (60 * 60 * 1000) - apartDay * 24);
				long apartMin = ((l / (60 * 1000)) - apartDay * 24 * 60 - apartHour * 60);
				long s = (l / 1000 - apartDay * 24 * 60 * 60 - apartHour * 60
						* 60 - apartMin * 60);
				System.out.println("相距" + apartDay + "天" + apartHour + "小时"
						+ apartMin + "分" + s + "秒");
				// 从小时得到的条数
				int timeFragSum = (int) (apartHour * (int) Math
						.round(60 / spaceTime));
				// 从分钟里获得条数
				int haveSum = (int) Math.round(apartMin / spaceTime);
				// 剩下不足15分钟的时间数
				// int remainMin = Math.round(apartMin % spaceTime);
				int sum = timeFragSum + haveSum
						- (int) Math.round(afterTime / spaceTime);// 40分钟之后时间,约3次

				String mHour = null;
				String mMinute = null;
				if (hour < 20) {
					int laterTime = minute + afterTime;
					for (int i = 0; i < sum; i++) {
						if (i != 0) {
							laterTime = spaceTime + laterTime;
						}
						if (laterTime > 60) {// 小时进1位
							int addHour = (int) Math.round(laterTime / 60);
							// 剩下不足15分钟的时间数
							int addMin = Math.round(laterTime % 60);
							hour = hour + addHour;
							laterTime = addMin;
						}
						if (hour < 10) {
							mHour = "0" + hour;
						} else {
							mHour = "" + hour;
						}

						if (laterTime < 10) {
							mMinute = "0" + laterTime;
						} else {
							mMinute = "" + laterTime;
						}
						String object = mHour + ":" + mMinute;
						list.add(object);
					}
				}
			} catch (ParseException e) {
				e.printStackTrace();
			}
			return list;
		}

		/**
		 * 将一个时间变成一个友好的计时格式
		 *
		 * @param time
		 *            时间 毫秒
		 * @return 时：分：秒：毫秒
		 */
		public static String getFormatTime(long time) {
			time = time / 1000;
			long second = time % 60;
			long minute = (time % 3600) / 60;
			long hour = time / 3600;

			// 毫秒秒显示两位
			// String strMillisecond = "" + (millisecond / 10);
			// 秒显示两位
			String strSecond = ("00" + second).substring(("00" + second)
					.length() - 2);
			// 分显示两位
			String strMinute = ("00" + minute).substring(("00" + minute)
					.length() - 2);
			// 时显示两位
			String strHour = ("00" + hour)
					.substring(("00" + hour).length() - 2);

			return strHour + ":" + strMinute + ":" + strSecond;
			// + strMillisecond;
		}

	}

	/**
	 * Android大小单位转换工具类
	 *
	 * @ClassName: T_Display
	 * @Description: TODO
	 * @author lig
	 *
	 */
	public static class T_Display {
		/**
		 * 将px值转换为dip或dp值，保证尺寸大小不变
		 *
		 * @param pxValue
		 * @param scale
		 *            （DisplayMetrics类中属性density）
		 * @return
		 */
		public static int px2dip(float pxValue, float scale) {
			return (int) (pxValue / scale + 0.5f);
		}

		/**
		 * 将dip或dp值转换为px值，保证尺寸大小不变
		 *
		 * @param dipValue
		 * @param scale
		 *            （DisplayMetrics类中属性density）
		 * @return
		 */
		public static int dip2px(float dipValue, float scale) {
			return (int) (dipValue * scale + 0.5f);
		}

		/**
		 * 将px值转换为sp值，保证文字大小不变
		 *
		 * @param pxValue
		 * @param fontScale
		 *            （DisplayMetrics类中属性scaledDensity）
		 * @return
		 */
		public static int px2sp(float pxValue, float fontScale) {
			return (int) (pxValue / fontScale + 0.5f);
		}

		/**
		 * 将sp值转换为px值，保证文字大小不变
		 *
		 * @param spValue
		 * @param fontScale
		 *            （DisplayMetrics类中属性scaledDensity）
		 * @return
		 */
		public static int sp2px(float spValue, float fontScale) {
			return (int) (spValue * fontScale + 0.5f);
		}
	}

	/**
	 *
	 * <p>
	 * Title: Tools.java
	 * </p>
	 * <p>
	 * Description: 意图跳转
	 * </p>
	 * <p>
	 * Copyright: Copyright (c) 2011
	 * </p>
	 *
	 * @author 自己填写
	 * @version V1.0
	 * @since JDK1.6
	 * @CheckItem 自己填写
	 */
	public static class T_Intent {
		/**
		 * 启动页面跳转
		 *
		 * @param mContext
		 * @param cls
		 *            目的类
		 * @param data
		 *            传递数据 void
		 */
		public static void startActivity(Context mContext, Class<?> cls,
                                         Bundle data) {
			Intent intent = new Intent(mContext, cls);
			intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);

			if (data != null) {
				intent.putExtras(data);
			}

			mContext.startActivity(intent);
		}

		/**
		 * 启动页面跳转(有返回处理)
		 *
		 * @param
		 * @param cls
		 *            目的类
		 * @param data
		 *            传递数据
		 * @param requestCode
		 *            请求编码 void
		 */
		public static void startActivityForResult(Activity mActivity,
                                                  Class<?> cls, Bundle data, int requestCode) {
			Intent intent = new Intent(mActivity, cls);
			intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);

			if (data != null) {
				intent.putExtras(data);
			}
			// 这个方法，在Activity范围下，不再Context范围下
			mActivity.startActivityForResult(intent, requestCode);
		}

		/**
		 * 安装APK程序代码
		 *
		 * @param context
		 * @param apkPath
		 */
		public static void ApkInstall(Context context, String apkPath) {
			File fileAPK = new File(apkPath);
			if (fileAPK.exists()
					&& fileAPK.getName().toLowerCase().endsWith(".apk")) {
				Intent install = new Intent();
				install.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				install.setAction(Intent.ACTION_VIEW);
				install.setDataAndType(Uri.fromFile(fileAPK),
						"application/vnd.android.package-archive");
				context.startActivity(install);// 安装
			}
		}

		/**
		 * 去应用市场给软件评分
		 * 
		 * @Title: marketScore
		 * @Description: TODO
		 * @paramc
		 * @return void
		 * @throws
		 */
		public static void marketScore(Context context) {
			String uriStr = "market://details?id=" + context.getPackageName();
			Uri uri = Uri.parse(uriStr);
			Intent intent = new Intent(Intent.ACTION_VIEW, uri);
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(intent);
		}

		/**
		 * 分享文本到第三方软件
		 * 
		 * @Title: shareText
		 * @Description: TODO
		 * @param
		 * @param content
		 * @return void
		 * @throws
		 */
		public static void shareText(Context context, String content) {
			Intent sendIntent = new Intent();
			sendIntent.setAction(Intent.ACTION_SEND);
			sendIntent.setType("text/*");
			sendIntent.putExtra(Intent.EXTRA_TEXT, content);
			context.startActivity(sendIntent);
		}

		/**
		 * 打电话
		 * 
		 * @param
		 * @param content
		 */
		public static void tell(Context context, String content) {
			Intent intent = new Intent("android.intent.action.CALL",
					Uri.parse("tel:" + content));
			context.startActivity(intent);
		}

		// /**
		// *
		// * 打开相机
		// *
		// * @param context
		// */
		// public static void photograph(Activity context) {
		// long nowTime = System.currentTimeMillis();
		// Constant.KEY_CAR_IMAGE = "/anji" + nowTime + ".jpg";
		// Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		// intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(
		// Environment.getExternalStorageDirectory().getPath(),
		// Constant.KEY_CAR_IMAGE)));
		// context.startActivityForResult(intent, RequestCode.PHOTOGRAPH);
		// }

		// /**
		// * 请求打开相册
		// *
		// * @param context
		// */
		// public static void openPhotos(Activity context) {
		//
		// Intent intent = new Intent(Intent.ACTION_PICK, null);
		// intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
		// "image/*");
		// context.startActivityForResult(intent, RequestCode.PHOTOS);// 返回结果
		// }
		//
		// /**
		// * 裁剪图片方法实现
		// *
		// * @param context
		// * @param uri
		// * 本地图片的uri
		// * @param w
		// * 裁剪后图片的宽度
		// * @param h
		// * 裁剪后图片的高度
		// */
		// public static void startPhotoZoom(Activity context, Uri uri, int w,
		// int h) {
		// DisplayMetrics dm = context.getResources().getDisplayMetrics();
		// Intent intent = new Intent("com.android.camera.action.CROP");
		// intent.setDataAndType(uri, "image/*");
		// intent.putExtra("crop", "true");
		// intent.putExtra("aspectX", 1);
		// intent.putExtra("aspectY", 1);
		// // TODO 剪切图片的大小
		// intent.putExtra("outputX", w);
		// intent.putExtra("outputY", h);
		// intent.putExtra("return-data", true);
		// context.startActivityForResult(intent, RequestCode.PHOTOZOOM);
		// }

		/**
		 * 
		 * Description: URI转变Path问题
		 * 
		 * @param context
		 * @param uri
		 *            本地图片的uri
		 * @param status
		 *            1表示来源是相册；2表示来源是拍照
		 * @return
		 */
		public static String uri2FilePath(Activity context, Uri uri, int status) {
			Cursor actualimagecursor = null;
			int actual_image_column_index = 0;
			if (status == 1) {
				/**
				 * 相册
				 */
				String[] proj = { MediaStore.Images.Media.DATA };
				actualimagecursor = context.managedQuery(uri, proj, null, null,
						null);
				actual_image_column_index = actualimagecursor
						.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
				actualimagecursor.moveToFirst();
				String img_path = actualimagecursor
						.getString(actual_image_column_index);
				return img_path;
			} else if (status == 2) {
				/**
				 * 拍照
				 */
				return uri.getPath();
			}
			return null;
		}

		public static void startActivity(Context mContext,
				FragmentActivity activity, Object data) {
			// TODO Auto-generated method stub

		}

	}

	public static String getRoundedPrice(double price) {
		BigDecimal decimal = new BigDecimal(price);
		BigDecimal rounded = decimal.setScale(2, BigDecimal.ROUND_HALF_UP);
		return rounded.toString();
	}

	/**
	 * getCurrVersionCode(这里用一句话描述这个方法的作用) (这里描述这个方法适用条件 – 可选)
	 * 
	 * @return int
	 * @exception
	 * @since 1.0.0
	 */
	public static int getCurrVersionCode(Context context) {
		int versionCode = 0;
		PackageManager manager = context.getPackageManager();
		try {
			PackageInfo info = manager.getPackageInfo(context.getPackageName(),
					0);
			versionCode = info.versionCode;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		return versionCode;
	}

	/**
	 * getCurrVersionName(这里用一句话描述这个方法的作用) (这里描述这个方法适用条件 – 可选)
	 * 
	 * @param context
	 * @return String
	 * @exception
	 * @since 1.0.0
	 */
	public static String getCurrVersionName(Context context) {
		String versionCode = "1.0.0";
		PackageManager manager = context.getPackageManager();
		try {
			PackageInfo info = manager.getPackageInfo(context.getPackageName(),
					0);
			versionCode = info.versionName;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		return versionCode;
	}




	/**
	 * 获取手机IMEI号
	 */
	public static String getIMEI(Context context) {
		TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(context.TELEPHONY_SERVICE);
		String imei = telephonyManager.getDeviceId();

		return imei;
	}

	/**
	 * 获取手机IMSI号
	 */
	public static String getIMSI(Context context){
		TelephonyManager mTelephonyMgr = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		String imsi = mTelephonyMgr.getSubscriberId();

		return imsi ;
	}



//	public   String getIMSI1( final Context context){
//
//		 String  imei;
//
//		performRequestPermissions(context,context.getString(R.string.permission_imei),
//				new String[]{
//						Manifest.permission.READ_PHONE_STATE,
//				}
//				, 0,
//				new PermissionResultListener() {
//					@Override
//					public void onPermissionDenied() {
//
//					}
//
//					@Override
//					public void onPermissionGranted() {
//
//						try {
//							TelephonyManager telmg = (TelephonyManager)
//									context.getSystemService(Context.TELEPHONY_SERVICE);
//							imei = telmg.getSubscriberId();
//
//
//
//						}catch (Exception E)
//						{
//							E.printStackTrace();
//						}
//
//					}
//				});
//
//
//		return imei;
//	}
//
//
//
//	protected  void performRequestPermissions(Context context,String desc, String[] permissions,
//											 int requestCode,
//											 PermissionResultListener listener) {
//		if (permissions == null || permissions.length == 0) {
//			return;
//		}
//		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//			if (checkEachSelfPermission(context,permissions)) {// 检查是否声明了权限
//				requestEachPermissions(context,desc, permissions, requestCode);
//			} else {// 已经申请权限
//				if (listener != null) {
//					listener.onPermissionGranted();
//				}
//			}
//		} else {
//			if (listener != null) {
//				listener.onPermissionGranted();
//			}
//		}
//	}
//
//
//	/**
//	 * 检察每个权限是否申请
//	 *
//	 * @param permissions
//	 * @return true 需要申请权限,false 已申请权限
//	 */
//	private boolean checkEachSelfPermission(Context context,String[] permissions) {
//		for (String permission : permissions) {
//			if (ContextCompat.checkSelfPermission(context, permission) !=
//					PackageManager.PERMISSION_GRANTED) {
//				return true;
//			}
//		}
//		return false;
//	}
//
//
//	/**
//	 * 申请权限前判断是否需要声明
//	 *
//	 * @param desc
//	 * @param permissions
//	 * @param requestCode
//	 */
//	private void requestEachPermissions(Context context,String desc, String[] permissions, int requestCode) {
//		if (shouldShowRequestPermissionRationale(context,permissions)) {// 需要再次声明
//			showRationaleDialog(context,desc, permissions, requestCode);
//		} else {
//			ActivityCompat.requestPermissions((Activity) context , permissions, requestCode);
//		}
//	}
//
//
//
//	/**
//	 * 再次申请权限时，是否需要声明
//	 *
//	 * @param permissions
//	 * @return
//	 */
//	private boolean shouldShowRequestPermissionRationale(Context context,String[] permissions) {
//		for (String permission : permissions) {
//			if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, permission)) {
//				return true;
//			}
//		}
//		return false;
//	}
//
//	/**
//	 * 弹出声明的 Dialog
//	 *
//	 * @param desc
//	 * @param permissions
//	 * @param requestCode
//	 */
//	private void showRationaleDialog(final Context context,String desc, final String[] permissions,
//									 final int requestCode) {
//		final AlertDialog.Builder builder = new AlertDialog.Builder(context);
//		builder.setTitle(context.getString(R.string.tips))
//				.setMessage(desc)
//				.setPositiveButton(context.getResources().getString(R.string.sure),
//						new DialogInterface.OnClickListener() {
//							@Override
//							public void onClick(DialogInterface dialogInterface, int i) {
//								ActivityCompat.requestPermissions((Activity) context,
//										permissions, requestCode);
//							}
//						})
//				.setNegativeButton(context.getResources().getString(R.string.cancel),
//						new DialogInterface.OnClickListener() {
//							@Override
//							public void onClick(DialogInterface dialogInterface, int i) {
//								dialogInterface.dismiss();
//							}
//						})
//				.setCancelable(false)
//				.show();
//	}



	/**
	 *判断当前应用程序处于前台还是后台
	 */
	public static boolean isApplicationBroughtToBackground(final Context context) {
		ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
		List<ActivityManager.RunningTaskInfo> tasks = am.getRunningTasks(1);
		if (!tasks.isEmpty()) {
			ComponentName topActivity = tasks.get(0).topActivity;
			if (!topActivity.getPackageName().equals(context.getPackageName())) {
				return true;
			}
		}
		return false;
	}


}
