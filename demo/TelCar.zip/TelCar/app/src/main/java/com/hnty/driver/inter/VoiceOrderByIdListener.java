package com.hnty.driver.inter;


import com.hnty.driver.entity.VoiceOrderByIdBean;

/**
 * Created by L on 2018/1/12.
 */

public interface VoiceOrderByIdListener {

    void onVoiceOrderByIdSuccess(VoiceOrderByIdBean bean);
    void onVoiceOrderByIdError(String err);

}
