package com.hnty.driver.entity;

import com.google.gson.Gson;


public class DriverRankBean {


   

    public String driver_permit;
    public String driver_name4;
    public int driver_balance;
    public String driver_name;
    public String order_state;
    public String driver_name2;
    public String driver_name3;
    public String driver_ismi;
    public String oper_date;
    public int driver_id1;
    public String driver_owner;
    public int driver_id0;
    public String driver_img;
    public String driver_pass;
    public String driver_name1;
    public int driver_id;
    public String driver_tell;
    public String car_no;
    public String round_card;
    public String driver_marks;
    public String out_state;
    public int driver_id4;
    public String driver_tell4;
    public String driver_state;
    public String car_no2;
    public String car_no3;
    public int driver_id2;
    public String car_no1;
    public int driver_id3;
    public String driver_tell1;
    public String driver_licence;
    public String driver_tell2;
    public String driver_tell3;
    public String driver_picture;
    public String comp_time;
    public String car_no4;

    @Override
    public String toString() {

        return new Gson().toJson(this);
    }

    
}
