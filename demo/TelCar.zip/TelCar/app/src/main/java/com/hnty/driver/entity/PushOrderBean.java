package com.hnty.driver.entity;

import com.google.gson.Gson;

import java.io.Serializable;

public class PushOrderBean implements Serializable{

    public int code;
    public String msg;
    public BodyBean body;


    public static class BodyBean implements Serializable{

    public String voice_end;//目的地解析结果
    public String voice_order;
    public String end_longitude;//目的地经度
    public String voice_name;//起始地录音文件名
    public String voice_lng;//起始地经度
    public String end_latitude;//目的地纬度
    public String end_name;//目的地录音文件名
    public String driver_name;
    public String voice_tell;//订单电话
    public String voice_file;//起始地解析结果
    public String voice_lat;//起始地纬度
    public String driver_latitude;//起始地纬度
    public String driver_longitude;//起始地纬度
    public String get_latitude;//起始地纬度
    public String get_longitude;//起始地纬度
    public String count;//起始地纬度
    public String oper_date;//下单时间
    public String voice_state;//
    public String order_type;//0  及时订单   1 预约订单

//        "driver_tell": "18700493859",
//                "driver_name": "你好",
//                "get_longitude": "108.9069890000",
//                "get_latitude": "34.1589290000",
//                "voice_order": "201803031045303674"


    }



    @Override
    public String toString() {

        return new Gson().toJson(this);
    }

}
