package com.hnty.driver.entity;

/**
 * Created by L on 2018/1/11.
 */

public class RegisterParam {
    public String method;
    public String carno;
    public String driver_name;
    public String driver_tell;
    public String driver_pass;
    public String driver_ismi;

    public RegisterParam() {
    }

    public RegisterParam(String method, String carno, String driver_name, String driver_tell, String driver_pass, String driver_ismi) {
        this.method = method;
        this.carno = carno;
        this.driver_name = driver_name;
        this.driver_tell = driver_tell;
        this.driver_pass = driver_pass;
        this.driver_ismi = driver_ismi;
    }
}
