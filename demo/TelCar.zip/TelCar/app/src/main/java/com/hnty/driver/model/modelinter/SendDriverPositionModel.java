package com.hnty.driver.model.modelinter;


import com.hnty.driver.entity.CodeParam;
import com.hnty.driver.entity.SendDriverPositionParam;
import com.hnty.driver.inter.OnCodeListener;
import com.hnty.driver.inter.OnSendDriverPositionListener;

/**
 * Created by L on 2018/1/12.
 */

public interface SendDriverPositionModel {

    void sendPosition(SendDriverPositionParam param, OnSendDriverPositionListener listener);

}
