package com.hnty.driver.model.modelimpl;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.CodeParam;
import com.hnty.driver.entity.DriverCancelBean;
import com.hnty.driver.entity.DriverCancelParam;
import com.hnty.driver.inter.OnCodeListener;
import com.hnty.driver.inter.OnDriverCancelListener;
import com.hnty.driver.model.modelinter.CodeModel;
import com.hnty.driver.model.modelinter.DriverCancelModel;
import com.hnty.driver.util.NetworkUtil;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by L on 2018/1/12.
 */

public class DriverCancelModelImpl implements DriverCancelModel {



    @Override
    public void driverCancel(DriverCancelParam param, final OnDriverCancelListener listener) {


        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            listener.onDriverCancelError("没有网络o");
            return;
        }

        MyApplication.getAPI().driverCancel(param.method,param.driver_id,param.voice_order)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<DriverCancelBean>(){

                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull DriverCancelBean bean) {

                        try {

                            if(bean.code==1){
                                listener.onDriverCancelSuccess(bean);
                            }else if(bean.code==0){
                                listener.onDriverCancelError(bean.msg);
                            }
                        }catch (Exception e){

                            e.printStackTrace();

                            listener.onDriverCancelError("数据错误111" );
                        }
                    }
                    @Override
                    public void onError(@NonNull Throwable e) {
                        listener.onDriverCancelError("数据错误222");
                    }

                    @Override
                    public void onComplete() {
                    }
                });


    }



}
