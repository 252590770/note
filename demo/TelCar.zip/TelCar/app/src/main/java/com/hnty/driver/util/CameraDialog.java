package com.hnty.driver.util;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface.OnCancelListener;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.hnty.driver.R;


public class CameraDialog {
    /**
     * 动作接口
     *
     * @author Administrator
     */
    public interface OnActionCameraSelect {
        void onCameraClick(int whichButton);
    }

    public static Dialog showSheet(Context context,
                                   final OnActionCameraSelect onActionCameraSelect,
                                   OnCancelListener onCancelListener
    ) {
        final Dialog mDialog = new Dialog(context, R.style.ActionSheet);
        LayoutInflater mInflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        LinearLayout layout = (LinearLayout) mInflater.inflate(
                R.layout.dialog_camera_layout, null);
        final int mFullFillWidth = 10000;
        // 设置宽度
        layout.setMinimumWidth(mFullFillWidth);
        TextView mTxtTakePhoto = (TextView) layout.findViewById(R.id.txt_dialog_camera);
        TextView mTxtChoose = (TextView) layout.findViewById(R.id.txt_dialog_photo);
        TextView mTxtCancel = (TextView) layout.findViewById(R.id.txt_dialog_cancel);
        //拍照
        mTxtTakePhoto.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onActionCameraSelect.onCameraClick(0);
                mDialog.dismiss();
            }
        });
        //从相册选择
        mTxtChoose.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View view) {
                onActionCameraSelect.onCameraClick(1);
                mDialog.dismiss();
            }
        });
        //取消
        mTxtCancel.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View view) {
                mDialog.dismiss();
            }
        });

        // 获取窗口
        Window window = mDialog.getWindow();
        // 改变对话框透明度
        WindowManager.LayoutParams mParams = window.getAttributes();
        mParams.x = 0;
        final int mMakeButton = -1000;
        mParams.y = mMakeButton;
        mParams.gravity = Gravity.BOTTOM;
        mDialog.onWindowAttributesChanged(mParams);
        // 设置点击外面取消对话框
        mDialog.setCanceledOnTouchOutside(false);
        if (onCancelListener != null) {
            mDialog.setOnCancelListener(onCancelListener);
            // 绑定布局
            mDialog.setContentView(layout);
            mDialog.show();
        }
        return mDialog;
    }



    public static Dialog showSheet(Context context,
                                   final OnActionCameraSelect onActionCameraSelect,
                                   OnCancelListener onCancelListener,
                                   int type
    ) {
        final Dialog mDialog = new Dialog(context, R.style.ActionSheet);
        LayoutInflater mInflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        LinearLayout layout = (LinearLayout) mInflater.inflate(
                R.layout.dialog_camera_layout, null);
        final int mFullFillWidth = 10000;
        // 设置宽度
        layout.setMinimumWidth(mFullFillWidth);
        TextView mTxtTakePhoto = (TextView) layout.findViewById(R.id.txt_dialog_camera);
        TextView mTxtChoose = (TextView) layout.findViewById(R.id.txt_dialog_photo);
        TextView mTxtCancel = (TextView) layout.findViewById(R.id.txt_dialog_cancel);
        //拍照
        mTxtTakePhoto.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onActionCameraSelect.onCameraClick(0);
                mDialog.dismiss();
            }
        });
        //从相册选择
        mTxtChoose.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View view) {
                onActionCameraSelect.onCameraClick(1);
                mDialog.dismiss();
            }
        });
        //取消
        mTxtCancel.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View view) {
                mDialog.dismiss();
            }
        });

        // 获取窗口
        Window window = mDialog.getWindow();
        // 改变对话框透明度
        WindowManager.LayoutParams mParams = window.getAttributes();
        mParams.x = 0;
        final int mMakeButton = -1000;
        mParams.y = mMakeButton;
        mParams.gravity = Gravity.BOTTOM;
        mDialog.onWindowAttributesChanged(mParams);
        // 设置点击外面取消对话框
        mDialog.setCanceledOnTouchOutside(false);
        if (onCancelListener != null) {
            mDialog.setOnCancelListener(onCancelListener);
            // 绑定布局
            mDialog.setContentView(layout);
            mDialog.show();
        }
        return mDialog;
    }




}
