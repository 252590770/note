package com.hnty.driver.model.modelimpl;

import android.util.Log;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.DriverCancelBean;
import com.hnty.driver.entity.DriverCancelParam;
import com.hnty.driver.entity.DriverDetailBean;
import com.hnty.driver.entity.GetDriverOrderStateBean;
import com.hnty.driver.inter.OnDriverCancelListener;
import com.hnty.driver.inter.OnDriverOrderStateListener;
import com.hnty.driver.model.modelinter.DriverCancelModel;
import com.hnty.driver.model.modelinter.DriverOrderStateModel;
import com.hnty.driver.util.NetworkUtil;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by L on 2018/1/12.
 */

public class DriverOrderStateModelImpl implements DriverOrderStateModel {

    @Override
    public void getDriverOrderState(String id,final OnDriverOrderStateListener listener) {

        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            listener.onDriverOrderStateError("没有网络o");
            return;
        }

        MyApplication.getAPI().getDriverOrderState("getdriverOrderstate",id)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<GetDriverOrderStateBean>(){

                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull GetDriverOrderStateBean bean) {

                        try {

                            if(bean.code==1){
                                listener.onDriverOrderStateSuccess(bean);
                            }else if(bean.code==0){
                                listener.onDriverOrderStateError(bean.msg);
                            }
                        }catch (Exception e){

                            listener.onDriverOrderStateError("数据错误" );
                        }
                    }
                    @Override
                    public void onError(@NonNull Throwable e) {
                        listener.onDriverOrderStateError("数据错误");
                    }

                    @Override
                    public void onComplete() {
                    }
                });


    }



}
