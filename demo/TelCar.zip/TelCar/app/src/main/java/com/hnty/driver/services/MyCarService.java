package com.hnty.driver.services;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.google.gson.Gson;
import com.hnty.driver.IClientCallBack;
import com.hnty.driver.IGetData;
import com.hnty.driver.IKillListener;
import com.hnty.driver.IMyEventCallBack;
import com.hnty.driver.MainActivity;
import com.hnty.driver.R;
import com.hnty.driver.activity.MainTopDialog;
import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.ComplaintOrderBean;
import com.hnty.driver.entity.EventBean;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.push.ClientSocket;
import com.hnty.driver.push.SocketSendThread;
import com.hnty.driver.util.MsgBox;
import com.hnty.driver.util.SPTool;
import com.hnty.driver.util.ToastUtil;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;


public class MyCarService extends Service implements ServiceConnection {

    volatile boolean needToRun;
//    public static MyCarService myService;
    private PowerManager pm;
    private PowerManager.WakeLock wakeLock;
    private MediaPlayer mMediaPlayer;
    /////////////////////
    public static final int NOTICE_ID = 100;


    @Override
    public void onCreate() {
        // TODO Auto-generated method stub
        super.onCreate();

        isReceiving=false;
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK|PowerManager.ON_AFTER_RELEASE, MyCarService.class.getName());
        wakeLock.acquire();

        mMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.service);
        mMediaPlayer.setLooping(true);


    }


    private void startPlayMusic(){
        if(mMediaPlayer != null){
            mMediaPlayer.start();
        }
    }
    private void stopPlayMusic(){
        if(mMediaPlayer != null){
            mMediaPlayer.stop();
        }
    }

    @Override
    public IBinder onBind(Intent intent) {


        return  binder;
    }
    @Override
    public boolean onUnbind(Intent intent) {
        needToRun=false;
        return super.onUnbind(intent);
    }


    IGetData.Stub binder;
    IClientCallBack callBack;
    IMyEventCallBack callBackEvent;
    {
        binder = new IGetData.Stub() {

            @Override
            public void registerEvent(IMyEventCallBack callBackEvent) throws RemoteException {

            }

            @Override
            public void register(IClientCallBack callback) throws RemoteException {
                callBack = callback;
            }

            @Override
            public void startCreateData(final  int b) throws RemoteException {
                needToRun = true;
                final ArrayList<String> arrayList = new ArrayList<>();

                        if(b==1){

                            stopPlayMusic();
                            // 这个方法只能用于自杀操作
                            android.os.Process.killProcess(android.os.Process.myPid());
                        }



            }
        };
    }

    
    public MyCarService() {
    }

    boolean isSending;
    boolean isReceiving;

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(EventBean event) {
        switch (event.code){

            case 101://续播订单

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        try { EventBus.getDefault().post(new EventBean(5)); }catch (Exception e){}

                        try {
                            if(MyApplication.getOrderList().size()>0){
                                Message msg = new Message();
                                msg.what = MsgBox.MSG_ON_CONTINUE_PLAY_ORDER;
                                mHandler.sendMessage(msg);
                            }

                        }catch (Exception e){

                        }
                    }
                }, 5000);

                break;
        }
    };


    public int onStartCommand(Intent intent, int flags, int startId) {




//        myService = this;
        flags=START_STICKY;


        if (intent == null) {
            creatSocket();
        }else {
            Log.i("515","MyService == "+this.toString());

            switch (intent.getIntExtra("CMD",0)) {

                case 0:

                    break;
                case 1:

                    this.isReceiving = true;
                    this.isSending = false;
                    creatSocket();

                    break;
                case 2:

                    break;
                case 3:

                    break;
                case 4:

                    break;
                case 5:
                    break;
            }
        }
        return START_STICKY;
       // return super.onStartCommand(intent, flags, startId);
    }




    @Override
    public void onDestroy() {
        super.onDestroy();


        Log.i("602", "---->onCreate,停止服务");
        // 重启
        Intent intent = new Intent(getApplicationContext(),MyCarService.class);
        intent.putExtra("CMD",1);
        startService(intent);




    }


    //推送
    SocketSendThread mThread;
    Thread mHeartThread;
    ClientSocket mSocket;

    long CURRENT_TIME;
    private int IJDJKDKD;
    
    private void creatSocket() {

        if (SPTool.getUserInfo(MyCarService.this) == null) {
            return;
        }



        if (mThread == null) {
            mThread = new SocketSendThread(MyCarService.this, mSocket,
                    SPTool.getUserInfo(MyCarService.this).body.driver_id, 0x14, mHandler);
            mThread.start();
        }


        if (mHeartThread == null) {

            mHeartThread = new Thread() {

                @Override
                public void run() {
                    super.run();


                    startPlayMusic();
                    //if(SPTool.getInt(MyService.this, Constant.DriverState)==1){

                        String carNo = SPTool.getString(MyCarService.this, Constant.CarNo);
                        String carNoFormat = String.format("%1$-10s", carNo);

                        if (mSocket != null) {
                            boolean isSendCarNo = mSocket.sendLogin(carNoFormat, 0x05);
                            Log.e("isSendCarNo", isSendCarNo + "");
                        }

                        IJDJKDKD++;
                        Log.e("tag", IJDJKDKD + "");
                        String driver_id = SPTool.getUserInfo(MyCarService.this).body.driver_id;
                        if (driver_id.length() == 1) {
                            driver_id = "     " + driver_id;
                        } else if (driver_id.length() == 2) {
                            driver_id = "    " + driver_id;
                        } else if (driver_id.length() == 3) {
                            driver_id = "   " + driver_id;
                        } else if (driver_id.length() == 4) {
                            driver_id = "  " + driver_id;
                        } else if (driver_id.length() == 5) {
                            driver_id = " " + driver_id;
                        } else if (driver_id.length() == 6) {
                            driver_id = "" + driver_id;
                        } else if (driver_id.length() > 6) {
                            ToastUtil.show(MyCarService.this, "用户数量超过限制,请联系技术人员!");
                        }

                        while (true) {
                            if (mSocket != null) {
                                boolean isHeard = mSocket.sendLogin(driver_id, 0x04);
                                Log.e("login", isHeard + "");
                            }


                            try {
                                sleep(15000);//心跳时间
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }

                        }


                    }

               // }
            };
        }
    }


    public void sendNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Intent intent = new Intent(MyCarService.this,MainActivity.class);
        SPTool.putBoolean(MyCarService.this,"isFromNotification",true);
        PendingIntent pendingIntent = PendingIntent.getActivity(MyCarService.this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new NotificationCompat.Builder(this, "chat")
                .setContentTitle("收到一条新订单！")
                .setWhen(System.currentTimeMillis())
                .setSmallIcon(R.drawable.logo1)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.logo1))
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build();

        manager.notify(1, notification);

    }


    //Handler
    @SuppressLint("HandlerLeak")
    public Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {

            Log.i("423", "msg.what   " + msg.what);
            Log.i("423", "msg.toString   " + msg.toString());

            switch (msg.what) {
                case MsgBox.MSG_CONTENT: {//收到通知内容   播报第一条订单

                    if(MainTopDialog.mainTopDialog==null|| MainTopDialog.mainTopDialog.isDestroyed()){
                        //已关闭
                        if( !SPTool.getBoolean(MyCarService.this, Constant.AutoOpen)){


                            Intent intent2 = new Intent(MyCarService.this, MainActivity.class);
                            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                            startActivity(intent2);
                        }

                        postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if(!SPTool.getBoolean(MyCarService.this,"InBackground")){
                                    //在前台
                                    Log.i("524","222222222222   在前台");
                                    //收到通知内容   播报第一条订单
                                    EventBus.getDefault().post(new EventBean(2));
                                }
                            }
                        }, 3000);
                    }
                }
                break;

                case MsgBox.MSG_ON_CONTINUE_PLAY_ORDER: //续播订单


                    EventBus.getDefault().post(new EventBean(3));

                    break;
                case MsgBox.MSG_ON_FINISH_ORDER: {//完成订单

                }
                break;

                case MsgBox.MSG_SHUTDOWN_FAILED: {//连接服务器失败  重新连接

                    Log.i("cccccc", "  重新连接");
                    mThread = null;
                    creatSocket();
                }
                break;

                case MsgBox.MSG_BEAT: {//连接服务器失败  重新连接

                    if (System.currentTimeMillis() - CURRENT_TIME > 30000) {
                        creatSocket();
                    }
                    CURRENT_TIME = System.currentTimeMillis();
                }
                break;
                case MsgBox.MSG_SHUTDOWN_SUCCESS: {//登录成功

                    mSocket = (ClientSocket) msg.obj;



                    if (!mHeartThread.isAlive()) {
                        mHeartThread.start();
                    }
                }
                break;

                case MsgBox.MSG_ON_CAR_NO_SAME: {//有别的司机用此车牌登录

                    stopPlayMusic();
                    SPTool.putInt(MyCarService.this, Constant.DriverState,0);
                    // 这个方法只能用于自杀操作
                    MyApplication.getInstance().driverOutLine();
                    postDelayed(new Runnable() {
                        @Override
                        public void run() {



                        }
                    }, 5000);

                    postDelayed(new Runnable() {
                        @Override
                        public void run() {

                            // 获取当前进程的id
                            int pid = android.os.Process.myPid();
                            // 这个方法只能用于自杀操作
                            android.os.Process.killProcess(pid);
                        }
                    }, 6000);


                }
                break;


                case MsgBox.MSG_ON_OTHER_ORDER: {//别人接单

                    Log.i("425", "  main 接收到的消息  1003  content  == ");
                    ComplaintOrderBean bean = new Gson().fromJson(((String)msg.obj),ComplaintOrderBean.class);
                    MyApplication.removeBean(-1,bean.body.voice_order);
                    EventBus.getDefault().post(new EventBean(4,(String)msg.obj));
                    //myWindowManager.updatetview("2");
                    break;
                }

                case MsgBox.MSG_ON_NOTICE:

                    //系统公告
                    SPTool.putString(MyCarService.this, Constant.Notice, (String) msg.obj);
                    EventBus.getDefault().post(new EventBean(1,(String) msg.obj));

                    break;

                case MsgBox.MSG_ON_PLAY_COMPLETE://续播声音

                    postDelayed(new Runnable() {
                        @Override
                        public void run() {

                            //续播声音
                            try { EventBus.getDefault().post(new EventBean(5)); }catch (Exception e){}
                            try {
                                if(MyApplication.getOrderList().size()>0){
                                    Message msg = new Message();
                                    msg.what = MsgBox.MSG_ON_CONTINUE_PLAY_ORDER;
                                    mHandler.sendMessage(msg);
                                }
                            }catch (Exception e){ }
                        }
                    }, 5000);

                    break;
                default:
                    break;
            }
        };
    };


    IKillListener killListener;
//    IKillLintenerA killListenerA;

    @Override
    public void onServiceConnected(ComponentName name, IBinder service) {
        killListener = IKillListener.Stub.asInterface(service);
//        killListenerA = IKillLintenerA.Stub.asInterface(service);

    }

    @Override
    public void onServiceDisconnected(ComponentName name) {

    }
    public static class CarRunService extends Service {
        @Override public int onStartCommand(Intent intent, int flags, int startId) {
            startForeground(NOTICE_ID, new Notification());
            stopForeground(true);
            stopSelf();
            return super.onStartCommand(intent, flags, startId);
        }

        @Nullable
        @Override
        public IBinder onBind(Intent intent) {
            return null;
        }
    }
}
