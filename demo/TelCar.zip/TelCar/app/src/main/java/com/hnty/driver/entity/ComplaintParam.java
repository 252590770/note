package com.hnty.driver.entity;

/**
 * Created by L on 2018/1/11.
 */

public class ComplaintParam {



    public String method;
    public String complaint_desc;
    public String driver_id;
    public String order_id;
    public String voice_tell;

    public ComplaintParam() {
    }

    public ComplaintParam(String method, String complaint_desc, String driver_id, String order_id, String voice_tell) {
        this.method = method;
        this.complaint_desc = complaint_desc;
        this.driver_id = driver_id;
        this.order_id = order_id;
        this.voice_tell = voice_tell;
    }
}
