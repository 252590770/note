package com.hnty.driver.model.modelimpl;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.CodeParam;
import com.hnty.driver.entity.VoiceOrderListBean;
import com.hnty.driver.inter.OnCodeListener;
import com.hnty.driver.inter.OnVoiceOrderListListener;
import com.hnty.driver.model.modelinter.VoiceOrderListModel;
import com.hnty.driver.util.NetworkUtil;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by L on 2018/1/12.
 */

public class VoiceOrderListModelImpl implements VoiceOrderListModel {


    @Override
    public void getOrderList( final OnVoiceOrderListListener listener,String page) {


        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            listener.onVoiceOrderListError("没有网络o");
            return;
        }

        MyApplication.getAPI().getOrderList("getVoiceOrderdesc",page)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<VoiceOrderListBean>(){

                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull VoiceOrderListBean bean) {

                        try {
                            listener.onVoiceOrderListSuccess(bean);
                        }catch (Exception e){
                            listener.onVoiceOrderListError("数据错误");
                        }
                    }
                    @Override
                    public void onError(@NonNull Throwable e) {
                        listener.onVoiceOrderListError("数据错误");
                    }

                    @Override
                    public void onComplete() {
                        listener.onComplete();
                    }
                });


    }



}
