package com.hnty.driver.activity;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.Gson;
import com.hnty.driver.R;
import com.hnty.driver.base.BaseActivity;
import com.hnty.driver.databinding.ActivityLoginBinding;
import com.hnty.driver.entity.DriverDetailBean;
import com.hnty.driver.entity.LoginParam;
import com.hnty.driver.entity.UserInfoBean;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.impl.PermissionResultListener;
import com.hnty.driver.inter.OnGetDriverDetailListener;
import com.hnty.driver.inter.OnLoginListener;
import com.hnty.driver.model.modelimpl.GetDriverDetailModelImpl;
import com.hnty.driver.model.modelimpl.LoginModelImpl;
import com.hnty.driver.util.SPTool;
import com.hnty.driver.util.ToastUtil;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;



public class LoginActivity extends BaseActivity<ActivityLoginBinding> implements View.OnClickListener ,OnLoginListener,OnGetDriverDetailListener {

    private Context context;
    private Button btnLogin;
    private Button btnRegister;
    private Button btnLogout;
    private CheckBox cbSign;
    private LinearLayout llPsd;
    private LinearLayout llSignPsd;
    private TextView tvForgetPass;
    private String etTelStr="";
    private String etPsdStr="";
    private String etCarnoStr="";
    private EditText etTel,etPsd,etCarno;
    private Gson gson = new Gson();

    private LoginModelImpl loginModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//来保持屏幕高亮
        setTitle("手机登陆");
        showContentView();
        initView();
        setView();
        getIMSI();
        loginModel = new LoginModelImpl();


    }


    @Override
    protected void onResume() {
        super.onResume();
        initView();
    }

    public void initView() {
        context = this;
        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnLogout = (Button) findViewById(R.id.btnLogout);
        cbSign = (CheckBox) findViewById(R.id.cbSign);
        llPsd = (LinearLayout) findViewById(R.id.llPsd);
        llSignPsd = (LinearLayout) findViewById(R.id.llSignPsd);
        tvForgetPass = (TextView) findViewById(R.id.tvForgetPass);
        etTel = (EditText) findViewById(R.id.etTel);
        etPsd = (EditText) findViewById(R.id.etPsd);
        etCarno = (EditText) findViewById(R.id.etCarno);
        btnLogin.setOnClickListener(this);
        btnRegister.setOnClickListener(this);
        llSignPsd.setOnClickListener(this);
        btnLogout.setOnClickListener(this);

        try{
            if (SPTool.getPSW(this)!=null) {

                etTel.setText(SPTool.getPSW(this).body.driver_tell);
                etPsd.setText(SPTool.getPSW(this).body.driver_pass);
                etCarno.setText(SPTool.getString(this,Constant.CarNo));
                cbSign.setChecked(SPTool.getBoolean(this,Constant.IsCheckedPSW));
            }
        }catch (Exception e){

        }


    }

    void setView(){

        boolean IsLogin =   SPTool.getBoolean(this,Constant.IsLogin);

        if(IsLogin){
            btnLogout.setVisibility(View.VISIBLE);
            llPsd.setVisibility(View.GONE);
            etPsd.setVisibility(View.GONE);
            etCarno.setVisibility(View.GONE);
            btnLogin.setVisibility(View.GONE);
            btnRegister.setVisibility(View.GONE);



            //不可编辑
            etTel.setFocusable(false);
            etTel.setFocusableInTouchMode(false);
            etPsd.setFocusable(false);
            etPsd.setFocusableInTouchMode(false);
            etCarno.setFocusable(false);
            etCarno.setFocusableInTouchMode(false);




        }else {
            btnLogout.setVisibility(View.GONE);
            llPsd.setVisibility(View.VISIBLE);
            btnLogin.setVisibility(View.VISIBLE);
            etPsd.setVisibility(View.VISIBLE);
            etCarno.setVisibility(View.VISIBLE);
            btnRegister.setVisibility(View.VISIBLE);

            //可编辑
            etTel.requestFocus();
            etTel.setFocusable(true);
            etTel.setFocusableInTouchMode(true);
            etPsd.requestFocus();
            etPsd.setFocusable(true);
            etPsd.setFocusableInTouchMode(true);
            etCarno.requestFocus();
            etCarno.setFocusable(true);
            etCarno.setFocusableInTouchMode(true);


        }

    }


// c76608

// b5730a

// b2821c


    public static void start(Context mContext) {  //c76608   b2821c
        Intent intent = new Intent(mContext, LoginActivity.class);
        mContext.startActivity(intent);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.btnRegister://注册

                startActivity(new Intent(this,RegisterActivity.class));
                break;
            case R.id.btnLogin:

                getLoginIMSI();



                break;

            case R.id.llSignPsd://ji zhu mi ma

                if(cbSign.isChecked()){
                    cbSign.setChecked(false);
                    //统一设置为保存密码
                    cbSign.setChecked(true);
                    SPTool.putBoolean(this,Constant.IsCheckedPSW,false);
                }else {
                    cbSign.setChecked(true);
                    SPTool.putBoolean(this,Constant.IsCheckedPSW,true);
                }

                break;

            case R.id.btnLogout:


                try{

                    SPTool.putBoolean(this,Constant.IsLogin,false);
                    SPTool.putContent(this, Constant.UserInfoBean,"");
                    btnLogout.setVisibility(View.GONE);
                    btnLogin.setVisibility(View.VISIBLE);
                    llPsd.setVisibility(View.VISIBLE);
                    etPsd.setVisibility(View.VISIBLE);
                    etCarno.setVisibility(View.VISIBLE);
                    btnRegister.setVisibility(View.VISIBLE);

                    //可编辑
                    etTel.requestFocus();
                    etTel.setFocusable(true);
                    etTel.setFocusableInTouchMode(true);
                    etPsd.requestFocus();
                    etPsd.setFocusable(true);
                    etPsd.setFocusableInTouchMode(true);
                    etCarno.requestFocus();
                    etCarno.setFocusable(true);
                    etCarno.setFocusableInTouchMode(true);


                    if (SPTool.getBoolean(this,Constant.IsCheckedPSW)) {
                        etTel.setText(SPTool.getUserInfo(this).body.driver_tell);
                        etPsd.setText(SPTool.getUserInfo(this).body.driver_pass);
                        etCarno.setText(SPTool.getString(LoginActivity.this,Constant.CarNo));
                        cbSign.setChecked(SPTool.getBoolean(this,Constant.IsCheckedPSW));
                    }else {
                        etTel.setText("");
                        etPsd.setText("");
                        etCarno.setText("");
                        cbSign.setChecked(SPTool.getBoolean(this,Constant.IsCheckedPSW));
                    }

                }catch (Exception e){

                }




                break;
        }
    }




    //判断是否填写正确
    private boolean getStringOK() {
        // TODO Auto-generated method stub

        boolean ok = true;

        etTelStr = etTel.getText().toString().trim();
        etPsdStr = etPsd.getText().toString().trim();
        etCarnoStr = etCarno.getText().toString().trim();

        if(etTelStr.length()==0){

            ToastUtil.show(context, "请输入手机号");
            ok = false;

        }else  if(etCarnoStr.length()==0) {

            ToastUtil.show(this, "请输入车牌号");
            ok = false;

        }else  if(etPsdStr.length()==0) {

            ToastUtil.show(context, "请输入密码");
            ok = false;
        }
        return ok;
    }



    final  int PER_REQUEST_CODE =0;
    String imei="";
    private String getIMSI(){



        performRequestPermissions(getString(R.string.permission_imei),
                new String[]{
                        Manifest.permission.READ_PHONE_STATE,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.READ_PHONE_STATE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.WAKE_LOCK
                }
                , PER_REQUEST_CODE,
                new PermissionResultListener() {
                    @Override
                    public void onPermissionDenied() {

                    }

                    @Override
                    public void onPermissionGranted() {



                        try {


                            TelephonyManager telmg = (TelephonyManager)
                                    getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE);
                            imei = telmg.getSubscriberId();

                            getDriverDetail(imei);



                        }catch (Exception E)
                        {
                            E.printStackTrace();
                        }

                    }
                });


        return imei;
    }



    private String getLoginIMSI(){

        performRequestPermissions(getString(R.string.permission_imei),
                new String[]{
                        Manifest.permission.READ_PHONE_STATE,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.READ_PHONE_STATE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                }
                , PER_REQUEST_CODE,
                new PermissionResultListener() {
                    @Override
                    public void onPermissionDenied() {

                    }

                    @Override
                    public void onPermissionGranted() {

                        try {

                            TelephonyManager telmg = (TelephonyManager)
                                    getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE);
                            imei = telmg.getSubscriberId();


                            if(getStringOK()){

                                LoginParam param;

                                try {
                                    param = new LoginParam("DriverLogin",
                                            URLEncoder.encode(etCarnoStr, "utf-8"),
                                            etTelStr,
                                            etPsdStr,
                                            imei);
                                    loginModel.sendLogin(param,LoginActivity.this);
                                    showProgressDialog();
                                } catch (UnsupportedEncodingException e) {
                                    e.printStackTrace();
                                }

                            }


                        }catch (Exception E)
                        {
                            E.printStackTrace();
                        }

                    }
                });


        return imei;
    }



    @Override
    public void onSuccess(UserInfoBean bean) {

        SPTool.putContent(this, Constant.UserInfoBean,bean.toString());
        SPTool.putContent(this, Constant.PSWBean,bean.toString());

        SPTool.putString(this,Constant.CarNo,etCarnoStr);
        SPTool.putBoolean(this, Constant.IsCheckedPSW,cbSign.isChecked());

//        JPushInterface.setAlias(this, bean.body.driver_id,
//                new TagAliasCallback() {
//                    @Override
//                    public void gotResult(int arg0, String arg1,
//                                          Set<String> arg2) {
//                        // TODO Auto-generated method stub
//                        // Log.i("111111","arg0="+arg0+"  arg1=="+arg1+"   arg2=="+arg2.toString());
//                    }
//                });


        btnLogout.setVisibility(View.VISIBLE);
        llPsd.setVisibility(View.GONE);
        etPsd.setVisibility(View.GONE);
        etCarno.setVisibility(View.GONE);
        btnLogin.setVisibility(View.GONE);
        btnRegister.setVisibility(View.GONE);
        SPTool.putBoolean(this,Constant.IsLogin,true);
        dissmissProgressDialog();

        //不可编辑
        etTel.setFocusable(false);
        etTel.setFocusableInTouchMode(false);
        etPsd.setFocusable(false);
        etPsd.setFocusableInTouchMode(false);
        etCarno.setFocusable(false);
        etCarno.setFocusableInTouchMode(false);


        try {
            Thread.sleep(1000);
            finish();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }




    @Override
    public void onError(String err) {
        ToastUtil.show(this,err);
        dissmissProgressDialog();
    }






    //请求码
    private int mRequestCode;
    //运行时权限接口
    private PermissionResultListener mListener;
    protected void performRequestPermissions(String desc, String[] permissions,
                                             int requestCode,
                                             PermissionResultListener listener) {
        if (permissions == null || permissions.length == 0) {
            return;
        }
        mRequestCode = requestCode;
        mListener = listener;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkEachSelfPermission(permissions)) {// 检查是否声明了权限
                requestEachPermissions(desc, permissions, requestCode);
            } else {// 已经申请权限
                if (mListener != null) {
                    mListener.onPermissionGranted();
                }
            }
        } else {
            if (mListener != null) {
                mListener.onPermissionGranted();
            }
        }
    }



    /**
     * 检察每个权限是否申请
     *
     * @param permissions
     * @return true 需要申请权限,false 已申请权限
     */
    private boolean checkEachSelfPermission(String[] permissions) {
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) !=
                    PackageManager.PERMISSION_GRANTED) {
                return true;
            }
        }
        return false;
    }

    private void requestEachPermissions(String desc, String[] permissions, int requestCode) {
        if (shouldShowRequestPermissionRationale(permissions)) {// 需要再次声明
            showRationaleDialog(desc, permissions, requestCode);
        } else {
            ActivityCompat.requestPermissions(LoginActivity.this, permissions, requestCode);
        }
    }


    /**
     * 再次申请权限时，是否需要声明
     *
     * @param permissions
     * @return
     */
    private boolean shouldShowRequestPermissionRationale(String[] permissions) {
        for (String permission : permissions) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 弹出声明的 Dialog
     *
     * @param desc
     * @param permissions
     * @param requestCode
     */
    private void showRationaleDialog(String desc, final String[] permissions,
                                     final int requestCode) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.tips))
                .setMessage(desc)
                .setPositiveButton(getResources().getString(R.string.sure),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                ActivityCompat.requestPermissions(LoginActivity.this,
                                        permissions, requestCode);
                            }
                        })
                .setNegativeButton(getResources().getString(R.string.cancel),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        })
                .setCancelable(false)
                .show();
    }





    /**
     * 显示进度框
     */
    private ProgressDialog progDialog = null;// 搜索时进度条
    private void showProgressDialog() {
        if (progDialog == null)
            progDialog = new ProgressDialog(this);
        progDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progDialog.setIndeterminate(false);
        progDialog.setCancelable(true);
        progDialog.setMessage("正在登录");
        progDialog.show();
    }

    /**
     * 隐藏进度框
     */
    private void dissmissProgressDialog() {
        if (progDialog != null) {
            progDialog.dismiss();
        }
    }



    /////////////////////////获取司机信息///////////////////////////
    GetDriverDetailModelImpl detailModel;

    void getDriverDetail(String imei){
        if(detailModel == null ){
            detailModel = new GetDriverDetailModelImpl();
        }
        detailModel.getDriverDetail(imei, this);
    }



    @Override
    public void onGetDriverDetailSuccess(DriverDetailBean bean) {
        bindingView.etTel.setText(bean.body.driver_tell);
        bindingView.etCarno.setText(bean.body.car_no);
    }

    @Override
    public void onGetDriverDetailError(String errStr) {

    }
    /////////////////////////获取司机信息///////////////////////////

}
