package com.hnty.driver.util;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build;
import android.os.Environment;
import android.os.Process;
import android.util.Log;

import com.hnty.driver.LocalService;
import com.hnty.driver.MainActivity;
import com.hnty.driver.file.FormFile;
import com.hnty.driver.file.SocketHttpRequester;
import com.hnty.driver.finals.Constant;
import com.hnty.driver.push.ConnectURL;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.Thread.UncaughtExceptionHandler;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class CrashHandler implements UncaughtExceptionHandler {

	private static final String TAG = "CrashHandler";
	private static final boolean DEBUG = true;
	private  String errorfilename="";
	private static final String FILE_NAME = "crash";

	// log文件的后缀名
	private static final String FILE_NAME_SUFFIX = ".txt";

	private static CrashHandler sInstance = new CrashHandler();

	// 系统默认的异常处理（默认情况下，系统会终止当前的异常程序）
	private UncaughtExceptionHandler mDefaultCrashHandler;

	private Context mContext;

	// 构造方法私有，防止外部构造多个实例，即采用单例模式
	private CrashHandler() {
	}

	public static CrashHandler getInstance() {
		return sInstance;
	}

	// 这里主要完成初始化工作
	public void init(Context context) {
		// 获取系统默认的异常处理器
		mDefaultCrashHandler = Thread.getDefaultUncaughtExceptionHandler();
		// 将当前实例设为系统默认的异常处理器
		Thread.setDefaultUncaughtExceptionHandler(this);
		// 获取Context，方便内部使用
		mContext = context.getApplicationContext();
	}

	/**
	 * 这个是最关键的函数，当程序中有未被捕获的异常，系统将会自动调用#uncaughtException方法
	 * thread为出现未捕获异常的线程，ex为未捕获的异常，有了这个ex，我们就可以得到异常信息。
	 */
	@Override
	public void uncaughtException(Thread thread, Throwable ex) {
		try {
			// 导出异常信息到SD卡中
			dumpExceptionToSDCard(ex);
			// 这里可以通过网络上传异常信息到服务器，便于开发人员分析日志从而解决bug
			uploadExceptionToServer();
		} catch (IOException e) {
			e.printStackTrace();
		}

		// 打印出当前调用栈信息
		ex.printStackTrace();
		// 如果系统提供了默认的异常处理器，则交给系统去结束我们的程序，否则就由我们自己结束自己
		Intent intent = new Intent(mContext.getApplicationContext(), MainActivity.class);
		@SuppressLint("WrongConstant") PendingIntent restartIntent = PendingIntent.getActivity(
				mContext.getApplicationContext(), 0, intent,Intent.FLAG_ACTIVITY_NEW_TASK);
		//退出程序
		AlarmManager mgr = (AlarmManager)mContext.getSystemService(Context.ALARM_SERVICE);
		mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 1000,
				restartIntent); // 1秒钟后重启应用

		if (mDefaultCrashHandler != null) {
			mDefaultCrashHandler.uncaughtException(thread, ex);
		} else {
			Process.killProcess(Process.myPid());
		}

	}

	/**
	 * 写入SD卡
	 *
	 * @param ex
	 * @throws IOException
	 */
	@SuppressLint("SimpleDateFormat")
	private void dumpExceptionToSDCard(Throwable ex) throws IOException {
		// 如果SD卡不存在或无法使用，则无法把异常信息写入SD卡
		if (!Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED)) {
			if (DEBUG) {
				Log.e(TAG, "sdcard unmounted,skip dump exception");
				return;
			}
		}

		File dir = new File(Constant.LOG_PATH);
		if (!dir.exists()) {
			dir.mkdirs();
		}
		long current = System.currentTimeMillis();
		String time = new SimpleDateFormat("yyyyMMddHHmmss")
				.format(new Date(current));
		// 以当前时间创建log文件
		File file = new File(Constant.LOG_PATH + FILE_NAME + time
				+ FILE_NAME_SUFFIX);
		errorfilename=Constant.LOG_PATH + FILE_NAME + time+ FILE_NAME_SUFFIX;
		//SPTool.putCrashLog(mContext,file);
		try {
			PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(
					file)));
			// 导出发生异常的时间
			pw.println(time);

			// 导出手机信息
			dumpPhoneInfo(pw);

			pw.println();
			// 导出异常的调用栈信息

			ex.printStackTrace(pw);

			pw.close();

			new Thread(){
				@Override
				public void run() {
					Log.i(TAG, "runnable run"+errorfilename);
					File file = new File(errorfilename);
					uploadFile(file);
				}
			}.start();

		} catch (Exception e) {
			Log.e(TAG, "dump crash info failed");
		}
	}

	private void dumpPhoneInfo(PrintWriter pw) throws NameNotFoundException {
		// 应用的版本名称和版本号
		PackageManager pm = mContext.getPackageManager();
		PackageInfo pi = pm.getPackageInfo(mContext.getPackageName(),
				PackageManager.GET_ACTIVITIES);
		pw.print("App Version: ");
		pw.print(pi.versionName);
		pw.print('_');
		pw.println(pi.versionCode);

		// android版本号
		pw.print("OS Version: ");
		pw.print(Build.VERSION.RELEASE);
		pw.print("_");
		pw.println(Build.VERSION.SDK_INT);

		// 手机制造商
		pw.print("Vendor: ");
		pw.println(Build.MANUFACTURER);

		// 手机型号
		pw.print("Model: ");
		pw.println(Build.MODEL);

		// cpu架构
		pw.print("CPU ABI: ");
		pw.println(Build.CPU_ABI);
	}

	/**
	 * 上传到服务器
	 */
	private void uploadExceptionToServer() {



	}

	/**
	 * 上传图片到服务器
	 *
	 * @param imageFile 包含路径
	 */
	public void uploadFile(File imageFile) {
		Log.i(TAG, "upload start");
		try {
			String requestUrl = "http://" +ConnectURL.TCP_IP+ConnectURL.PORT+"/travel/loginfo.action?method=execute";
			Log.i(TAG, "upload start"+requestUrl);
			//请求普通信息
			Map<String, String> params = new HashMap<String, String>();
			String driver_id = SPTool.getUserInfo(mContext).body.driver_id;
			params.put("driverid", driver_id);
			params.put("errfileName", imageFile.getName());
			//上传文件
			Log.i(TAG, "upload start"+imageFile.getName());
			FormFile formfile = new FormFile(imageFile.getName(), imageFile, "image", "application/octet-stream");

			SocketHttpRequester.post(requestUrl, params, formfile);
			Log.i(TAG, "upload success");
		} catch (Exception e) {
			Log.i(TAG, "upload error");
			e.printStackTrace();
		}
		Log.i(TAG, "upload end");
	}
}
