package com.hnty.driver.inter;


import com.hnty.driver.entity.DriverCancelBean;
import com.hnty.driver.entity.DriverRankBean;

import java.util.ArrayList;

/**
 * Created by L on 2018/1/12.
 */

public interface OnDriverRankListener {

    void onDriverRankSuccess(ArrayList<DriverRankBean> list);
    void onDriverRankError(String errStr);

}
