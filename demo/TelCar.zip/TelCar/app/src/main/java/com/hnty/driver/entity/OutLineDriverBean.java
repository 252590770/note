package com.hnty.driver.entity;

import com.google.gson.Gson;


public class OutLineDriverBean {
 

    public int code;
    public String msg;


    @Override
    public String toString() {

        return new Gson().toJson(this);
    }




}
