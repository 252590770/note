package com.hnty.driver.util;

import android.app.DownloadManager;
import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.FileProvider;
import android.util.Log;

import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.extractor.ExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelection;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.upstream.BandwidthMeter;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.util.Util;
import com.hnty.driver.MainActivity;
import com.hnty.driver.R;
import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.EventBean;
import com.hnty.driver.entity.PushOrderBean;
import com.hnty.driver.finals.Constant;

import org.greenrobot.eventbus.EventBus;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

import static com.hnty.driver.finals.Constant.baseUrl;


public class VoiceUtils implements MediaPlayer.OnCompletionListener,MediaPlayer.OnErrorListener,ExoPlayer.EventListener {
    private static volatile VoiceUtils singleton = null;
    public    boolean IsPlaying;
    MediaPlayer mediaPlayer=null;
    private Context mContext;
    private PushOrderBean bean;
    private Handler handler;
    public  SimpleExoPlayer player;

    public VoiceUtils(Context context) {
        this.mContext = context.getApplicationContext();
    }

    /**
     * 单例
     * @param context
     * @return
     */
    public static VoiceUtils with(Context context){
        if (singleton == null) {
            synchronized (VoiceUtils.class) {
                if (singleton == null) {
                    singleton = new VoiceUtils(context);
                }
            }
        }
        return singleton;
    }

    public void SetIsPlay( boolean IsPlaying){

        this.IsPlaying=IsPlaying;
    }

    public boolean GetIsPlay() {
        return IsPlaying;
    }



    public void Play(final PushOrderBean bean,Handler handler)
    {
        this.bean = bean;
        this.handler = handler;
        MediaPlayer mp = null;
        Uri uri;
        //APK升级

		singleton.SetIsPlay(true);
        // 判断版本大于6.0
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M && bean.body.voice_name.indexOf("mp3")>0) {
            try {

                MediaSource mediaSource;
                DataSource.Factory dataSourceFactory;
                TrackSelector trackSelector;
                ExtractorsFactory extractorsFactory;
                DefaultBandwidthMeter defaultBandwidthMeter;
                TrackSelection.Factory trackSelectionFactory;
                BandwidthMeter bandwidthMeter;
                bandwidthMeter = new DefaultBandwidthMeter();
                extractorsFactory = new DefaultExtractorsFactory();
                defaultBandwidthMeter = new DefaultBandwidthMeter();

                trackSelectionFactory = new AdaptiveTrackSelection.Factory(bandwidthMeter);

                trackSelector = new DefaultTrackSelector(trackSelectionFactory);

                dataSourceFactory = new DefaultDataSourceFactory(mContext, Util.getUserAgent(mContext, "mediaPlayerSample"), defaultBandwidthMeter);
                mediaSource = new ExtractorMediaSource(Uri.parse(baseUrl + "travel/uploadVoice/" + bean.body.voice_name.trim()),
                        dataSourceFactory,
                        extractorsFactory,
                        null,
                        null);
                player = ExoPlayerFactory.newSimpleInstance(mContext, trackSelector);
                player.addListener(VoiceUtils.this);
                player.prepare(mediaSource);
                player.setPlayWhenReady(true);

            }
            catch (IllegalStateException e) {
                e.printStackTrace();
                uri = Uri.parse(baseUrl + Constant.travel+"/uploadVoice/"+bean.body.voice_name.trim());
                mp = MediaPlayer.create(mContext,uri);//
                SPTool.putBoolean(mContext,Constant.IsPlay,true);
                singleton.SetIsPlay(false);
                EventBus.getDefault().post(new EventBean(11));
                ToastUtil.show(mContext,"网络异常无法播放声音");
                new Handler().postDelayed(
                        new Runnable() {
                            @Override
                            public void run() {
                                EventBus.getDefault().post(new EventBean(5));
                            }
                        }
                        , 5000);


            }
        }else {

            uri = Uri.parse(baseUrl + Constant.travel+"/uploadVoice/"+bean.body.voice_name.trim());
            try {

                mp = MediaPlayer.create(mContext,uri);
                if (mp==null)
                {
                    return;
                }
                SPTool.putBoolean(mContext,Constant.IsPlay,false);
                //开始播放音频
                mp.start();
                // mp.setDataSource(mContext,uri);
                //System.out.println("play");
                // mp.prepare();
            } catch (IllegalStateException e) {
                e.printStackTrace();
                mp = MediaPlayer.create(mContext,uri);//
                SPTool.putBoolean(mContext,Constant.IsPlay,true);
                singleton.SetIsPlay(false);
                EventBus.getDefault().post(new EventBean(11));
                ToastUtil.show(mContext,"网络异常无法播放声音");
                new Handler().postDelayed(
                        new Runnable() {
                            @Override
                            public void run() {
                                EventBus.getDefault().post(new EventBean(5));
                            }
                        }
                        , 5000);


            }

            //播放错误触发此事件
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra) {

                    EventBus.getDefault().post(new EventBean(Constant.NeedPlay,""));

                    SPTool.putBoolean(mContext,Constant.IsPlay,false);
                    EventBus.getDefault().post(new EventBean(11));
                    new Handler().postDelayed(
                            new Runnable() {
                                @Override
                                public void run() {
                                    EventBus.getDefault().post(new EventBean(5));
                                }
                            }
                            , 5000);


                    try {   MyApplication.removeBean(0,null); } catch (Exception e){}

                    try {
                        mp.stop();;
                        mp.release();
                        mp = null;
                    }catch (Exception e){
                        mp.stop();;
                        mp.release();
                        mp = null;
                    }

                    SetIsPlay(false);

                    return false;
                }


            });
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp)
                {


                    SetIsPlay(false);
                    mp.release();
                    mp = null;
                    SPTool.putBoolean(mContext,Constant.IsPlay,true);
                    singleton.SetIsPlay(false);
                    EventBus.getDefault().post(new EventBean(11));
                    new Handler().postDelayed(
                            new Runnable() {
                                @Override
                                public void run() {
                                    EventBus.getDefault().post(new EventBean(5));
                                }
                            }
                            , 5000);

                    Log.i("101","handler   rList().remove");
                    if(MyApplication.getOrderList().size()!=0&&VoiceUtils.this.handler!=null){
                        MyApplication.removeBean(0,null);
                        //EventBus.getDefault().post(new EventBean(101));

                        Message msg = new Message();
                        msg.what = MsgBox.MSG_ON_PLAY_COMPLETE;
                        VoiceUtils.this.handler.sendMessage(msg);

                    }



                }
            });

        }

















    }



    public int PlayReturnLong(final PushOrderBean bean,Handler handler)
    {


        singleton.SetIsPlay(true);
        int mp3Long = -1;
        try {
            mp3Long = MediaPlayer.create(mContext,Uri.parse(baseUrl + Constant.travel+"/uploadVoice/"+bean.body.voice_name.trim())).getDuration();

        }catch (Exception e){

            SPTool.putBoolean(mContext,Constant.IsPlay,true);
            singleton.SetIsPlay(false);

            EventBus.getDefault().post(new EventBean(11));
            new Handler().postDelayed(
                    new Runnable() {
                        @Override
                        public void run() {
                            EventBus.getDefault().post(new EventBean(5));
                        }
                    }
                    , 5000);

            Log.i("101","handler   rList().remove");
            if(MyApplication.getOrderList().size()!=0&&VoiceUtils.this.handler!=null){
                MyApplication.removeBean(0,null);
                //EventBus.getDefault().post(new EventBean(101));

                Message msg = new Message();
                msg.what = MsgBox.MSG_ON_PLAY_COMPLETE;
                VoiceUtils.this.handler.sendMessage(msg);

            }



        }

        this.bean = bean;
        this.handler = handler;
        MediaPlayer mp = null;
        Uri uri;
        //APK升级

        // 判断版本大于6.0
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M && bean.body.voice_name.indexOf("mp3")>0) {
            try {

                Log.i("cai","11111");

                MediaSource mediaSource;
                DataSource.Factory dataSourceFactory;
                TrackSelector trackSelector;
                ExtractorsFactory extractorsFactory;
                DefaultBandwidthMeter defaultBandwidthMeter;
                TrackSelection.Factory trackSelectionFactory;
                BandwidthMeter bandwidthMeter;
                bandwidthMeter = new DefaultBandwidthMeter();
                extractorsFactory = new DefaultExtractorsFactory();
                defaultBandwidthMeter = new DefaultBandwidthMeter();

                trackSelectionFactory = new AdaptiveTrackSelection.Factory(bandwidthMeter);

                trackSelector = new DefaultTrackSelector(trackSelectionFactory);

                dataSourceFactory = new DefaultDataSourceFactory(mContext, Util.getUserAgent(mContext, "mediaPlayerSample"), defaultBandwidthMeter);
                mediaSource = new ExtractorMediaSource(Uri.parse(baseUrl + Constant.travel+"/uploadVoice/" + bean.body.voice_name.trim()),
                        dataSourceFactory,
                        extractorsFactory,
                        null,
                        null);
                player = ExoPlayerFactory.newSimpleInstance(mContext, trackSelector);
                player.addListener(VoiceUtils.this);
                player.prepare(mediaSource);
                player.setPlayWhenReady(true);




            }
            catch (IllegalStateException e) {
                e.printStackTrace();
                uri = Uri.parse(baseUrl + Constant.travel+"/uploadVoice/"+bean.body.voice_name.trim());
                mp = MediaPlayer.create(mContext,uri);//
                SPTool.putBoolean(mContext,Constant.IsPlay,true);
                singleton.SetIsPlay(false);

                EventBus.getDefault().post(new EventBean(11));
                ToastUtil.show(mContext,"网络异常无法播放声音");
                new Handler().postDelayed(
                        new Runnable() {
                            @Override
                            public void run() {
                                EventBus.getDefault().post(new EventBean(5));
                            }
                        }
                        , 5000);


            }
        }else {

            Log.i("cai","222");

            uri = Uri.parse(baseUrl + Constant.travel+"/uploadVoice/"+bean.body.voice_name.trim());
            try {

                mp = MediaPlayer.create(mContext,uri);
                if (mp==null)
                {
                    return -1;
                }
                SPTool.putBoolean(mContext,Constant.IsPlay,false);
                //开始播放音频

//                mp3Long = mp.getDuration();

                mp.start();
                // mp.setDataSource(mContext,uri);
                //System.out.println("play");
                // mp.prepare();
            } catch (IllegalStateException e) {
                e.printStackTrace();
                mp = MediaPlayer.create(mContext,uri);//
                SPTool.putBoolean(mContext,Constant.IsPlay,true);
                singleton.SetIsPlay(false);
                ToastUtil.show(mContext,"网络异常无法播放声音");
                new Handler().postDelayed(
                        new Runnable() {
                            @Override
                            public void run() {
                                EventBus.getDefault().post(new EventBean(5));
                            }
                        }
                        , 5000);


            }

            //播放错误触发此事件
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra) {

                    EventBus.getDefault().post(new EventBean(Constant.NeedPlay,""));

                    SPTool.putBoolean(mContext,Constant.IsPlay,false);
                    singleton.SetIsPlay(false);

                    EventBus.getDefault().post(new EventBean(11));
                    new Handler().postDelayed(
                            new Runnable() {
                                @Override
                                public void run() {
                                    EventBus.getDefault().post(new EventBean(5));
                                }
                            }
                            , 5000);


                    try {   MyApplication.removeBean(0,null); } catch (Exception e){}

                    try {
                        mp.stop();;
                        mp.release();
                        mp = null;
                    }catch (Exception e){
                        mp.stop();;
                        mp.release();
                        mp = null;

                    }

                    return false;
                }


            });
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp)
                {


                    mp.release();
                    mp = null;
                    SPTool.putBoolean(mContext,Constant.IsPlay,true);
                    singleton.SetIsPlay(false);

                    EventBus.getDefault().post(new EventBean(11));
                    new Handler().postDelayed(
                            new Runnable() {
                                @Override
                                public void run() {
                                    EventBus.getDefault().post(new EventBean(5));
                                }
                            }
                            , 5000);

                    Log.i("101","handler   rList().remove");
                    if(MyApplication.getOrderList().size()!=0&&VoiceUtils.this.handler!=null){
                        MyApplication.removeBean(0,null);
                        //EventBus.getDefault().post(new EventBean(101));

                        Message msg = new Message();
                        msg.what = MsgBox.MSG_ON_PLAY_COMPLETE;
                        VoiceUtils.this.handler.sendMessage(msg);

                    }



                }
            });

        }




        return mp3Long;


    }







    int tag;


    //下载后播放
    public void  playAudio(String filename)
    {
        MediaPlayer mp  = new MediaPlayer();

        try {
            mp.setDataSource(Environment.getExternalStorageDirectory().toString() + "/CallACar/"+filename);
            System.out.println("play");
			singleton.SetIsPlay(true);

            mp.prepare();
            mp.start();
        }catch (IllegalStateException e) {
            mp.stop();;
            mp.release();
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
            mp.stop();;
            mp.release();
        }
        mp.setOnCompletionListener(this);
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        mp.stop();;
        mp.release();//释放音频资源
        
        singleton.SetIsPlay(false);

        EventBus.getDefault().post(new EventBean(11));
        new Handler().postDelayed(
                new Runnable() {
                    @Override
                    public void run() {
                        EventBus.getDefault().post(new EventBean(5));
                    }
                }
                , 5000);

        Log.i("101","handler   rList().remove");
        if(MyApplication.getOrderList().size()!=0&&handler!=null){
            MyApplication.removeBean(0,null);
            //EventBus.getDefault().post(new EventBean(101));

            Message msg = new Message();
            msg.what = MsgBox.MSG_ON_PLAY_COMPLETE;
            handler.sendMessage(msg);

        }


    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {


        EventBus.getDefault().post(new EventBean(Constant.NeedPlay,""));

        SetIsPlay(false);
        SPTool.putBoolean(mContext,Constant.IsPlay,false);
        File dir = new File(Constant.LOG_PATH);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        long current = System.currentTimeMillis();
        String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                .format(new Date(current));
        // 以当前时间创建log文件
        File file = new File(Constant.LOG_PATH + "mediap_layer_error_" + time
                +  ".txt");


        try {   MyApplication.removeBean(0,null); } catch (Exception e){}


        try {
            mediaPlayer.stop();;
            mediaPlayer.release();
            mediaPlayer = null;
        }catch (Exception e){
            mediaPlayer.stop();;
            mediaPlayer.release();
            mediaPlayer = null;
        }

        return false;
    }


    @Override
    public void onTimelineChanged(Timeline timeline, Object manifest) {

    }

    @Override
    public void onTracksChanged(TrackGroupArray trackGroups, TrackSelectionArray trackSelections) {

    }

    @Override
    public void onLoadingChanged(boolean isLoading) {

    }

    @Override
    public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {

        if(playbackState == ExoPlayer.STATE_READY){
            Log.i("TEST", "ExoPlayer State is: READY");
        } else if (playbackState == ExoPlayer.STATE_BUFFERING){
            Log.i("TEST", "ExoPlayer State is: BUFFERING");
        } else if (playbackState == ExoPlayer.STATE_ENDED){
            Log.i("TEST", "ExoPlayer State is: ENDED");
            if (player!=null)
            {
                player.stop();;
                player.release();
            }
            SPTool.putBoolean(mContext,Constant.IsPlay,true);
            singleton.SetIsPlay(false);
            EventBus.getDefault().post(new EventBean(11));
            new Handler().postDelayed(
                    new Runnable() {
                        @Override
                        public void run() {
                            EventBus.getDefault().post(new EventBean(5));
                        }
                    }
                    , 5000);

            Log.i("101","handler   rList().remove");
            if(MyApplication.getOrderList().size()!=0&&handler!=null){
                MyApplication.removeBean(0,null);
                //EventBus.getDefault().post(new EventBean(101));

                Message msg = new Message();
                msg.what = MsgBox.MSG_ON_PLAY_COMPLETE;
                handler.sendMessage(msg);

            }

        } else if (playbackState == ExoPlayer.STATE_IDLE){
            Log.i("TEST", "ExoPlayer State is: IDLE");
        }
    }

    @Override
    public void onPlayerError(ExoPlaybackException error) {

    }

    @Override
    public void onPositionDiscontinuity() {

    }

    @Override
    public void onPlaybackParametersChanged(PlaybackParameters playbackParameters) {

    }
}
