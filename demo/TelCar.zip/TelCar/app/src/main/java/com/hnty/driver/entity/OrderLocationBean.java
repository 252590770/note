package com.hnty.driver.entity;


import com.google.gson.Gson;

public class OrderLocationBean {


    @Override
    public String toString() {
        return new Gson().toJson(this);
    }

    public String info;
    public RegeocodeBean regeocode;

    public static class RegeocodeBean {
        public String formatted_address;

    }
}
