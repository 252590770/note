package com.hnty.driver.entity;

import com.google.gson.Gson;


public class FinishOrderBean {

 

    public int code;
    public String msg;
    public BodyBean body;





    public class BodyBean {
    }


    @Override
    public String toString() {

        return new Gson().toJson(this);
    }


}
