package com.hnty.driver.util;

/**
 * Created by L on 2017/11/1.
 */

public class MsgBox {
    public static final int BASE_MESSAGE=0X01;
    public static final int MSG_UPLOAD_FILE_SUCCESS=BASE_MESSAGE+1;
    public static final int MSG_UPLOAD_FILE_FAILED=BASE_MESSAGE+2;

    public static final int MSG_SHUTDOWN_SUCCESS=BASE_MESSAGE+3;
    public static final int MSG_SHUTDOWN_FAILED=BASE_MESSAGE+4;
    public static final int MSG_CONTENT=BASE_MESSAGE+5;
    public static final int MSG_BEAT=BASE_MESSAGE+6;
    public static final int MSG_ON_FINISH_ORDER=BASE_MESSAGE+7;
    public static final int MSG_ON_CAR_NO_SAME=BASE_MESSAGE+8;
    public static final int MSG_ON_OTHER_ORDER=BASE_MESSAGE+9;
    public static final int MSG_ON_NOTICE=BASE_MESSAGE+10;
    public static final int MSG_ON_PLAY_COMPLETE=BASE_MESSAGE+11;
    public static final int MSG_ON_CONTINUE_PLAY_ORDER=BASE_MESSAGE+12;
    public static final int MSG_ON_CONNECT=BASE_MESSAGE+13;
    public static final int MSG_CLOSE_CONNECT=BASE_MESSAGE+14;
    public static final int MSG_CONNECT_SUCCESS=BASE_MESSAGE+15;







}
