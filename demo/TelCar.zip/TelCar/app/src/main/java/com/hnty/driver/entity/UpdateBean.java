package com.hnty.driver.entity;

/**
 * Created by L on 2018/1/11.
 */

public class UpdateBean {


    public int code;
    public String msg;
    public BodyBean body;


    public static class BodyBean {


        public String id;
        public String version_num;
        public String version_url;


    }
}
