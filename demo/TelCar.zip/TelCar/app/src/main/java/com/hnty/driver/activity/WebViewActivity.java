package com.hnty.driver.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

import com.hnty.driver.R;
import com.hnty.driver.base.BaseActivity;
import com.hnty.driver.databinding.ActivityQrCodeBinding;
import com.hnty.driver.inter.OnPosyListener;
import com.hnty.driver.model.modelimpl.ToPosyModelImpl;
import com.hnty.driver.util.ToastUtil;

/**
 * Created by Administrator on 2017/4/27.
 */

public class WebViewActivity extends BaseActivity<ActivityQrCodeBinding>  {

    Context context;
    String orderId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_code);
        setTitle("收款码");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//来保持屏幕高亮
        showContentView();
        context = this;
        orderId = getIntent().getStringExtra("billNo");
    }

    public void getQrCode(View view) {
        if(bindingView.money.getText().toString().trim().length()==0){
            ToastUtil.show(context,"请输入金额");
            return;
        }
        bindingView.money.clearFocus();
        showProgressDialog("正在生成...");
        toPosy(orderId+"",1+"");
    }






    ToPosyModelImpl  posyModel;
    OnPosyListener   onPosyListener;
    void  toPosy (String billNo ,String totalAmount){
        if(posyModel == null){
            posyModel = new ToPosyModelImpl();
        }
        if(onPosyListener == null){
            onPosyListener = new OnPosyListener() {
                @Override
                public void onPosSuccess(String code) {



                }

                @Override
                public void onPosError(String errStr) {

                }
            };
        }

        posyModel.toPosy(billNo,totalAmount,onPosyListener);
    }















    //显示进度框
    private ProgressDialog progDialog = null;//
    private void showProgressDialog(String str) {
        if (progDialog == null)
            progDialog = new ProgressDialog(this);
        progDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progDialog.setIndeterminate(false);
        progDialog.setCancelable(true);
        progDialog.setMessage(str);
        progDialog.show();
    }
    //隐藏进度框
    private void dissmissProgressDialog() {
        if (progDialog != null) {
            progDialog.dismiss();
        }
    }



    public static void start(Context mContext) {
        Intent intent = new Intent(mContext, WebViewActivity.class);
        mContext.startActivity(intent);
    }



}
