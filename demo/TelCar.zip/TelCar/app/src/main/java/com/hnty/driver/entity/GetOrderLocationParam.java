package com.hnty.driver.entity;

/**
 * Created by L on 2018/1/11.
 */

public class GetOrderLocationParam {

    //output=JSON&
    // location=116.481488,39.990464
    // &key=d6a0cb18838da2ebb137e2a800e478db&
    // radius=0&
    // extensions=base

    public String location;
    public String key;

    public GetOrderLocationParam(String location, String key) {
        this.location = location;
        this.key = key;
    }

    public GetOrderLocationParam() {
    }


}
