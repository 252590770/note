package com.hnty.driver.model.modelinter;


import com.hnty.driver.entity.CodeParam;
import com.hnty.driver.entity.DriverCancelParam;
import com.hnty.driver.inter.OnCodeListener;
import com.hnty.driver.inter.OnDriverCancelListener;


public interface DriverCancelModel {

    void driverCancel(DriverCancelParam param, OnDriverCancelListener listener);

}
