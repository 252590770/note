package com.hnty.driver.activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.hnty.driver.R;
import com.hnty.driver.application.MyApplication;
import com.hnty.driver.autolist.MyMessageAdapter;
import com.hnty.driver.autolist.PullToRefreshLayout;
import com.hnty.driver.autolist.PullableListView;
import com.hnty.driver.base.BaseActivity;
import com.hnty.driver.databinding.ActivityMyMessageBinding;
import com.hnty.driver.entity.VoiceOrderByIdBean;
import com.hnty.driver.entity.VoiceOrderStateParam;
import com.hnty.driver.inter.OnSkanCodeInfoListener;
import com.hnty.driver.inter.VoiceOrderByIdListener;
import com.hnty.driver.model.modelimpl.ScanCodeInfoModelImpl;
import com.hnty.driver.model.modelimpl.VoiceOrderByIdModelImpl;
import com.hnty.driver.util.SPTool;
import com.hnty.driver.util.ToastUtil;
import com.yzq.zxinglibrary.android.CaptureActivity;
import com.yzq.zxinglibrary.bean.ZxingConfig;

/**
 * Created by Administrator on 2017/4/27.
 */

public class MyMessageActivity extends BaseActivity<ActivityMyMessageBinding> implements VoiceOrderByIdListener
                    ,PullToRefreshLayout.OnRefreshListener,PullableListView.OnLoadListener ,MyMessageAdapter.Callback {


    Context context;
    int page = 1;

    public static MyMessageActivity myMessageActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_message);
        myMessageActivity = this;
        setTitle("我的订单");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//来保持屏幕高亮
        showContentView();
        context = this;
        page = 1;
        init();
        getMyOrder();

    }

    public static MyMessageActivity getMyMessageActivity(){
        return myMessageActivity;
    }

    private void init() {
        bindingView.refreshView.setOnRefreshListener(this);;
        bindingView.listView.setOnLoadListener(this);;
    }


    //获取历史订单
    VoiceOrderByIdModelImpl model;
    void getMyOrder (){
        if(model == null){
            model = new VoiceOrderByIdModelImpl();
        }
        if(SPTool.getUserInfo(MyApplication.getContext())==null){
            ToastUtil.show(MyMessageActivity.this,"请登录");
            return;
        }
        showProgressDialog("请稍等...");

        VoiceOrderStateParam param;
        param = new VoiceOrderStateParam("getVoiceOrderbyid", SPTool.getUserInfo(MyApplication.getContext()).body.driver_id,page+"");
        model.getVoiceOrderState(param,this);

    }

    @Override
    public void onRefresh(PullToRefreshLayout pullToRefreshLayout) {
        page = 1;
        isOK = false;
        getMyOrder();
    }

    @Override
    public void onLoad(PullableListView pullableListView) {
        page ++ ;
        if(isOK)
            return;

        getMyOrder();
        bindingView.listView.mStateTextView.setVisibility(View.GONE);
    }

    MyMessageAdapter adapter;
    boolean isOK = false;

    @Override
    public void onVoiceOrderByIdSuccess(final VoiceOrderByIdBean bean) {
        dissmissProgressDialog();

        if(bean.body.size()==0){
            isOK = true;
        }

        if(adapter == null){
            adapter = new MyMessageAdapter(MyMessageActivity.this,bean.body,this);
            bindingView.listView.setAdapter(adapter);
        }else {
            if(page == 1){
                if(bindingView.listView.getAdapter()==null){
                    adapter.refreshAdapter(bean.body);
                    bindingView.listView.setAdapter(adapter);
                }else {
                    adapter.refreshAdapter(bean.body);
                }

            }else {
                adapter.addInfo(bean.body);
            }

        }

        bindingView.refreshView.refreshFinish(PullToRefreshLayout.SUCCEED);
        bindingView.listView.finishLoading();

    }

    @Override
    public void onVoiceOrderByIdError(String err) {
        dissmissProgressDialog();
        ToastUtil.show(MyMessageActivity.this,err);
    }









    //显示进度框
    private ProgressDialog progDialog = null;//
    private void showProgressDialog(String str) {
        if (progDialog == null)
            progDialog = new ProgressDialog(this);
        progDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progDialog.setIndeterminate(false);
        progDialog.setCancelable(true);
        progDialog.setMessage(str);
        progDialog.show();
    }
    //隐藏进度框
    private void dissmissProgressDialog() {
        if (progDialog != null) {
            progDialog.dismiss();
        }
    }


    //提示对话框
    public Dialog dialog;
    public TextView btn_one;
    public TextView btn_right;



    public interface ClickSureListener {
        public void click();
    }

    private ClickSureListener clickSureListener;

    public void showTipDialog(int type, String titleStr,final String no ) {
        if (dialog == null) {
            dialog = new AlertDialog.Builder(this).create();
        }

        LayoutInflater inflater = LayoutInflater.from(this);
        View view = (View) inflater.inflate(R.layout.dialog_edittext, null);
        TextView title = (TextView) view.findViewById(R.id.title);
        final EditText content = (EditText) view.findViewById(R.id.content);
        btn_one = (TextView) view.findViewById(R.id.btn_one);
        LinearLayout layout = (LinearLayout) view
                .findViewById(R.id.bottom_layout);
        btn_right = (TextView) view.findViewById(R.id.btn_right);
        if (type == 1) {
            btn_one.setVisibility(View.VISIBLE);
            layout.setVisibility(View.GONE);
        } else if (type == 2) {
            btn_one.setVisibility(View.GONE);
            layout.setVisibility(View.VISIBLE);
        }
        btn_one.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });

        btn_right.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // sure();
                clickSureListener.click();
            }
        });
        title.setText(titleStr);


        view.findViewById(R.id.btn_left).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

        view.findViewById(R.id.btn_right).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if(content.getText().toString().trim().equals("")){
                            ToastUtil.show(context,"请输入金额!");
                            return;
                        }

                        if(Double.parseDouble(content.getText().toString().trim())<0.01){
                            ToastUtil.show(context,"请输入正确金额!");
                            return;
                        }




                        Intent intent = new Intent(context, QRCodeActivity.class);
                        intent.putExtra("billNo",no);
                        intent.putExtra("count",content.getText().toString().trim());
                        context.startActivity(intent);

                        dialog.dismiss();
                    }
                });

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));

        // 首先先让dialog显示
        dialog.show();
        // 接着清除flags
        dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
        // 然后弹出输入法
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        // 接着添加view
        dialog.getWindow().setContentView(view);


        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
    }







    public static void start(Context mContext) {
        Intent intent = new Intent(mContext, MyMessageActivity.class);
        mContext.startActivity(intent);
    }


    /////////////////上传二维码信息/////////////////
    ScanCodeInfoModelImpl scanCodeInfoModel;
    OnSkanCodeInfoListener onSkanCodeInfoListener;

    void scanCodeInfo(String code,String voice_tell,String voice_order) {
        if (scanCodeInfoModel == null) {
            scanCodeInfoModel = new ScanCodeInfoModelImpl();
        }
        if (onSkanCodeInfoListener == null) {
            onSkanCodeInfoListener = new OnSkanCodeInfoListener() {
                @Override
                public void onSkanCodeSuccess(String str) {
                    ToastUtil.show(context, str);
                }

                @Override
                public void onSkanCodeError(String errStr) {
                    ToastUtil.show(context, errStr);
                }
            };
        }
        scanCodeInfoModel.scanCodeInfo(code, SPTool.getUserInfo(context).body.driver_id+"",
                ""+voice_tell,
                ""+voice_order,
                onSkanCodeInfoListener);
    }
    /////////////////上传二维码信息/////////////////



    @Override
    public void click(View v) {

        int position = (Integer) v.getTag();
        VoiceOrderByIdBean.BodyBean bean = ((VoiceOrderByIdBean.BodyBean)adapter.getItem(position));


        if(v.getId()==R.id.iv_title_code){



            showTipDialog(2,"请输入金额" ,bean.voice_order  );
            return;
        }



        Intent intent = new Intent(context, CaptureActivity.class);
                                /*ZxingConfig是配置类
                                 *可以设置是否显示底部布局，闪光灯，相册，
                                 * 是否播放提示音  震动
                                 * 设置扫描框颜色等
                                 * 也可以不传这个参数
                                 * */
        ZxingConfig config = new ZxingConfig();
        config.setPlayBeep(true);//是否播放扫描声音 默认为true
        config.setShake(true);//是否震动  默认为true
        config.setDecodeBarCode(true);//是否扫描条形码 默认为true
        config.setReactColor(R.color.white);//设置扫描框四个角的颜色 默认为淡蓝色
        config.setFrameLineColor(R.color.white);//设置扫描框边框颜色 默认无色
        config.setFullScreenScan(false);//是否全屏扫描  默认为true  设为false则只会在扫描框中扫描
        intent.putExtra(com.yzq.zxinglibrary.common.Constant.INTENT_ZXING_CONFIG, config);
        startActivityForResult(intent, position);


    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        //requestCode == position &&
        // 扫描二维码/条码回传

        Log.i("1011   requestCode == ",requestCode+"");


        if (resultCode == RESULT_OK) {
            if (data != null) {
                VoiceOrderByIdBean.BodyBean bean = ((VoiceOrderByIdBean.BodyBean)adapter.getItem(requestCode));

                String content = data.getStringExtra(com.yzq.zxinglibrary.common.Constant.CODED_CONTENT);
                scanCodeInfo(content,""+bean.voice_tell,""+bean.voice_order);
            }
        }
    }


}
