package com.hnty.driver.model.modelinter;


import com.hnty.driver.inter.OnNewsListener;

/**
 * Created by L on 2018/1/12.
 */

public interface NewsModel {

    void getNews(OnNewsListener onNewsListener);

}
