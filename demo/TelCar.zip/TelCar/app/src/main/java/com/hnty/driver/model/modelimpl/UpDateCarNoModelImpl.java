package com.hnty.driver.model.modelimpl;

import android.util.Log;

import com.hnty.driver.application.MyApplication;
import com.hnty.driver.entity.BaseBean;
import com.hnty.driver.entity.UpDateCarNoParam;
import com.hnty.driver.inter.OnUpDateCarNoListener;
import com.hnty.driver.util.NetworkUtil;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by L on 2018/1/12.
 */

public class UpDateCarNoModelImpl {


    public void driverOutByCarInfo(UpDateCarNoParam param , final OnUpDateCarNoListener listener) {


        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
//            Toast.makeText(App.getContext(), "没有网络O", Toast.LENGTH_SHORT).show();
            listener.onUpDateCarNoError( "没有网络o");
            return;
        }


        MyApplication.getAPI().driverOutByCarInfo(param.method,param.driver_id,param.car_no)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<BaseBean>() {
                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull BaseBean bean) {


                        try {
                            if(bean.code==1){
                                listener.onUpDateCarNoSuccess(bean.msg);
                            }else{
                                listener.onUpDateCarNoError(bean.msg);
                            }

                        }catch (Exception e){
                            listener.onUpDateCarNoError(  "数据错误"); ;
                        }
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        listener.onUpDateCarNoError("数据错误");
                        Log.i("ccccccc","onError="+e.toString());
                    }

                    @Override
                    public void onComplete() {
                    }
                });

    }



}
