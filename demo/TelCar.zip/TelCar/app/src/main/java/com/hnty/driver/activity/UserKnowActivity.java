package com.hnty.driver.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TextView;

import com.hnty.driver.R;
import com.hnty.driver.base.BaseActivity;

/**
 * Created by Administrator on 2017/4/27.
 */

public class UserKnowActivity  extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_know);
        setTitle("关于我们");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//来保持屏幕高亮
        showContentView();
        ((TextView)findViewById(R.id.tvContent)).setText(
                "        各位的哥的姐，您辛苦了！" +
                        getString(R.string.app_name)+
                        "智能叫车平台旨在方便乘客出行，" +
                        "更为让出租车司机师傅们，" +
                        "少遛活多跑钱。" +
                        "请大家一定按制度使用，" +
                        "接单后使用文明用语，" +
                        "及时联系乘客，" +
                        "树立全新的本地出租车司机形象。祝大家行车愉快，一路平安，感谢您的使用。"



        );
    }
    public static void start(Context mContext) {
        Intent intent = new Intent(mContext, UserKnowActivity.class);
        mContext.startActivity(intent);
    }
}