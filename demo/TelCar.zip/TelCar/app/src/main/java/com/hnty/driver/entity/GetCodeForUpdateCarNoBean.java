package com.hnty.driver.entity;


public class GetCodeForUpdateCarNoBean {


    public int code;
    public String msg;
    public BodyBean body;

    public static class BodyBean {

        public int num;


    }
}
