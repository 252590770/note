package com.hnty.driver.entity;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by L on 2018/1/11.
 */

public class VoiceOrderByIdBean {

    public int code;
    public String msg;
    public ArrayList<BodyBean> body;

    public  class BodyBean {

        public String voice_order;
        public int driver_balance;
        public int driver_charge;
        public String driver_name;
        public String voice_name;
        public String oper_date;
        public int rowNumber;
        public String end_name;
        public String voice_file;
        public String voice_lat;
        public String driver_latitude;
        public String driver_longitude;
        public String get_latitude;
        public String voice_state;
        public String order_price;
        public int id;
        public String voice_end;
        public String get_longitude;
        public String end_longitude;
        public String end_latitude;
        public int drivercount;
        public String voice_lng;
        public int driver_id;
        public String voice_tell;
        public String driver_tell;
        public String order_type;
    }

}
