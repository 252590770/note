package com.hnty.driver.update;

import android.widget.Toast;


import com.hnty.driver.application.MyApplication;
import com.hnty.driver.util.NetworkUtil;

import org.reactivestreams.Publisher;

import io.reactivex.Flowable;
import io.reactivex.FlowableTransformer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import okhttp3.ResponseBody;

/**
 * Created by L on 2018/1/12.
 */

public class DownLoadAPKModelImpl implements DownLoadAPK {

    @Override
    public void downLoad(FileDownLoadSubscriber subscriber, String url) {


        if (!NetworkUtil.isNetworkAvailable(MyApplication.getContext())) {
            Toast.makeText(MyApplication.getContext(), "没有网络O", Toast.LENGTH_SHORT).show();
            return;
        }

        MyApplication.getAPI().downLoad(url).
                compose(ioMainDownload()).
                subscribeWith(subscriber);
    }


    private static FlowableTransformer<ResponseBody, ResponseBody> ioMainDownload() {
        return new FlowableTransformer<ResponseBody, ResponseBody>() {
            @Override
            public Publisher<ResponseBody> apply(Flowable<ResponseBody> upstream) {
                return upstream.subscribeOn(Schedulers.io()).
                        observeOn(Schedulers.io()).
                        observeOn(Schedulers.computation()).
                        map(new Function<ResponseBody, ResponseBody>() {
                            @Override
                            public ResponseBody apply(ResponseBody responseBody) throws Exception {
                                return responseBody;
                            }
                        }).
                        observeOn(AndroidSchedulers.mainThread());
            }
        };
    }


}
