/**
 * 文 件 名:  App.java
 * 版    权:  Technologies Co., Ltd. Copyright YYYY-YYYY,  All rights reserved
 * 描    述:  <描述>
 * 修 改 人:  江钰锋 00501
 * 修改时间:  16/6/8
 * 跟踪单号:  <跟踪单号>
 * 修改单号:  <修改单号>
 * 修改内容:  <修改内容>
 */

package com.robin.lazy.sample;

import android.app.Application;

import com.karumi.dexter.Dexter;

/**
 * <一句话功能简述>
 */
public class App extends Application{
    @Override
    public void onCreate() {
        super.onCreate();
        Dexter.initialize(this);
    }
}
